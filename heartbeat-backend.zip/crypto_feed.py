"""Independent read-only Alpaca crypto quote polling. No broker order capability."""
import copy,json,math,sqlite3,threading,time,shutil,os
from datetime import datetime
VERSION='HB-CRYPTO-COLLECTION-002'
SYMBOLS=('BTC/USD','ETH/USD')

def diagnose(raw,now):
    if raw is None:return {'state':'MISSING','reason':'QUOTE_MISSING'}
    if not isinstance(raw,dict):return {'state':'MALFORMED','reason':'QUOTE_MALFORMED'}
    try:
        stamp=datetime.fromisoformat(raw['t'].replace('Z','+00:00'))
        if stamp.tzinfo is None:raise ValueError()
        age=now-stamp.timestamp()
        values=[float(raw[k]) for k in ('bp','ap','bs','as')]
        if any(isinstance(raw[k],bool) for k in ('bp','ap','bs','as')) or not all(math.isfinite(v) for v in values):raise ValueError()
        bid,ask,bs,asz=values
        if not 0<bid<=ask or min(bs,asz)<=0:raise ValueError()
    except (KeyError,ValueError,TypeError,OverflowError):return {'state':'MALFORMED','reason':'QUOTE_MALFORMED','source_at':raw.get('t')}
    state='FUTURE' if age<0 else 'STALE' if age>15 else 'FRESH'
    return {'state':state,'reason':'QUOTE_'+state,'source_at':raw['t'],'age_seconds':round(age,3)}

class Collector:
    def __init__(self,path,fetch):
        self.path=path;self.fetch=fetch;self.started=False;self.lock=threading.Lock();self.latest={};self.received=None;self.error=None;self.failures=0
    def initialize(self):
        with sqlite3.connect(self.path,timeout=10) as db:
            db.execute('CREATE TABLE IF NOT EXISTS cq_polls(id INTEGER PRIMARY KEY,received_at REAL,payload TEXT NOT NULL)')
            row=db.execute('SELECT received_at,payload FROM cq_polls ORDER BY id DESC LIMIT 1').fetchone()
        if row:
            record=json.loads(row[1]);self.received=row[0];self.latest=record.get('quotes',{});self.error=record.get('error')
    def poll(self,clock=time.time):
        if shutil.disk_usage(os.path.dirname(self.path)).free<64*1024*1024:raise OSError('FEED_STORAGE_LOW')
        try:
            response=self.fetch();received=clock()
            if not isinstance(response,dict) or not isinstance(response.get('quotes'),dict):raise ValueError()
            raw={s:response['quotes'].get(s) for s in SYMBOLS};error=None
        except Exception as e:
            received=clock();raw={};error=str(e) if str(e) in ('RATE_LIMITED','AUTH_REJECTED','PAPER_ACCESS_DENIED','REQUEST_UNCERTAIN') else 'FEED_UNAVAILABLE'
        record={'version':VERSION,'received_at':received,'quotes':raw,'diagnostics':{s:diagnose(raw.get(s),received) for s in SYMBOLS},'error':error}
        # Persist before making the sample available to the strategy.
        with sqlite3.connect(self.path,timeout=10) as db:db.execute('INSERT INTO cq_polls(received_at,payload) VALUES(?,?)',(received,json.dumps(record,allow_nan=False)))
        with self.lock:self.latest=raw;self.received=received;self.error=error;self.failures=self.failures+1 if error else 0
        return record
    def snapshot(self,now):
        with self.lock:
            return {'version':VERSION,'transport':'REST polling, nominally every 5 seconds','received_at':self.received,'error':self.error,'quotes':copy.deepcopy(self.latest),'diagnostics':{s:diagnose(self.latest.get(s),now) for s in SYMBOLS},'failures':self.failures}
    def start(self):
        if self.started:return
        self.initialize();self.started=True;threading.Thread(target=self.loop,daemon=True,name='crypto-quotes').start()
    def loop(self):
        while True:
            try:self.poll()
            except Exception:
                with self.lock:self.error='FEED_STORAGE_UNAVAILABLE';self.latest={};self.failures+=1
            # Reconnect on each REST request; capped backoff, never a busy retry loop.
            with self.lock:delay=min(60,5*2**min(self.failures,4))
            time.sleep(delay)
