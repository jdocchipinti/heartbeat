"""Website Studio: bounded public-page scan, reviewed briefs, deterministic concepts."""
import html, http.client, ipaddress, json, re, secrets, socket, ssl, time
from html.parser import HTMLParser
from urllib.parse import urlsplit
from clarity_outreach import OutreachError, clean

class Page(HTMLParser):
    def __init__(self):
        super().__init__(); self.hidden=0; self.title=False; self.titles=[]; self.words=[]; self.description=''; self.viewport=False; self.h1=0
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag in ('script','style','noscript','svg'):self.hidden+=1
        if tag=='title':self.title=True
        if tag=='h1':self.h1+=1
        if tag=='meta' and a.get('name','').lower()=='description':self.description=a.get('content','')[:800]
        if tag=='meta' and a.get('name','').lower()=='viewport':self.viewport=True
    def handle_endtag(self,tag):
        if tag in ('script','style','noscript','svg'):self.hidden=max(0,self.hidden-1)
        if tag=='title':self.title=False
    def handle_data(self,data):
        if not self.hidden:
            self.words.append(data)
            if self.title:self.titles.append(data)

def public_url(value):
    value=clean(value,1000); u=urlsplit(value)
    try:port=u.port
    except ValueError:raise OutreachError('INVALID_PUBLIC_URL')
    if u.scheme!='https' or not u.hostname or u.username or u.password or port not in (None,443) or any(c.isspace() for c in value):raise OutreachError('USE_PUBLIC_HTTPS_URL')
    return u

class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self,host,address):super().__init__(host,timeout=8,context=ssl.create_default_context());self.address=address
    def connect(self):
        sock=socket.create_connection((self.address,443),self.timeout)
        try:self.sock=self._context.wrap_socket(sock,server_hostname=self.host)
        except Exception:sock.close();raise

class Studio:
    def __init__(self,workspace):self.workspace=workspace
    def db(self):
        db=self.workspace.db();db.execute('CREATE TABLE IF NOT EXISTS ws_projects(id TEXT PRIMARY KEY,created REAL,payload TEXT)');return db
    def status(self):
        with self.db() as db:rows=db.execute('SELECT payload FROM ws_projects ORDER BY created DESC LIMIT 50').fetchall()
        return {'projects':[json.loads(r['payload']) for r in rows]}
    def scan(self,data):
        u=public_url(data.get('source')); host=u.hostname.encode('idna').decode('ascii')
        try:
            addresses=list(dict.fromkeys(x[4][0] for x in socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)))
            if not addresses or any(not ipaddress.ip_address(a).is_global for a in addresses):raise OutreachError('PUBLIC_INTERNET_ADDRESS_REQUIRED')
            conn=PinnedHTTPS(host,addresses[0])
            try:
                conn.request('GET',(u.path or '/')+('?' + u.query if u.query else ''),headers={'User-Agent':'UmbrellaWebsiteStudio/1.0 (single-page research)','Accept':'text/html','Accept-Encoding':'identity'})
                r=conn.getresponse()
                if 300<=r.status<400:raise OutreachError('REDIRECT_NOT_FOLLOWED_USE_FINAL_HTTPS_URL')
                if r.status!=200:raise OutreachError('SOURCE_UNAVAILABLE_'+str(r.status))
                if 'text/html' not in r.getheader('Content-Type','').lower():raise OutreachError('HTML_PAGE_REQUIRED')
                if r.getheader('Content-Encoding','identity') not in ('','identity'):raise OutreachError('COMPRESSED_SOURCE_NOT_SUPPORTED')
                raw=r.read(200001)
                if len(raw)>200000:raise OutreachError('PAGE_TOO_LARGE_PASTE_VERIFIED_INFORMATION')
            finally:conn.close()
        except OutreachError:raise
        except (OSError,ValueError,http.client.HTTPException):raise OutreachError('SCAN_UNAVAILABLE_PASTE_VERIFIED_INFORMATION') from None
        p=Page();p.feed(raw.decode('utf-8',errors='replace'));body=re.sub(r'\s+',' ',' '.join(p.words)).strip()[:7000]
        findings=[{'observation':'HTML title','value':' '.join(p.titles)[:300] or 'Not found in downloaded HTML'}, {'observation':'Meta description','value':p.description or 'Not found in downloaded HTML'}, {'observation':'Mobile viewport declaration','value':'Present' if p.viewport else 'Not found in downloaded HTML'}, {'observation':'Primary headings (H1)','value':str(p.h1)}]
        opportunities=[]
        if not p.description:opportunities.append('No meta description found in this response. Consider a concise description of the business and service area.')
        if not p.viewport:opportunities.append('No viewport declaration found. Check the rendered mobile experience before recommending a fix.')
        if p.h1!=1:opportunities.append('Review the primary heading structure; the downloaded page contains '+str(p.h1)+' H1 elements.')
        if not re.search(r'book|contact|quote|consultation|reserve|schedule',body,re.I):opportunities.append('No common inquiry wording found in extracted text. Check whether the next action is clear to visitors.')
        opportunities.append('Confirm the target customer, main offer, and inquiry destination with the business. These cannot be verified from HTML alone.')
        result={'opportunities':opportunities,'source':data['source'],'scanned_at':time.time(),'findings':findings,'excerpt':body,'scope':'One public HTML page; no JavaScript rendering, performance measurement, accessibility audit, or contact verification.'}
        # Keep source evidence separately from the operator-reviewed business brief.
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS ws_scans(id TEXT PRIMARY KEY,payload TEXT)');scan_id=secrets.token_hex(12);db.execute('INSERT INTO ws_scans VALUES(?,?)',(scan_id,json.dumps(result)))
        return dict(result,scan_id=scan_id)
    def create(self,data):
        if data.get('verified') is not True:raise OutreachError('REVIEW_BUSINESS_FACTS_FIRST')
        fields={k:clean(data.get(k),n) for k,n in [('company',120),('source',1000),('audience',300),('offer',500),('headline',180),('goal',120),('fact',500)]};public_url(fields['source'])
        services=data.get('services')
        if not isinstance(services,list) or not 1<=len(services)<=6:raise OutreachError('ONE_TO_SIX_SERVICES_REQUIRED')
        fields['services']=[clean(s,140) for s in services]
        style=data.get('style','editorial')
        if style not in ('editorial','local','professional'):raise OutreachError('INVALID_STYLE')
        project=dict(fields,id=secrets.token_hex(12),created=time.time(),style=style,version='WS-1',provenance='Operator-reviewed facts; deterministic layout and copy, no autonomous LLM.',source_evidence=None)
        if data.get('scan_id'):
            with self.db() as db:
                db.execute('CREATE TABLE IF NOT EXISTS ws_scans(id TEXT PRIMARY KEY,payload TEXT)');row=db.execute('SELECT payload FROM ws_scans WHERE id=?',(data['scan_id'],)).fetchone()
            if not row:raise OutreachError('SCAN_NOT_FOUND')
            evidence=json.loads(row['payload'])
            if evidence['source']!=fields['source']:raise OutreachError('SOURCE_CHANGED_SCAN_AGAIN_OR_CLEAR_SCAN')
            project['source_evidence']=evidence
        project['recommendations']=[f"Lead with the reviewed offer: {fields['offer']}",f"Write for: {fields['audience']}",f"Use one primary action: {fields['goal']}","Verify photography rights and business claims before publishing.","Connect and test the inquiry destination before launch."]
        project['subject']='A website concept for '+fields['company']
        project['email_body']='Hello '+fields['company']+' team,\n\n'+fields['fact']+'\n\nI’m John with The Umbrella Institute. I build websites for small and medium-sized businesses. I prepared an independent website concept around '+fields['offer']+' with a clearer path for visitors to '+fields['goal'].lower()+'.\n\nWould you like me to send the concept for your feedback? It is an unsolicited design proposal, with no obligation. I can also walk you through the design and discuss scope if it is useful.\n\nThank you for your time.'
        project['html']=render(project)
        with self.db() as db:db.execute('INSERT INTO ws_projects VALUES(?,?,?)',(project['id'],project['created'],json.dumps(project)))
        return project
    def queue(self,data):
        with self.db() as db:row=db.execute('SELECT payload FROM ws_projects WHERE id=?',(data.get('id'),)).fetchone()
        if not row:raise OutreachError('PROJECT_NOT_FOUND')
        p=json.loads(row['payload'])
        return self.workspace.create({'company':p['company'],'source':p['source'],'fact':p['fact'],'email':data.get('email'),'verified_source':data.get('verified_contact') is True,'campaign':'website','subject':p['subject'],'body':p['email_body']})

def render(p):
    e=lambda k:html.escape(p[k],quote=True)
    palettes={'editorial':('#eee9e0','#202c29','#d4aa73'),'local':('#f1eee7','#153f32','#c1dc91'),'professional':('#eff2f5','#192d49','#b3caf2')}
    bg,ink,accent=palettes[p['style']]
    cards=''.join('<article><span class="number">0'+str(i+1)+'</span><h3>'+html.escape(s)+'</h3><a href="#contact">Explore your next step ↗</a></article>' for i,s in enumerate(p['services']))
    return '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'"><title>'''+e('company')+''' · Independent website concept</title><style>
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:'''+bg+''';color:'''+ink+''';font:17px/1.65 system-ui,sans-serif}a{color:inherit}button,a{touch-action:manipulation}header,main,footer{max-width:1440px;margin:auto;padding:28px 6%}.notice{background:'''+ink+''';color:white;text-align:center;font-size:12px;padding:10px 18px;letter-spacing:.05em}header{display:flex;gap:20px;align-items:center;justify-content:space-between;border-bottom:1px solid #8885}.brand{font-size:23px;font-weight:750;letter-spacing:-.05em;overflow-wrap:anywhere}nav{display:flex;gap:24px;font-size:14px}nav a{text-decoration:none}.hero{display:grid;grid-template-columns:1.2fr 1fr;gap:7%;align-items:center;padding:70px 0 85px}.eyebrow{text-transform:uppercase;font-size:12px;letter-spacing:.2em;font-weight:700}h1{font:clamp(40px,5.5vw,80px)/1.04 Georgia,serif;letter-spacing:-.05em;margin:25px 0;overflow-wrap:anywhere}h2{font:clamp(32px,4vw,50px)/1.15 Georgia,serif;letter-spacing:-.03em}h3{font-size:23px;line-height:1.3}.intro{max-width:550px;opacity:.85}.cta{display:inline-block;background:'''+ink+''';color:white;padding:17px 25px;border-radius:50px;text-decoration:none;margin-top:20px;font-size:14px}.art{min-height:440px;position:relative;overflow:hidden;background:'''+accent+''';border-radius:200px 200px 16px 16px;display:grid;place-items:center}.art svg{width:100%;height:auto}.art small{position:absolute;bottom:20px;left:25px;right:25px;font-size:11px;text-transform:uppercase;letter-spacing:.12em}.section{padding:60px 0;border-top:1px solid #8885}.services{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}.services article{background:#fff7;border:1px solid #8883;padding:28px;border-radius:12px}.number{font-size:12px;letter-spacing:.15em;opacity:.6}.services a{font-size:13px}.contact{background:'''+ink+''';color:white;border-radius:20px;padding:48px;margin:35px 0}.contact h2{margin-top:0}.contact p{max-width:680px}.contact a{display:inline-block;margin-top:15px;color:white}footer{border-top:1px solid #8885;font-size:12px;display:flex;justify-content:space-between;gap:20px}@media(max-width:750px){header{flex-wrap:wrap}nav{gap:15px}.hero{grid-template-columns:1fr;padding:35px 0;gap:35px}.art{min-height:300px;max-height:400px}.services{grid-template-columns:1fr}.section{padding:30px 0}.contact{padding:28px}footer{display:block}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}</style></head><body>
<div class="notice">INDEPENDENT DESIGN CONCEPT · Prepared by The Umbrella Institute · Not an official business website</div><header><div class="brand">'''+e('company')+'''</div><nav aria-label="Main"><a href="#services">Services</a><a href="#about">Our approach</a><a href="#contact">Get in touch ↗</a></nav></header><main><section class="hero"><div><p class="eyebrow">'''+e('audience')+'''</p><h1>'''+e('headline')+'''</h1><p class="intro">'''+e('offer')+'''</p><a class="cta" href="#contact">'''+e('goal')+''' ↗</a></div><div class="art" aria-label="Original abstract concept artwork, not a business photograph"><svg viewBox="0 0 500 520" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Architectural arches"><circle cx="390" cy="110" r="65" fill="#fff" opacity=".4"/><path d="M80 480V230a170 170 0 0 1 340 0v250Z" fill="'''+ink+'''"/><path d="M135 480V245a115 115 0 0 1 230 0v235Z" fill="'''+bg+'''"/><path d="M190 480V270a60 60 0 0 1 120 0v210Z" fill="'''+accent+'''"/><path d="M0 480h500v40H0Z" fill="'''+ink+'''" opacity=".2"/></svg><small>Visual direction / custom photography to follow</small></div></section><section id="services" class="section"><p class="eyebrow">What we do</p><h2>A clear path to what you need.</h2><div class="services">'''+cards+'''</div></section><section id="about" class="section"><p class="eyebrow">Made for your next step</p><h2>Start with the right conversation.</h2><p class="intro">Explore the services above, share what you need, and discuss the next steps with the team.</p></section><section id="contact" class="contact"><p class="eyebrow">Let’s begin</p><h2>'''+e('goal')+'''</h2><p>This concept demonstrates the inquiry section. Booking, payments and contact forms are not connected.</p><a href="'''+e('source')+'''" rel="noopener noreferrer" target="_blank">Visit the existing business website ↗</a></section></main><footer><span>'''+e('company')+''' · Design preview</span><span>Concept by The Umbrella Institute · Content requires business approval</span></footer></body></html>'''
