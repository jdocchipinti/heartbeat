import io,json,tempfile,unittest
from unittest.mock import Mock,patch
import clarity_outreach as o
import server
ENV={'HB_OUTREACH_ENABLED':'true','HB_OUTREACH_SMTP_HOST':'smtp.example.com','HB_OUTREACH_SMTP_PORT':'587','HB_OUTREACH_SMTP_USER':'fixture','HB_OUTREACH_SMTP_PASSWORD':'fixture-secret','HB_OUTREACH_FROM':'john@example.com','HB_OUTREACH_POSTAL_ADDRESS':'Fixture postal address','HB_OUTREACH_SENDER_CONFIRMED':'true'}
DATA={'company':'Example Co','email':'hello@example.com','source':'https://example.com/about','fact':'I saw your planning resources on your website.','verified_source':True}
class OutreachTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.transport=Mock(return_value='<fixture>');self.w=o.Workspace(self.tmp.name+'/outreach.db',self.transport,False);self.env=patch.dict(o.os.environ,ENV);self.env.start()
 def tearDown(self):self.env.stop();self.tmp.cleanup()
 def create(self):return self.w.create(DATA)['drafts'][0]
 def test_draft_and_duplicate_no_send(self):
  d=self.create();self.assertEqual(d['state'],'DRAFT');self.assertNotIn('954-849',d['body']);self.assertIn('unsubscribe',d['body']);self.assertNotIn('fixture-secret',json.dumps(self.w.status()));self.transport.assert_not_called()
  with self.assertRaisesRegex(o.OutreachError,'ALREADY'):self.create()
 def test_approval_hash_and_idempotence(self):
  d=self.create()
  for bad in ({'approved':False},{'approved':True,'review_hash':'old'}):
   with self.assertRaises(o.OutreachError):self.w.send({'id':d['id'],**bad})
  req={'id':d['id'],'approved':True,'review_hash':d['review_hash']};result=self.w.send(req);self.assertEqual(result['drafts'][0]['state'],'SMTP_ACCEPTED')
  with self.assertRaises(o.OutreachError):self.w.send(req)
  self.assertEqual(self.transport.call_count,1)
 def test_changed_content_and_sender_require_new_review(self):
  d=self.create();self.w.edit({'id':d['id'],'subject':'New subject','body':'A changed message that needs another review.'})
  with self.assertRaisesRegex(o.OutreachError,'CHANGED'):self.w.send({'id':d['id'],'approved':True,'review_hash':d['review_hash']})
 def test_suppression_link_requires_post_and_blocks(self):
  d=self.create();token=d['body'].split('?t=')[1].split('\n')[0];self.w.unsubscribe(token);self.assertEqual(len(self.w.status()['suppressed']),0);self.w.unsubscribe(token,True);self.assertEqual(self.w.status()['drafts'][0]['state'],'SUPPRESSED')
  with self.assertRaises(o.OutreachError):self.w.send({'id':d['id'],'approved':True,'review_hash':d['review_hash']})
 def test_uncertain_attempt_never_retried_after_restart(self):
  d=self.create();self.transport.side_effect=TimeoutError();req={'id':d['id'],'approved':True,'review_hash':d['review_hash']};self.w.send(req)
  again=o.Workspace(self.w.path,self.transport,False)
  with self.assertRaises(o.OutreachError):again.send(req)
  self.assertEqual(again.status()['drafts'][0]['state'],'UNKNOWN_CHECK_MAILBOX');self.assertEqual(self.transport.call_count,1)
 def test_setup_gate_and_header_injection(self):
  d=self.create()
  with patch.dict(o.os.environ,{'HB_OUTREACH_ENABLED':'false'}):
   with self.assertRaisesRegex(o.OutreachError,'SETUP'):self.w.send({'id':d['id'],'approved':True,'review_hash':d['review_hash']})
  with self.assertRaises(o.OutreachError):self.w.create({**DATA,'company':'bad\nBcc: other@example.com'})
 def test_daily_limit(self):
  for i in range(5):
   d=self.w.create({**DATA,'email':f'p{i}@example.com'})['drafts'][0];self.w.send({'id':d['id'],'approved':True,'review_hash':d['review_hash']})
  d=self.w.create({**DATA,'email':'six@example.com'})['drafts'][0]
  with self.assertRaisesRegex(o.OutreachError,'DAILY_LIMIT'):self.w.send({'id':d['id'],'approved':True,'review_hash':d['review_hash']})
 def test_route_auth_and_bearer_create(self):
  with patch.object(server,'ensure_started'),patch.object(server,'OUTREACH',self.w),patch.object(server,'TOKEN','x'*32),patch.object(server.browser_sessions,'validate',return_value=None):
   result=[];server.application({'PATH_INFO':'/api/outreach/status','REQUEST_METHOD':'GET'},lambda s,h:result.append(s));self.assertTrue(result[0].startswith('401'))
   body=json.dumps(DATA).encode();result=[]
   response=b''.join(server.application({'PATH_INFO':'/api/outreach/create','REQUEST_METHOD':'POST','HTTP_AUTHORIZATION':'Bearer '+'x'*32,'CONTENT_LENGTH':str(len(body)),'wsgi.input':io.BytesIO(body)},lambda s,h:result.append(s)))
   self.assertEqual(result[0],'200 OK');self.assertEqual(json.loads(response)['drafts'][0]['email'],DATA['email'])
