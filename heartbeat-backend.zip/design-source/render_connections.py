"""Render original vector motion graphics on black, for screen compositing.
This creates animated paths and particles; it does not edit a source image.
"""
import math,random,subprocess
from PIL import Image,ImageDraw,ImageFilter
W,H,FPS,SECONDS=960,540,30,12
random.seed(21)
def bez(a,b,c,d,n=100):
 return [((1-t)**3*a[0]+3*(1-t)**2*t*b[0]+3*(1-t)*t*t*c[0]+t**3*d[0],(1-t)**3*a[1]+3*(1-t)**2*t*b[1]+3*(1-t)*t*t*c[1]+t**3*d[1]) for t in [i/(n-1) for i in range(n)]]
def curve(coords):return bez(*[(x*W,y*H) for x,y in coords])
# Brain fibers, brain-to-world pathways, then world-to-root pathways.
specs=[
([(.72,.23),(.69,.10),(.59,.12),(.55,.23)],.2),
([(.72,.23),(.77,.13),(.83,.10),(.84,.19)],.4),
([(.72,.23),(.64,.29),(.60,.32),(.59,.25)],.6),
([(.72,.23),(.77,.29),(.85,.24),(.85,.34)],.8),
([(.72,.23),(.72,.17),(.70,.09),(.65,.10)],1.0),
([(.72,.23),(.78,.34),(.82,.36),(.77,.43)],1.2),
([(.65,.31),(.65,.42),(.75,.41),(.73,.52)],2.1),
([(.80,.34),(.87,.44),(.78,.49),(.80,.64)],2.3),
([(.70,.35),(.69,.47),(.65,.49),(.64,.66)],2.5),
([(.76,.38),(.73,.50),(.69,.60),(.72,.73)],2.7),
([(.73,.52),(.65,.54),(.64,.67),(.73,.72)],3.3),
([(.80,.64),(.77,.69),(.68,.77),(.63,.80)],3.5),
([(.73,.72),(.66,.79),(.61,.89),(.49,.91)],4.0),
([(.64,.66),(.60,.69),(.56,.79),(.40,.84)],4.2),
([(.80,.64),(.85,.72),(.89,.77),(.94,.86)],4.4),
([(.72,.73),(.77,.88),(.81,.88),(.86,.94)],4.6),
([(.63,.80),(.58,.88),(.36,.86),(.29,.94)],4.8),
([(.73,.72),(.72,.84),(.65,.90),(.62,.98)],5.0),
]
paths=[(curve(c),delay) for c,delay in specs]
stars=[(random.uniform(.49,.91)*W,random.uniform(.06,.94)*H,random.random()*math.tau) for _ in range(32)]
p=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','motion-work/connections.mp4'],stdin=subprocess.PIPE)
for frame in range(FPS*SECONDS):
 t=frame/FPS;fade=min(1,t/.7)*min(1,max(0,(12-t)/1.6)); layer=Image.new('RGB',(W,H));d=ImageDraw.Draw(layer)
 for idx,(points,delay) in enumerate(paths):
  elapsed=t-delay
  if elapsed<0:continue
  reveal=min(1,elapsed/1.8);count=max(2,int(len(points)*reveal));strength=int(38*fade)
  d.line(points[:count],fill=(strength,int(strength*.77),int(strength*.35)),width=1)
  # Two staggered impulses have explicit directional tails.
  for offset in (0,1.65):
   e=elapsed-offset
   if e<0:continue
   phase=(e%3.4)/2.4
   if phase>1:continue
   at=int(phase*99);tail=max(0,at-17)
   for k in range(tail,at):
    gain=((k-tail+1)/(at-tail+1))**1.5*fade
    color=(int(235*gain),int(207*gain),int((118 if idx<10 else 161)*gain))
    d.line([points[k],points[k+1]],fill=color,width=2)
   x,y=points[at];r=2.3
   d.ellipse((x-r,y-r,x+r,y+r),fill=(int(255*fade),int(246*fade),int(206*fade)))
  x,y=points[-1]
  arrived=max(0,elapsed-2.1)
  if arrived>0:
   q=(.4+.6*max(0,math.sin(arrived*2.0+idx))) *fade
   d.ellipse((x-1.7,y-1.7,x+1.7,y+1.7),fill=(int(210*q),int(227*q),int(151*q)))
 # Initial thought: a soft breathing node before the scene is visible.
 q=min(1,t/.7)*min(1,max(0,(12-t)/1.6))*(.6+.4*math.sin(t*2.2)**2)
 x,y=.72*W,.23*H;r=2.8+math.sin(t*2)*.5
 d.ellipse((x-r,y-r,x+r,y+r),fill=(int(250*q),int(230*q),int(169*q)))
 for x,y,phase in stars:
  a=max(0,math.sin(t*.9+phase))**10*min(1,max(0,(t-3)/3))*fade
  if a>.02:d.ellipse((x-1,y-1,x+1,y+1),fill=(int(170*a),int(190*a),int(134*a)))
 # Soft halos around the same procedural geometry.
 glow=layer.filter(ImageFilter.GaussianBlur(4));halo=layer.filter(ImageFilter.GaussianBlur(10))
 from PIL import ImageChops
 out=ImageChops.add(ImageChops.add(layer,glow,1),halo,1)
 p.stdin.write(out.tobytes())
p.stdin.close();code=p.wait()
if code:raise SystemExit(code)
print('Rendered 360 frames of directional connection graphics')
