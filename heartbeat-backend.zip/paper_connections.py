"""Read-only checklist from current worker evidence; never forces a trade."""
import os,time
from datetime import datetime

def check(worker,report,now=None):
    now=time.time() if now is None else now
    checks=[]
    def add(name,state,detail):checks.append({'name':name,'state':state,'detail':detail})
    add('Paper credentials','CONFIGURED' if worker.key and worker.secret else 'BLOCKED','Both keys are present; successful broker access is checked separately.' if worker.key and worker.secret else 'Set ALPACA_API_KEY and ALPACA_SECRET_KEY in Render. Use paper-account keys.')
    add('Worker enabled','READY' if worker.enabled else 'BLOCKED','Server paper worker enabled.' if worker.enabled else 'Set HB_CRYPTO_PAPER_ENABLED=true in Render.')
    mounted=os.path.ismount('/var/data') and os.path.realpath(worker.path).startswith('/var/data/')
    add('Persistent disk','READY' if mounted else 'BLOCKED','Mounted /var/data storage found.' if mounted else 'Attach a persistent disk at /var/data and use HB_CRYPTO_DB_PATH=/var/data/crypto-paper.sqlite3.')
    started=bool(report.get('worker_started'));tick=report.get('last_tick');fresh=isinstance(tick,(int,float)) and 0<=now-tick<=120
    error=report.get('error')
    advice={'ALPACA_KEYS_MISSING':'Set both Alpaca paper keys in Render.','AUTH_REJECTED':'Replace rejected credentials with keys from the Alpaca paper account.','PAPER_ACCESS_DENIED':'Check Alpaca paper-account access; this does not require the premium options feed.','DEDICATED_PAPER_ACCOUNT_REQUIRED':'Use a dedicated paper account without unrelated positions. No holdings will be silently sold.','UNMANAGED_OPEN_ORDERS':'Review unrelated open orders in Alpaca. Heartbeat will not cancel them automatically.','PERSISTENT_DISK_REQUIRED':'Mount a persistent disk at /var/data.','STORAGE_OR_SINGLE_WORKER_LOCK_FAILED':'Check the disk, source-version migration, and that Gunicorn uses one worker.','REQUEST_UNCERTAIN':'Broker response uncertain. Let reconciliation run; do not resubmit the order.','POSITION_OR_FEE_QUANTITY_MISMATCH':'Reconcile the broker quantity and fee difference before resuming.'}
    add('Worker health','BLOCKED' if error else 'READY' if started and fresh else 'WAITING',advice.get(error,'Worker reports '+str(error)+'. Review the technical report before resuming.') if error else 'Last cycle completed recently.' if started and fresh else 'No recent completed cycle. Check Render deployment and worker settings.')
    view=report.get('latest') or {};review=report.get('guardian') or view.get('guardian');checked=review.get('checked_at') if review else None
    recent_review=isinstance(checked,(int,float)) and 0<=now-checked<=120
    add('Broker / Guardian cycle','VERIFIED' if recent_review and not error else 'UNVERIFIED','Account, assets and owned-position reconciliation completed before this recorded review.' if recent_review and not error else 'No recent successful full broker/Guardian cycle is available.')
    for symbol in ('BTC/USD','ETH/USD'):
        q=view.get('quotes',{}).get(symbol);age=None
        try:age=now-datetime.fromisoformat(q['t'].replace('Z','+00:00')).timestamp()
        except (TypeError,KeyError,ValueError):pass
        valid=age is not None and 0<=age<=15
        add(symbol+' quote','RECENT' if valid else 'WAITING',f'Observed quote age: {age:.0f}s. It is rechecked before an order.' if age is not None else 'No timestamped quote loaded. The worker fetches fresh quotes each cycle.')
    state=report.get('state') or {};reason=view.get('reason') or 'No completed decision.'
    add('Paper entry state','PAUSED' if state.get('paused') else 'WAITING',('New entries paused. Fix the reported issue, then use Resume paper experiment. Existing exits and reconciliation continue.' if state.get('paused') else str(reason).replace('_',' ').lower()+'. One entry/day, warm-up and eligibility limits still apply.'))
    return {'checked_at':now,'checks':checks,'scope':'Read-only diagnostics. Configuration is not proof of broker access; fresh review is not proof of a fill. US options and Binance feeds are not required for this Alpaca crypto experiment.','forced_trade':False}
