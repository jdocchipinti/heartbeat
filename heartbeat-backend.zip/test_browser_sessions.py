import importlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest
from unittest.mock import patch
import browser_sessions as sessions
import server

class SessionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=self.tmp.name+'/sessions.sqlite3'
        self.patches=[patch.object(server,'TOKEN','test-'+'x'*40),patch.object(server,'SESSION_DB',self.db),patch.object(server,'ensure_started')]
        for p in self.patches:p.start()

    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.tmp.cleanup()

    def call(self,path='/api/session',method='GET',cookie='',auth='',origin=None,secure=True,query=''):
        env={'PATH_INFO':path,'REQUEST_METHOD':method,'HTTP_HOST':'heartbeat.example','wsgi.url_scheme':'https' if secure else 'http','HTTP_COOKIE':cookie,'HTTP_AUTHORIZATION':auth,'QUERY_STRING':query}
        if origin is not None:env['HTTP_ORIGIN']=origin
        out={}
        def start(status,headers):out.update(status=status,headers=dict(headers))
        out['body']=json.loads(b''.join(server.application(env,start)))
        return out

    def login(self,remember=True,cookie=''):
        r=self.call('/api/session/login','POST',auth='Bearer '+server.TOKEN,origin='https://heartbeat.example',query='remember=1' if remember else '',cookie=cookie)
        self.assertEqual(r['status'],'200 OK')
        return r,r['headers']['Set-Cookie'].split(';')[0]

    def test_remember_cookie_and_restart_recovery(self):
        r,cookie=self.login()
        for attr in ('Secure','HttpOnly','SameSite=Strict','Path=/','Max-Age=2592000'):self.assertIn(attr,r['headers']['Set-Cookie'])
        self.assertNotIn('Domain=',r['headers']['Set-Cookie'])
        self.assertNotIn(server.TOKEN,cookie)
        self.assertNotIn(cookie.split('=')[1],Path(self.db).read_bytes().decode('latin1'))
        importlib.reload(sessions)
        self.assertTrue(self.call(cookie=cookie)['body']['authenticated'])
        self.assertEqual(self.call('/api/us/status',cookie=cookie)['status'],'200 OK')

    def test_session_cookie_not_persistent(self):
        r,c=self.login(False)
        self.assertNotIn('Max-Age',r['headers']['Set-Cookie'])
        self.assertAlmostEqual(r['body']['expires_at']-time.time(),12*3600,delta=2)

    def test_expired_tampered_and_rotated_token(self):
        r,c=self.login()
        self.assertFalse(self.call(cookie=c+'bad')['body']['authenticated'])
        with patch.object(server,'TOKEN','z'*40):self.assertFalse(self.call(cookie=c)['body']['authenticated'])
        with patch.object(sessions.time,'time',return_value=r['body']['expires_at']+1):
            self.assertFalse(self.call(cookie=c)['body']['authenticated'])
            self.assertEqual(self.call('/api/us/status',cookie=c)['status'],'401 Unauthorized')

    def test_logout_revokes_and_relogin_rotates(self):
        _,old=self.login();_,new=self.login(cookie=old)
        self.assertFalse(self.call(cookie=old)['body']['authenticated'])
        r=self.call('/api/session/logout','POST',cookie=new,origin='https://heartbeat.example')
        self.assertEqual(r['status'],'200 OK');self.assertIn('Max-Age=0',r['headers']['Set-Cookie'])
        self.assertFalse(self.call(cookie=new)['body']['authenticated'])

    def test_csrf_rejected_for_all_cookie_mutations(self):
        _,c=self.login()
        for origin in (None,'null','https://evil.example','https://sibling.heartbeat.example'):
            for path in ('/api/session/login','/api/session/logout','/api/crypto/pause','/api/crypto/resume','/api/options/check','/api/storage/check','/api/research/run'):
                self.assertEqual(self.call(path,'POST',cookie=c,origin=origin)['status'],'403 Forbidden',path)
        with patch.object(server.CRYPTO,'enabled',True),patch.object(server.CRYPTO,'started',True),patch.object(server.CRYPTO,'pause') as pause,patch.object(server.CRYPTO,'status',return_value={'execution_enabled':False}):
            self.assertEqual(self.call('/api/crypto/pause','POST',cookie=c,origin='https://heartbeat.example')['status'],'200 OK');pause.assert_called_once_with(True)

    def test_bad_login_http_and_missing_storage_fail_closed(self):
        self.assertEqual(self.call('/api/session/login','POST',auth='Bearer wrong',origin='https://heartbeat.example')['status'],'401 Unauthorized')
        self.assertEqual(self.call('/api/session/login','GET')['status'],'405 Method Not Allowed')
        self.assertEqual(self.call(secure=False)['status'],'403 Forbidden')
        self.assertFalse(self.call()['body']['authenticated'])
        _,c=self.login()
        with patch.object(server,'SESSION_DB',self.tmp.name+'/absent/sessions.sqlite3'):
            self.assertEqual(self.call(cookie=c)['status'],'503 Service Unavailable')
            self.assertEqual(self.call('/api/us/status',cookie=c)['status'],'503 Service Unavailable')

    def test_bearer_compatibility(self):
        self.assertEqual(self.call('/api/us/status',auth='Bearer '+server.TOKEN)['status'],'200 OK')
        self.assertEqual(self.call('/api/us/status')['status'],'401 Unauthorized')
        self.assertEqual(self.call('/api/order','POST',auth='Bearer '+server.TOKEN)['status'],'405 Method Not Allowed')
