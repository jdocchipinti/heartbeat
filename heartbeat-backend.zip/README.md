# Heartbeat — options access and evidence storage


## New options access check

After uploading this replacement ZIP and deployment, connect in US Charts with the existing
HB_ACCESS_TOKEN. Open Evidence and select **Check historical options access**. This tests
MASSIVE_API_KEY on this server, independently of the chat connector. It retrieves the expired
SPY June 20, 2025 $600 call reference as of June 2 and two small June 2 historical bid/ask
windows. A successful reference lookup does not establish quote access. Empty windows,
entitlement failures and truncated results are displayed explicitly. This is a narrow access
probe, not a full history coverage audit or a qualifying historical trade.

On September 17, 2026 the chat connector returned the expired contract but its historical
quote request returned NOT_ENTITLED. No historical quote-based performance is claimed.
The server key may have different permissions. Check before buying a data subscription.

The long-option execution model uses timestamped quotes available at modeled order arrival:
entry at ask plus slippage; exit at bid minus slippage; tick rounding and fees on both sides.
Default assumptions are 500 ms latency, $0.01/share slippage per side, $0.65/contract/side fees,
2-second maximum quote age and 20% maximum spread. They require venue/account calibration.
It rejects incomplete history, future/stale/crossed quotes, insufficient displayed size,
limit-price violations, nonstandard multipliers and expiry violations. A displayed quote is
not a guaranteed fill. Theta is already included in observed option-price changes.

The fixed diagnostic uses one contract, a $0.03 entry limit and $0.01 exit limit. Most contracts
will fail this deliberately small test. It enforces a $50 budget and $5 full-premium loss bound
including assumed fees; a stop price is not a guaranteed maximum loss. It does not implement
an event eligibility engine, a complete options backtest, exercise/assignment, portfolio
mark-to-market, daily-loss enforcement or order execution. It grants zero readiness credit.

## Durable storage setup — prepared, not provisioned

The new PostgreSQL adapter stores candle revisions, raw historical input snapshots, reports
and access-check evidence. Existing code runs without a database change using temporary
SQLite. No paid database has been created and PostgreSQL connectivity has not been tested.

1. Download your existing historical report before replacing the deployment. Old local SQLite
   and temporary source files are not automatically migrated.
2. Upload this file as exactly **heartbeat-backend.zip** to replace that GitHub file. Keep the
   existing Render service and build/start commands; do not create another web service.
3. To enable durable storage after approving the displayed hosting cost, provision a managed
   PostgreSQL database in the same Render workspace and Virginia region. Put its private
   Internal Database URL into the backend service's **DATABASE_URL** environment variable.
   Never put that URL, a provider API key or access token in GitHub or chat.
4. Redeploy; connect and select Evidence → **Check evidence storage**. Confirm PostgreSQL and
   successful read/write. A configured URL alone is not proof of recovery or backups.
5. Run a new historical pilot, export its report, restart the backend, then refresh Evidence.
   Confirm the same report/run ID is restored and the storage check reads a prior-process
   record. Confirm backup/recovery and retention settings separately in the database dashboard.

With DATABASE_URL set, database failures block persistence instead of silently falling back
to SQLite. The first storage check in each process is cached to preserve restart evidence.
Hashes detect accidental payload changes; they are not an independent audit or tamper-proof
storage. Free web-service sleep still interrupts collection even with a durable database.
The free PostgreSQL offering is time-limited; it is unsuitable as permanent evidence storage.
Capacity, retention, backup recovery tests and always-on collection remain operational work.

Validation: `python3 -m unittest -v test_server.py test_historical_pilot.py test_options_storage.py`.
Local tests cover execution rejections, SQLite reopen/recovery, append protection, entitlement
failure handling and fail-closed database errors. They do not prove a real PostgreSQL deployment.

## Phase 1 upgrade

The Evidence tab now contains a private historical pilot runner. Connect using the existing
backend access token in US Charts, open Evidence, and click Run historical pilot. The service
fetches 2025 daily bars for three ETFs and four crypto pairs, runs frozen rules in three
chronological windows, and retains accepted, rejected and censored observations. This is an
underlying-price pipeline experiment, not an options strategy certification. No parameters
were tuned to improve the first run's results. The prospective rule specification lives in
pilot_config.json; results remain retrospective and not certified untouched out-of-sample.

The report includes cost stress, symbol/regime breakdowns and leave-one-group-out checks.
The serial closed-trade drawdown proxy is explicitly NOT a marked-to-market portfolio risk
measure. Hypothetical trades across different symbols can overlap. No $50 account allocation
or actual tradability is modeled. ETF dividends and total-return reinvestment are not modeled.
Current chosen symbols create selection bias. An assumed net profit is not audited profit.

One successful run is allowed per process to avoid accidental repeated requests. The shared
Massive rate limiter spaces requests by 15 seconds. Live collection may lag during historical
fetches; freshness checks continue to block stale data. A run has a unique directory under
the SQLite parent path. Without PostgreSQL, export its report before a free-host sleep/restart: local storage is not durable.
Failures stay failed; missing inputs are never silently dropped to improve results.

No historical source data or reports are bundled in this deployment ZIP, because the GitHub
repository is public. Each server fetches its own inputs privately with its configured key.
The raw input format, rule file and runner permit local reproduction. The separately delivered
private research archive contains the first run's source snapshots, ledger and report.

Update the existing GitHub file named heartbeat-backend.zip with this ZIP. Render auto-deploys
the backend with the existing commands; no environment changes or paid upgrades are needed.
The older static site's index (2).html remains a separate deployment source.

Run all checks with `python3 -m unittest -v test_server.py test_historical_pilot.py`.

This is a private read-only research backend, plus the complete dashboard.
It does not place orders, establish an edge, or increment
historical/paper/shadow readiness counts.

## Deploy from the existing GitHub repository

1. Upload `heartbeat-backend.zip` to the root of jdocchipinti/heartbeat. Keep that exact filename.
2. Create a **new Python Web Service** on Render from that repository, branch `main`.
   The existing static site remains available.
3. Build command:

   `unzip -o heartbeat-backend.zip -d service && pip install -r service/requirements.txt`

4. Start command:

   `gunicorn --chdir service --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 30 server:application`

5. Health check: `/healthz`. Use a Free instance for the initial connectivity test only.
6. In **Render → Environment**, set:
   - `MASSIVE_API_KEY`: your own Massive dashboard API key, with stocks minute-bar access.
   - `HB_ACCESS_TOKEN`: a separate random secret with at least 32 characters. Generate it in a password manager. This is the only token entered in the website's private feed panel.
   - Optional `HB_SYMBOLS`: defaults to `QQQ,SPY,GLD`. Supported additions: TLT, IEF, IWM, HYG, AAPL, MSFT, NVDA, AMZN, TSLA. More symbols mean a longer cycle.
   - Optional `HB_POLL_SECONDS`: defaults to 90, minimum 90.
   - Optional `HB_DB_PATH`: defaults to `/tmp/heartbeat.sqlite3`. For approved persistent-disk deployments, use a path inside the actual disk mount; setting a path alone does not make it durable.
7. Open the new backend URL → **06 · US Charts**. The backend URL field prefills on the backend-hosted page. Enter your **HB_ACCESS_TOKEN**, then Connect backend. Never enter your Massive key in the page or in chat.

Gunicorn must run **one worker**: the collector cache and launch guard are process-local.
The service has no secrets in this archive. No credentials from the chat plugin transfer automatically.
This package does not change the live static site's source file or Render configuration.
To use the new desk at the old static URL, upload this archive's index.html under the existing
configured source filename `index (2).html`. Enter the separate backend URL in its US chart desk.

## What it does

- Polls Massive REST for unadjusted one-minute bars. It asks for the most recent 120 bars within seven calendar days, not a full historical backfill.
- Polls provider market status rather than guessing holidays from weekdays. Extended hours remain research-blocked in this version.
- Validates OHLCV, completed timestamps, duplicates and gaps. Missing intervals stay missing.
- Keeps shared server-side caches; browser refresh does not issue upstream calls. Upstream requests are spaced by at least 15 seconds, with a cycle of at least 90 seconds. Rate-limit and entitlement errors block current research and retry on the next cycle.
- Stores first-observed bar revisions in PostgreSQL when configured, otherwise SQLite, retaining corrections and reversions. Identical repeated bars are not duplicated. Exports at most the latest 2,000 revision records per symbol, with the limit disclosed.
- Records provider request IDs and receipt times. This is not a tamper-proof or independently audited ledger. Historical bars fetched now were not necessarily known at their original timestamp; observed_at is when this service saw them.
- Calculates descriptive volume, SMA, ATR and VWAP metrics. No buyer-volume inference. Stockholm blocks liquidity judgments without quotes; Professor is deterministic. These outputs remain separate from the crypto orbit and readiness gates.
- Protects all market data API endpoints with the separate access token. The HTML and process health are public. CORS permits the existing static-site origin; same-origin backend use also works. No secrets are stored in browser storage. Data-use and display rights must match your Massive agreement; public hosting does not grant redistribution rights.

## Actual limits

This is REST polling, **not tick streaming**. Fresh timestamps do not certify real-time entitlements.
The three-minute freshness threshold is only a research data check, not acceptable order-price latency.
The default collector can take about a minute after startup to fetch all three symbols.

Free Render sleeps after inactivity, may cold-start slowly, and loses local SQLite on sleep/restart/redeploy.
It cannot establish uninterrupted collection or durable evidence. An always-on instance plus durable
storage requires a separate cost decision; no paid resources are authorized by this package.
Storage capacity/retention and backups must be configured before sustained collection. API errors,
market closure and absent quotes keep research or execution blocked; they do not produce substitute data.

Tests: `python3 -m unittest -v test_server.py`.
Local-only development: `python3 server.py` (127.0.0.1:8000). Production uses Gunicorn above.

## Verification so far

The chat connector returned QQQ minute bars and market status on 2026-09-17.
Its newest sampled bar began 2026-09-16 23:59 UTC, so this was historical data, not a live-price proof.
Backend key authentication, account-specific delay, Render deployment and browser rendering still
need end-to-end verification after the user's secrets and repository upload are in place.

References:
- https://massive.com/docs/rest/quickstart
- https://massive.com/docs/rest/stocks/aggregates/custom-bars
- https://render.com/docs/free

## Next production milestones

Verify timestamp age under the actual plan during a regular session; choose durable storage and
uptime; add bid/ask quotes and contract data with the proper entitlements; connect US outputs to
the orbit; add reconnect/backfill recovery and retention monitoring. Only then evaluate historical,
out-of-sample, paper and shadow-account gates. Brokerage execution remains absent.

## Agent feed routing

Connect the existing private backend in US Charts, choose the instrument, then in Overview
set Agent data source to Private US backend. The five agent cards and orbit inspector now
consume the same verified response as the candles. Browser cache refresh is every 15 seconds;
provider collection remains rate-limited REST polling (at least 90 seconds per cycle), not a
tick stream. Real-time entitlement remains unverified. Responses older than 45 seconds and
completed candles older than 180 seconds are visibly blocked. Disconnect and symbol changes
clear the active observation; failed requests mark it unusable. Professor aggregates the four
module statuses. Stockholm reports missing quotes, never simulated liquidity. Crypto spot
mode retains its separate public-feed connection and readiness checks. No options permission,
subscription, continuous uptime or durable-storage claim is added by this UI integration.

## Customer journey and mobile web update — September 22, 2026

The app now opens on Today, with a five-destination navigation: Today, Markets, Agents,
Practice and Account. Mobile uses bottom navigation and responsive layouts; wide research
tables scroll within their containers. Existing charts, agents, historical checks, scenarios,
news and education remain accessible through section tabs and All research tools. Technical
records are expandable. Today derives connection status from this browser session; it does
not invent holdings, returns or readiness.

Account explains planned Robinhood integration, unsupported Cash App trading access and the
recommended broker-held funding path. No account authentication, payment, deposit, custody,
withdrawal or order endpoint has been added. Public Cash App Pay documentation describes
merchant checkout, not a verified investing API. Robinhood's official agent setup guidance
currently requires desktop onboarding. These references were checked September 22, 2026.
This is responsive mobile web, not a native app or background alert service.

Deploy by replacing the same heartbeat-backend.zip filename; no environment changes required.
The separate static site only updates when its configured HTML source is replaced too.

## Decision journal — September 24, 2026

Agents now opens on Decisions. After deployment, connect the private backend, wait for a
successful SPY or QQQ collector cycle, and open Agents → Decisions. The authenticated
GET /api/decisions endpoint returns the latest 100 stored records and linked outcomes.
Refresh/export are read-only. The collector, not page refresh, creates observations.
No broker orders, paper fills or quote entitlements are added by this upgrade.

The collector samples current completed candles at its existing polling cadence, not every
market event. Each decision retains its initial input snapshot, collection/evaluation times,
config/runner hashes, initial four specialist assessments and subsequent Professor review.
Initial modules receive raw inputs without peer outputs. These are separate deterministic
rules, not independent predictive models. Repeated identical inputs retain the first record;
changed input revisions create another record. Subsequent review never mutates initials.
The source code and experiment configuration are stored with the experiment artifact.

A follow-up observes the exact underlying bar closing five minutes after the decision time
rounded up to a minute. The comparison uses the original snapshot's latest close. It is a
counterfactual underlying observation, not a fill, option return, benchmark return or win.
Missing bars stay pending. Up to the latest 500 pending records are considered per collector
cycle; older pending items can remain unresolved. Outcomes append as separate artifacts;
later provider corrections do not silently overwrite them. No tamper-proof or external-audit
claim is made. SHA checks detect corruption, not a privileged attacker rewriting hashes.

The versioned experiment defines two underlyings and a fixed candle watch rule. The options
selection is a planned specification, not an executable strategy. Quotes, event eligibility,
full order lifecycle, mark-to-market drawdown, benchmark and agent ablation runners remain
unimplemented. Drawdown acceptance must be preregistered before qualification. No experiment
completion, out-of-sample success or readiness credit is claimed. Strategy revisions require
a new config/version and new evidence. All displayed metrics and records remain research.

SQLite persists only within the existing host lifecycle. Configure PostgreSQL and verify
restart recovery and backups before claiming durable evidence. No paid resource was created.

Tests: python3 -m unittest discover -p 'test_*.py'

## Shared evidence and bounded agent review

The SPY/QQQ decision journal now includes HB-REVIEW-001. Five deterministic
initial assessments are frozen before one review round routes seven targeted
messages. Every message references evidence and claim IDs. The limit is eight
unique messages and one round. Professor records the resolution; missing
options quotes, event coverage and validation continue to block eligibility.

Candles are shared by content ID. Exact duplicate evidence and messages are
collapsed. Multiple agents using one provider do not establish independent
corroboration. News ingestion and syndication detection are not implemented in
this protocol. This is local rule-based routing, not five autonomous LLM calls.
It makes no additional market requests or model calls.

Open Agents → Decisions → See the agents’ review. The orbit button displays
that recorded exchange and highlights a selected message's recipients. These
are historical records, not live traffic animations. Return to current inputs
exits the recorded view; disconnect clears it. Older records remain unchanged.

Feed health, analysis completion and trade eligibility are distinct. Paired
before/after decision labels are available, but collaboration's effect on
profits, missed opportunities and execution costs has not been measured.
The review source is included in the runner digest and experiment artifact.
Durable storage and historical quote entitlements remain separate prerequisites.

## Free research mode (Alpaca)

ALPACA_API_KEY and ALPACA_SECRET_KEY remain in Render Environment. No new
settings or subscription are required by this update. The collector now always
requests feed=indicative for SPY/QQQ snapshots every 90 seconds. It never
requests current premium OPRA snapshots. Indicative quotes are modified prices,
not executable quotes: recent_valid_quote stays false, execution modeling is
disabled, and readiness credit remains zero. Freshness is exposed separately
as recent_indicative_observation. Massive collection is unchanged.

Open Agents → Decisions → Free research mode · Alpaca. Refresh free research
status shows the Alpaca collector and the existing Massive quote-access result.
Check Massive historical quote access triggers the original bounded Massive
probe (one expired contract and two quote windows). It does not buy anything.

At collector startup, once per process, Alpaca tests two documented historical
endpoints: bars and trades for SPY250620C00600000 on June 2, 2025, 14:00–15:00 UTC.
Each is limited to 100 observations, with pagination explicitly disclosed.
Success means only sample retrieval, not independently audited data or broad
coverage. Empty data is distinct from denied access. There is no historical
bid/ask claim for these bars/trades. Results and samples use the existing
storage adapter; process restarts repeat the probe. Missing credentials keep
it unstarted. Account-specific access is not known until deployed requests run.

The source samples and status are private behind HB_ACCESS_TOKEN. Errors are
sanitized. No credential is embedded in this package. No account/order API is
called. These feeds remain separate from the frozen decision experiment.
SQLite persistence is still unverified unless durable storage is configured;
continuous collection needs storage-capacity monitoring. Free hosting can sleep.
