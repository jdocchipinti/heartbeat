# Heartbeat US candle backend — first connection build

This is a private read-only research backend, plus the complete dashboard.
It does not place orders, collect options quotes, establish an edge, or increment
historical/paper/shadow readiness counts.

## Deploy from the existing GitHub repository

1. Upload `heartbeat-backend.zip` to the root of jdocchipinti/heartbeat. Keep that exact filename.
2. Create a **new Python Web Service** on Render from that repository, branch `main`.
   The existing static site remains available.
3. Build command:

   `unzip -o heartbeat-backend.zip -d service && pip install -r service/requirements.txt`

4. Start command:

   `gunicorn --chdir service --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 30 server:application`

5. Health check: `/healthz`. Use a Free instance for the initial connectivity test only.
6. In **Render → Environment**, set:
   - `MASSIVE_API_KEY`: your own Massive dashboard API key, with stocks minute-bar access.
   - `HB_ACCESS_TOKEN`: a separate random secret with at least 32 characters. Generate it in a password manager. This is the only token entered in the website's private feed panel.
   - Optional `HB_SYMBOLS`: defaults to `QQQ,SPY,GLD`. Supported additions: TLT, IEF, IWM, HYG, AAPL, MSFT, NVDA, AMZN, TSLA. More symbols mean a longer cycle.
   - Optional `HB_POLL_SECONDS`: defaults to 90, minimum 90.
   - Optional `HB_DB_PATH`: defaults to `/tmp/heartbeat.sqlite3`. For approved persistent-disk deployments, use a path inside the actual disk mount; setting a path alone does not make it durable.
7. Open the new backend URL → **06 · US Charts**. The backend URL field prefills on the backend-hosted page. Enter your **HB_ACCESS_TOKEN**, then Connect backend. Never enter your Massive key in the page or in chat.

Gunicorn must run **one worker**: the collector cache and launch guard are process-local.
The service has no secrets in this archive. No credentials from the chat plugin transfer automatically.
This package does not change the live static site's source file or Render configuration.
To use the new desk at the old static URL, upload this archive's index.html under the existing
configured source filename `index (2).html`. Enter the separate backend URL in its US chart desk.

## What it does

- Polls Massive REST for unadjusted one-minute bars. It asks for the most recent 120 bars within seven calendar days, not a full historical backfill.
- Polls provider market status rather than guessing holidays from weekdays. Extended hours remain research-blocked in this version.
- Validates OHLCV, completed timestamps, duplicates and gaps. Missing intervals stay missing.
- Keeps shared server-side caches; browser refresh does not issue upstream calls. Upstream requests are spaced by at least 15 seconds, with a cycle of at least 90 seconds. Rate-limit and entitlement errors block current research and retry on the next cycle.
- Stores first-observed bar revisions in SQLite, retaining corrections and reversions. Identical repeated bars are not duplicated. Exports at most the latest 2,000 revision records per symbol, with the limit disclosed.
- Records provider request IDs and receipt times. This is not a tamper-proof or independently audited ledger. Historical bars fetched now were not necessarily known at their original timestamp; observed_at is when this service saw them.
- Calculates descriptive volume, SMA, ATR and VWAP metrics. No buyer-volume inference. Stockholm blocks liquidity judgments without quotes; Professor is deterministic. These outputs remain separate from the crypto orbit and readiness gates.
- Protects all market data API endpoints with the separate access token. The HTML and process health are public. CORS permits the existing static-site origin; same-origin backend use also works. No secrets are stored in browser storage. Data-use and display rights must match your Massive agreement; public hosting does not grant redistribution rights.

## Actual limits

This is REST polling, **not tick streaming**. Fresh timestamps do not certify real-time entitlements.
The three-minute freshness threshold is only a research data check, not acceptable order-price latency.
The default collector can take about a minute after startup to fetch all three symbols.

Free Render sleeps after inactivity, may cold-start slowly, and loses local SQLite on sleep/restart/redeploy.
It cannot establish uninterrupted collection or durable evidence. An always-on instance plus durable
storage requires a separate cost decision; no paid resources are authorized by this package.
Storage capacity/retention and backups must be configured before sustained collection. API errors,
market closure and absent quotes keep research or execution blocked; they do not produce substitute data.

Tests: `python3 -m unittest -v test_server.py`.
Local-only development: `python3 server.py` (127.0.0.1:8000). Production uses Gunicorn above.

## Verification so far

The chat connector returned QQQ minute bars and market status on 2026-09-17.
Its newest sampled bar began 2026-09-16 23:59 UTC, so this was historical data, not a live-price proof.
Backend key authentication, account-specific delay, Render deployment and browser rendering still
need end-to-end verification after the user's secrets and repository upload are in place.

References:
- https://massive.com/docs/rest/quickstart
- https://massive.com/docs/rest/stocks/aggregates/custom-bars
- https://render.com/docs/free

## Next production milestones

Verify timestamp age under the actual plan during a regular session; choose durable storage and
uptime; add bid/ask quotes and contract data with the proper entitlements; connect US outputs to
the orbit; add reconnect/backfill recovery and retention monitoring. Only then evaluate historical,
out-of-sample, paper and shadow-account gates. Brokerage execution remains absent.
