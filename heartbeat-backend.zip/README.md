# Heartbeat — options access and evidence storage


## New options access check

After uploading this replacement ZIP and deployment, connect in US Charts with the existing
HB_ACCESS_TOKEN. Open Evidence and select **Check historical options access**. This tests
MASSIVE_API_KEY on this server, independently of the chat connector. It retrieves the expired
SPY June 20, 2025 $600 call reference as of June 2 and two small June 2 historical bid/ask
windows. A successful reference lookup does not establish quote access. Empty windows,
entitlement failures and truncated results are displayed explicitly. This is a narrow access
probe, not a full history coverage audit or a qualifying historical trade.

On September 17, 2026 the chat connector returned the expired contract but its historical
quote request returned NOT_ENTITLED. No historical quote-based performance is claimed.
The server key may have different permissions. Check before buying a data subscription.

The long-option execution model uses timestamped quotes available at modeled order arrival:
entry at ask plus slippage; exit at bid minus slippage; tick rounding and fees on both sides.
Default assumptions are 500 ms latency, $0.01/share slippage per side, $0.65/contract/side fees,
2-second maximum quote age and 20% maximum spread. They require venue/account calibration.
It rejects incomplete history, future/stale/crossed quotes, insufficient displayed size,
limit-price violations, nonstandard multipliers and expiry violations. A displayed quote is
not a guaranteed fill. Theta is already included in observed option-price changes.

The fixed diagnostic uses one contract, a $0.03 entry limit and $0.01 exit limit. Most contracts
will fail this deliberately small test. It enforces a $50 budget and $5 full-premium loss bound
including assumed fees; a stop price is not a guaranteed maximum loss. It does not implement
an event eligibility engine, a complete options backtest, exercise/assignment, portfolio
mark-to-market, daily-loss enforcement or order execution. It grants zero readiness credit.

## Durable storage setup — prepared, not provisioned

The new PostgreSQL adapter stores candle revisions, raw historical input snapshots, reports
and access-check evidence. Existing code runs without a database change using temporary
SQLite. No paid database has been created and PostgreSQL connectivity has not been tested.

1. Download your existing historical report before replacing the deployment. Old local SQLite
   and temporary source files are not automatically migrated.
2. Upload this file as exactly **heartbeat-backend.zip** to replace that GitHub file. Keep the
   existing Render service and build/start commands; do not create another web service.
3. To enable durable storage after approving the displayed hosting cost, provision a managed
   PostgreSQL database in the same Render workspace and Virginia region. Put its private
   Internal Database URL into the backend service's **DATABASE_URL** environment variable.
   Never put that URL, a provider API key or access token in GitHub or chat.
4. Redeploy; connect and select Evidence → **Check evidence storage**. Confirm PostgreSQL and
   successful read/write. A configured URL alone is not proof of recovery or backups.
5. Run a new historical pilot, export its report, restart the backend, then refresh Evidence.
   Confirm the same report/run ID is restored and the storage check reads a prior-process
   record. Confirm backup/recovery and retention settings separately in the database dashboard.

With DATABASE_URL set, database failures block persistence instead of silently falling back
to SQLite. The first storage check in each process is cached to preserve restart evidence.
Hashes detect accidental payload changes; they are not an independent audit or tamper-proof
storage. Free web-service sleep still interrupts collection even with a durable database.
The free PostgreSQL offering is time-limited; it is unsuitable as permanent evidence storage.
Capacity, retention, backup recovery tests and always-on collection remain operational work.

Validation: `python3 -m unittest -v test_server.py test_historical_pilot.py test_options_storage.py`.
Local tests cover execution rejections, SQLite reopen/recovery, append protection, entitlement
failure handling and fail-closed database errors. They do not prove a real PostgreSQL deployment.

## Phase 1 upgrade

The Evidence tab now contains a private historical pilot runner. Connect using the existing
backend access token in US Charts, open Evidence, and click Run historical pilot. The service
fetches 2025 daily bars for three ETFs and four crypto pairs, runs frozen rules in three
chronological windows, and retains accepted, rejected and censored observations. This is an
underlying-price pipeline experiment, not an options strategy certification. No parameters
were tuned to improve the first run's results. The prospective rule specification lives in
pilot_config.json; results remain retrospective and not certified untouched out-of-sample.

The report includes cost stress, symbol/regime breakdowns and leave-one-group-out checks.
The serial closed-trade drawdown proxy is explicitly NOT a marked-to-market portfolio risk
measure. Hypothetical trades across different symbols can overlap. No $50 account allocation
or actual tradability is modeled. ETF dividends and total-return reinvestment are not modeled.
Current chosen symbols create selection bias. An assumed net profit is not audited profit.

One successful run is allowed per process to avoid accidental repeated requests. The shared
Massive rate limiter spaces requests by 15 seconds. Live collection may lag during historical
fetches; freshness checks continue to block stale data. A run has a unique directory under
the SQLite parent path. Without PostgreSQL, export its report before a free-host sleep/restart: local storage is not durable.
Failures stay failed; missing inputs are never silently dropped to improve results.

No historical source data or reports are bundled in this deployment ZIP, because the GitHub
repository is public. Each server fetches its own inputs privately with its configured key.
The raw input format, rule file and runner permit local reproduction. The separately delivered
private research archive contains the first run's source snapshots, ledger and report.

Update the existing GitHub file named heartbeat-backend.zip with this ZIP. Render auto-deploys
the backend with the existing commands; no environment changes or paid upgrades are needed.
The older static site's index (2).html remains a separate deployment source.

Run all checks with `python3 -m unittest -v test_server.py test_historical_pilot.py`.

This is a private read-only research backend, plus the complete dashboard.
It does not place orders, establish an edge, or increment
historical/paper/shadow readiness counts.

## Deploy from the existing GitHub repository

1. Upload `heartbeat-backend.zip` to the root of jdocchipinti/heartbeat. Keep that exact filename.
2. Create a **new Python Web Service** on Render from that repository, branch `main`.
   The existing static site remains available.
3. Build command:

   `unzip -o heartbeat-backend.zip -d service && pip install -r service/requirements.txt`

4. Start command:

   `gunicorn --chdir service --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 30 server:application`

5. Health check: `/healthz`. Use a Free instance for the initial connectivity test only.
6. In **Render → Environment**, set:
   - `MASSIVE_API_KEY`: your own Massive dashboard API key, with stocks minute-bar access.
   - `HB_ACCESS_TOKEN`: a separate random secret with at least 32 characters. Generate it in a password manager. This is the only token entered in the website's private feed panel.
   - Optional `HB_SYMBOLS`: defaults to `QQQ,SPY,GLD`. Supported additions: TLT, IEF, IWM, HYG, AAPL, MSFT, NVDA, AMZN, TSLA. More symbols mean a longer cycle.
   - Optional `HB_POLL_SECONDS`: defaults to 90, minimum 90.
   - Optional `HB_DB_PATH`: defaults to `/tmp/heartbeat.sqlite3`. For approved persistent-disk deployments, use a path inside the actual disk mount; setting a path alone does not make it durable.
7. Open the new backend URL → **06 · US Charts**. The backend URL field prefills on the backend-hosted page. Enter your **HB_ACCESS_TOKEN**, then Connect backend. Never enter your Massive key in the page or in chat.

Gunicorn must run **one worker**: the collector cache and launch guard are process-local.
The service has no secrets in this archive. No credentials from the chat plugin transfer automatically.
This package does not change the live static site's source file or Render configuration.
To use the new desk at the old static URL, upload this archive's index.html under the existing
configured source filename `index (2).html`. Enter the separate backend URL in its US chart desk.

## What it does

- Polls Massive REST for unadjusted one-minute bars. It asks for the most recent 120 bars within seven calendar days, not a full historical backfill.
- Polls provider market status rather than guessing holidays from weekdays. Extended hours remain research-blocked in this version.
- Validates OHLCV, completed timestamps, duplicates and gaps. Missing intervals stay missing.
- Keeps shared server-side caches; browser refresh does not issue upstream calls. Upstream requests are spaced by at least 15 seconds, with a cycle of at least 90 seconds. Rate-limit and entitlement errors block current research and retry on the next cycle.
- Stores first-observed bar revisions in PostgreSQL when configured, otherwise SQLite, retaining corrections and reversions. Identical repeated bars are not duplicated. Exports at most the latest 2,000 revision records per symbol, with the limit disclosed.
- Records provider request IDs and receipt times. This is not a tamper-proof or independently audited ledger. Historical bars fetched now were not necessarily known at their original timestamp; observed_at is when this service saw them.
- Calculates descriptive volume, SMA, ATR and VWAP metrics. No buyer-volume inference. Stockholm blocks liquidity judgments without quotes; Professor is deterministic. These outputs remain separate from the crypto orbit and readiness gates.
- Protects all market data API endpoints with the separate access token. The HTML and process health are public. CORS permits the existing static-site origin; same-origin backend use also works. Provider keys and the access token are never stored in localStorage; browser sign-in uses an HttpOnly secure cookie. Data-use and display rights must match your Massive agreement; public hosting does not grant redistribution rights.

## Actual limits

This is REST polling, **not tick streaming**. Fresh timestamps do not certify real-time entitlements.
The three-minute freshness threshold is only a research data check, not acceptable order-price latency.
The default collector can take about a minute after startup to fetch all three symbols.

Free Render sleeps after inactivity, may cold-start slowly, and loses local SQLite on sleep/restart/redeploy.
It cannot establish uninterrupted collection or durable evidence. An always-on instance plus durable
storage requires a separate cost decision; no paid resources are authorized by this package.
Storage capacity/retention and backups must be configured before sustained collection. API errors,
market closure and absent quotes keep research or execution blocked; they do not produce substitute data.

Tests: `python3 -m unittest -v test_server.py`.
Local-only development: `python3 server.py` (127.0.0.1:8000). Production uses Gunicorn above.

## Verification so far

The chat connector returned QQQ minute bars and market status on 2026-09-17.
Its newest sampled bar began 2026-09-16 23:59 UTC, so this was historical data, not a live-price proof.
Backend key authentication, account-specific delay, Render deployment and browser rendering still
need end-to-end verification after the user's secrets and repository upload are in place.

References:
- https://massive.com/docs/rest/quickstart
- https://massive.com/docs/rest/stocks/aggregates/custom-bars
- https://render.com/docs/free

## Next production milestones

Verify timestamp age under the actual plan during a regular session; choose durable storage and
uptime; add bid/ask quotes and contract data with the proper entitlements; connect US outputs to
the orbit; add reconnect/backfill recovery and retention monitoring. Only then evaluate historical,
out-of-sample, paper and shadow-account gates. Brokerage execution remains absent.

## Agent feed routing

Connect the existing private backend in US Charts, choose the instrument, then in Overview
set Agent data source to Private US backend. The five agent cards and orbit inspector now
consume the same verified response as the candles. Browser cache refresh is every 15 seconds;
provider collection remains rate-limited REST polling (at least 90 seconds per cycle), not a
tick stream. Real-time entitlement remains unverified. Responses older than 45 seconds and
completed candles older than 180 seconds are visibly blocked. Disconnect and symbol changes
clear the active observation; failed requests mark it unusable. Professor aggregates the four
module statuses. Stockholm reports missing quotes, never simulated liquidity. Crypto spot
mode retains its separate public-feed connection and readiness checks. No options permission,
subscription, continuous uptime or durable-storage claim is added by this UI integration.

## Customer journey and mobile web update — September 22, 2026

The app now opens on Today, with a five-destination navigation: Today, Markets, Agents,
Practice and Account. Mobile uses bottom navigation and responsive layouts; wide research
tables scroll within their containers. Existing charts, agents, historical checks, scenarios,
news and education remain accessible through section tabs and All research tools. Technical
records are expandable. Today derives connection status from this browser session; it does
not invent holdings, returns or readiness.

Account explains planned Robinhood integration, unsupported Cash App trading access and the
recommended broker-held funding path. No account authentication, payment, deposit, custody,
withdrawal or order endpoint has been added. Public Cash App Pay documentation describes
merchant checkout, not a verified investing API. Robinhood's official agent setup guidance
currently requires desktop onboarding. These references were checked September 22, 2026.
This is responsive mobile web, not a native app or background alert service.

Deploy by replacing the same heartbeat-backend.zip filename; no environment changes required.
The separate static site only updates when its configured HTML source is replaced too.

## Decision journal — September 24, 2026

Agents now opens on Decisions. After deployment, connect the private backend, wait for a
successful SPY or QQQ collector cycle, and open Agents → Decisions. The authenticated
GET /api/decisions endpoint returns the latest 100 stored records and linked outcomes.
Refresh/export are read-only. The collector, not page refresh, creates observations.
No broker orders, paper fills or quote entitlements are added by this upgrade.

The collector samples current completed candles at its existing polling cadence, not every
market event. Each decision retains its initial input snapshot, collection/evaluation times,
config/runner hashes, initial four specialist assessments and subsequent Professor review.
Initial modules receive raw inputs without peer outputs. These are separate deterministic
rules, not independent predictive models. Repeated identical inputs retain the first record;
changed input revisions create another record. Subsequent review never mutates initials.
The source code and experiment configuration are stored with the experiment artifact.

A follow-up observes the exact underlying bar closing five minutes after the decision time
rounded up to a minute. The comparison uses the original snapshot's latest close. It is a
counterfactual underlying observation, not a fill, option return, benchmark return or win.
Missing bars stay pending. Up to the latest 500 pending records are considered per collector
cycle; older pending items can remain unresolved. Outcomes append as separate artifacts;
later provider corrections do not silently overwrite them. No tamper-proof or external-audit
claim is made. SHA checks detect corruption, not a privileged attacker rewriting hashes.

The versioned experiment defines two underlyings and a fixed candle watch rule. The options
selection is a planned specification, not an executable strategy. Quotes, event eligibility,
full order lifecycle, mark-to-market drawdown, benchmark and agent ablation runners remain
unimplemented. Drawdown acceptance must be preregistered before qualification. No experiment
completion, out-of-sample success or readiness credit is claimed. Strategy revisions require
a new config/version and new evidence. All displayed metrics and records remain research.

SQLite persists only within the existing host lifecycle. Configure PostgreSQL and verify
restart recovery and backups before claiming durable evidence. No paid resource was created.

Tests: python3 -m unittest discover -p 'test_*.py'

## Shared evidence and bounded agent review

The SPY/QQQ decision journal now includes HB-REVIEW-001. Five deterministic
initial assessments are frozen before one review round routes seven targeted
messages. Every message references evidence and claim IDs. The limit is eight
unique messages and one round. Professor records the resolution; missing
options quotes, event coverage and validation continue to block eligibility.

Candles are shared by content ID. Exact duplicate evidence and messages are
collapsed. Multiple agents using one provider do not establish independent
corroboration. News ingestion and syndication detection are not implemented in
this protocol. This is local rule-based routing, not five autonomous LLM calls.
It makes no additional market requests or model calls.

Open Agents → Decisions → See the agents’ review. The orbit button displays
that recorded exchange and highlights a selected message's recipients. These
are historical records, not live traffic animations. Return to current inputs
exits the recorded view; disconnect clears it. Older records remain unchanged.

Feed health, analysis completion and trade eligibility are distinct. Paired
before/after decision labels are available, but collaboration's effect on
profits, missed opportunities and execution costs has not been measured.
The review source is included in the runner digest and experiment artifact.
Durable storage and historical quote entitlements remain separate prerequisites.

## Free research mode (Alpaca)

ALPACA_API_KEY and ALPACA_SECRET_KEY remain in Render Environment. No new
settings or subscription are required by this update. The collector now always
requests feed=indicative for SPY/QQQ snapshots every 90 seconds. It never
requests current premium OPRA snapshots. Indicative quotes are modified prices,
not executable quotes: recent_valid_quote stays false, execution modeling is
disabled, and readiness credit remains zero. Freshness is exposed separately
as recent_indicative_observation. Massive collection is unchanged.

Open Agents → Decisions → Free research mode · Alpaca. Refresh free research
status shows the Alpaca collector and the existing Massive quote-access result.
Check Massive historical quote access triggers the original bounded Massive
probe (one expired contract and two quote windows). It does not buy anything.

At collector startup, once per process, Alpaca tests two documented historical
endpoints: bars and trades for SPY250620C00600000 on June 2, 2025, 14:00–15:00 UTC.
Each is limited to 100 observations, with pagination explicitly disclosed.
Success means only sample retrieval, not independently audited data or broad
coverage. Empty data is distinct from denied access. There is no historical
bid/ask claim for these bars/trades. Results and samples use the existing
storage adapter; process restarts repeat the probe. Missing credentials keep
it unstarted. Account-specific access is not known until deployed requests run.

The source samples and status are private behind HB_ACCESS_TOKEN. Errors are
sanitized. No credential is embedded in this package. No account/order API is
called. These feeds remain separate from the frozen decision experiment.
SQLite persistence is still unverified unless durable storage is configured;
continuous collection needs storage-capacity monitoring. Free hosting can sleep.

## Alpaca continuously running crypto PAPER experiment

HB-CRYPTO-PAPER-001 is a separate experiment, NOT the options validation run.
It can submit simulated orders to Alpaca's paper account once explicitly
configured. Live-order routes do not exist in its client. Use a dedicated
Alpaca paper account without manual trades, existing positions or other bots.
Do NOT reset that account while this experiment has records or open positions.
Existing ALPACA_API_KEY / ALPACA_SECRET_KEY must be the rotated paper keys.

Render setup for the existing umbrella-heartbeat-api service:
1. Compute / Instance Type: Starter (published $7/month at preparation time).
   This is the service compute plan, not a paid workspace-plan upgrade.
2. Disks: add a 1 GB persistent disk mounted at /var/data (published $0.25/GB/month).
   Confirm the dashboard quote; these resources total about $7.25/month before
   tax/other usage. Budget ceiling: $25/month, not trading capital.
3. Environment: HB_CRYPTO_PAPER_ENABLED=true and
   HB_CRYPTO_DB_PATH=/var/data/crypto-paper.sqlite3.
4. Upload the replacement heartbeat-backend.zip in GitHub, keeping that exact
   filename. Keep one Gunicorn worker and one Render instance.
5. Health Check Path: /healthz. A health request starts the worker independently
   of a logged-in dashboard. Opening the backend also starts it.
6. Connect Heartbeat privately → Agents → Decisions → Crypto paper experiment.
   Check heartbeat, errors and quotes before assuming it is collecting.

The mount is checked with os.path.ismount. Without the disk, keys or enable flag,
the worker cannot submit orders. A file lock prevents a second process from
controlling the experiment. On-disk configuration AND source hash changes block
reuse of the run; preserve its ledger and start a new versioned experiment only
with an explicit migration/close-out plan. A disk deployment briefly stops the
service; it is not a guarantee of uninterrupted availability. Existing Massive
storage settings remain unchanged; /tmp data from earlier modules is NOT moved
by this release. Export any prior evidence before redeploying.

Frozen rules and limits:
- BTC/USD and ETH/USD spot, long only, no leverage, one position total.
- $50 virtual budget; buy exposure plus modeled entry fee <= $5.
- One attempted entry per America/Denver calendar day. Exits do not count as
  extra entries. Unfilled/rejected/uncertain entries consume the daily slot.
- 21 chronological minute-spaced quote observations; last midpoint exceeds the
  previous 20 and 5-observation average exceeds 20-observation average.
  These are observed quote midpoints, NOT completed candles or volume signals.
- Quotes <=15 seconds old, valid bid/ask/size, entry spread <=0.5%.
- Asset eligibility, increments and minimum size retrieved from Alpaca before
  an order. A minimum above $5 is a logged rejection, never a cap increase.
- Limit IOC orders only. Buy at rounded-up ask, sell at rounded-down bid. Entry
  quantity is rounded down and displayed size must cover it. Orders can fail.
- Exit triggers: -2%, +4%, 60 minutes, or modeled daily equity loss >=$5. These
  are triggers, not guaranteed fills or maximum realized losses.
- Quote errors, unknown account positions/orders, mismatched broker quantities,
  ambiguous submissions or storage failure stop new entries. Exit processing
  also requires valid data/account reconciliation; inspect errors promptly.
- Pause blocks NEW entries; it does not cancel an outstanding order or flatten
  a holding. Existing exits/reconciliation continue. Resume does not override
  the eligibility gates. A busy cycle may require retrying the control.

Order intents are committed before POST and receive unique client_order_id.
After a timeout we query that ID instead of resubmitting. Unresolved/unknown
orders require investigation; no automatic duplicate or blind retry is made.
Partial terminal fills become positions. Fee-related crypto-quantity differences
are not guessed: they stop the run for reconciliation. This conservative first
version may need a fee-accounting adapter after inspecting actual paper results.

Results use broker paper fills and a modeled 0.5% fee allowance EACH side,
not reconciled actual account charges. Gross benchmark = equal-weight BTC/ETH
midpoint buy-and-hold from first observations; it is NOT a net executable
benchmark. Estimated drawdown is sampled, not continuous. All performance is
simulated, not revenue, and grants ZERO options readiness credit. The crypto
five-role findings are deterministic descriptors, not the existing options
peer-review protocol and not independent predictive models. Strategy benefit
and agent ablation are not established.

The worker records observations, rejections, intent, fills and errors in
/var/data/crypto-paper.sqlite3. Each successful day's first cycle writes a native
SQLite backup, retaining the two latest daily backups on the SAME disk. This
protects restart recovery, not disk loss; external backup is not configured.
Low free disk space blocks the run. UI/report export shows only latest 50 events,
not the full ledger; download the database/backups through Render for full audit.
No external outage notification service is configured. API status reports age
so a live process is not confused with a successful data collection cycle.

The worker polls every 60 seconds plus API time and makes no LLM calls. It needs
at least 21 uninterrupted observations to consider an entry. At one entry/day,
100 closed paper trades require at least 100 days, and usually longer.
First acceptance: deployment healthy, persistent disk confirmed, quotes current,
no account mismatch, and state restored after a restart. No actual Alpaca request
with these credentials was made from the development workspace; account access,
minimum order size, paper fills and hosting recovery remain to be verified live.

## Customer experience release: simple journey v1

The dashboard now has five primary tabs:

- Home: connection status, paper-worker health, and one next action.
- Paper trading: the existing Alpaca crypto experiment, estimated value and realized result, recent events, pause/resume, and report download. Simulated outcomes are not income. The current report includes up to 50 events, with 10 summarized on screen.
- Research: saved US decisions, US candles, browser crypto prices, agent review, and Advanced research. These are distinct from the server crypto experiment.
- Learn: plain-language introduction followed by the existing educational material.
- Settings: the private backend URL and access token, provider access diagnostics, and collapsed future integrations.

Advanced research preserves the historical pilot, options validation, walk-forward methodology, limits, browser calculations and logs. Uncalibrated scenarios and archived news are explicitly labeled and collapsed. The duplicate unavailable replay, empty legacy paper ledger, and public chart widget no longer appear in the normal navigation. No historical records, agent rules, backend order logic, limits, or execution permissions were changed.

The token is exchanged for an opaque secure browser cookie. Sign out revokes that device session and clears the private experiment display. Home and Paper trading refresh the server report while the page is visible; this browser polling does not keep a sleeping server running. Worker timestamps, errors and report age govern status. A successful private-server connection does not prove a healthy market feed or worker.

Validation: 55 existing backend unit tests; existing JavaScript calculation/validation tests; browser fixture tests for navigation, authentication, running/paused/stale/error/disconnected states, unique DOM IDs, clearing private data, and desktop/mobile overflow. Browser tests use synthetic fixtures and do not verify actual account connectivity, profitability, or fills.


## Remember this device (secure sign-in release)

Use the dashboard served by the backend itself: https://umbrella-heartbeat-api.onrender.com.
In Settings, enter HB_ACCESS_TOKEN once and check **Remember this device for 30 days**.
The page will restore the session on later visits without requesting the token again.
Without the checkbox, the cookie is a browser-session cookie with a server expiry of 12 hours.
Browser session restoration can preserve session cookies; use Sign out on shared devices.

- Cookie: opaque random 256-bit identifier, __Host- prefix, Secure, HttpOnly, SameSite=Strict, Path=/, no Domain attribute. Provider keys never leave Render.
- Only session digests and expiry/key fingerprints are stored in SQLite. Every cookie-authenticated POST requires an exact same-origin HTTPS Origin check. Existing bearer API clients still work.
- Signing out revokes the current identifier in the database and expires its cookie. Rotating HB_ACCESS_TOKEN invalidates all existing sessions. Re-signing in rotates the current identifier.
- Login uses POST /api/session/login; restore uses GET /api/session; logout uses POST /api/session/logout. HTTPS is required. Render's trusted TLS proxy supplies X-Forwarded-Proto. Do not expose a plain-HTTP origin behind an untrusted proxy.
- Session storage uses HB_SESSION_DB_PATH if provided. Otherwise it uses /var/data/heartbeat-sessions.sqlite3 when /var/data exists, or HB_DB_PATH plus .sessions. The already mounted /var/data disk preserves sessions across deployments. With temporary storage, a restart can require sign-in again. A missing configured directory or unavailable session database fails closed.
- Sign-out and closing the dashboard do not stop the server paper worker. Use Pause new entries for that distinct action; pending orders and exits remain managed.
- This is a personal single-owner session, not a multi-user identity system. No new order permissions, live trading, or strategy changes.

Validation: 62 Python tests, JavaScript calculation checks, and a real local HTTPS browser integration check covering login, cookie flags, automatic reload restore, optional persistence, logout/reload, wrong-token rejection and mobile layout. Security tests cover expiry, token rotation, replay after logout, cross-origin POST rejection, restart recovery and storage failure. Test worker data is a fixture, not trading evidence.

## Guardian: sixth oversight role

Guardian is a deterministic pre-order policy gate for the existing BTC/USD and ETH/USD crypto paper experiment. It validates the presence/scope of five role assessments, independently checks the frozen breakout condition, and enforces current quotes, liquidity, cash, daily entry/loss limits, and owned-position-only exits. Structured agent text cannot change the policy. It is not a separate LLM, independent source of market evidence, ethical certification, profit guarantee, or OS sandbox.

The gateway uses a fixed Alpaca paper host, a route allowlist, strict order fields, limit/IOC orders, and a buy notional cap inclusive of modeled fees. No live orders, transfers, withdrawals, shopping, arbitrary URLs, or code execution are exposed to agent outputs. These controls assume the deployed server/code/credentials remain trusted; a compromised server is outside this application-level boundary. Stronger infrastructure isolation would require a separately deployed credential-holding order gateway and egress policy.

Alpaca paper buying power is displayed separately from the $50 starting experiment allocation. It cannot expand the $5 position cap, one-position/one-entry-per-day limits, or $5 daily-loss entry cutoff. Stops and loss thresholds are triggers, not promises of fills or maximum realized loss. Live-money execution stays disabled. Continuous operation still requires an enabled healthy worker, mounted disk, paper credentials, eligible minimum order sizes, fresh quotes, and qualifying signals. No qualifying trade is not a fault; do not force orders merely to show activity.

Each order gets a persisted GUARDIAN_ALLOW or GUARDIAN_BLOCK record. Scope, per-role checks, assessment age, realized paper result and recorded drawdown are exposed in the paper dashboard. The journal remains SQLite audit evidence, not independently immutable storage. After worker faults, its existing pause/reconciliation behavior remains in place. Missing peer assessments do not prevent a valid owned-position exit.

Upgrade handling accepts only the exact prior crypto source SHA-256 9298dcd9009be0e12752019cd07ac83208b03536802f1b36c6dfc02e07f7eaca with unchanged strategy configuration. It records GUARDIAN_UPGRADE and preserves cash, positions, pending orders, pause state, and all existing events. New identity covers both crypto_paper.py and guardian.py. Any other source/config mismatch still blocks startup. This is a documented safety-overlay change, not an untouched out-of-sample continuation; performance before and after must remain distinguishable by the upgrade event.

Validated with 71 Python tests, existing JavaScript checks, and HTTPS browser fixtures showing Guardian and separate $100,000/$50 balances on mobile. Tests include a full qualified paper tick, oversized/foreign/extra-field order rejection before network access, missing roles, stale inputs, loss/entry caps, risk-reducing exits, journal preservation and unsupported-source rejection. No actual broker order was submitted by these tests.

## Guardian orbit and paper connections release

Agent review now defaults to the authenticated Alpaca crypto paper worker. Guardian is an elevated sixth node connected to each of the five research roles. Select BTC/USD or ETH/USD and click a node to inspect recorded checks. Gold oversight links require a recent private worker report; gray dashed links are architecture only. Guardian is explicitly out of scope when inspecting US or browser Binance research. The orbit does not manufacture message deliveries or claim independent model reasoning.

Private paper status refreshes while Home, Paper trading, or the Alpaca orbit is visible. The orbit connection button refreshes the paper worker report or takes the user to Settings; it does not connect Binance when paper mode is selected. Current checks, persisted Guardian events and their timestamps are exportable. Browser-only data and messages remain distinct.

The authenticated /api/crypto/paper report now includes a read-only connection checklist: key presence (never values), enable flag, real disk mount, worker health, recent broker/Guardian cycle, each quote timestamp, and paused/waiting entry state. A configured key is not reported as verified account access. Quotes collected by a 60-second worker can exceed the 15-second display age between cycles; orders obtain and check current quotes within the existing strategy. No connection check forces an order, enables live money, changes strategy code/hashes or raises limits.

Validated: 75 backend tests; existing JS validation; local HTTPS sign-in/orbit tests including all six nodes, BTC/ETH selection, scope switching, no JS errors, and desktop/mobile rendering. Production deployment and public health were checked, but private worker health/actual paper fills require authenticated status. No live provider credentials were accessed or replaced in this release.

## Paper control error fix

Production logs showed successful GET /api/crypto/paper requests followed by a failed POST /api/crypto/resume. The former handler masked expected WORKER_NOT_STARTED/CYCLE_BUSY_RETRY and storage errors as CRYPTO_STATE_UNAVAILABLE. The unstarted-worker case was reproduced locally; the production startup blocker is not inferred from the HTTP status alone.

The status response now includes controls_available. Pause/Resume require an enabled, initialized, running worker; Resume does not start an uninitialized worker or repair its disk/keys. Blocked control requests return an explicit safe code plus the current report/checklist when available. Diagnostics failure cannot hide a usable worker report. Storage failure is classified separately. Unexpected failures log category/type only, never credentials, headers, provider payloads or exception text. The UI preserves returned diagnostic reports and places action feedback separately from worker health. Refresh clears obsolete action feedback.

Validation: 81 Python tests, JS checks, and local HTTPS browser regressions. Frozen crypto strategy, Guardian policy, budgets, source hashes and persisted experiment history are unchanged. No deployment-specific credential or storage problem has been declared resolved without an authenticated report.

## Entry Comparison Lab v1

Deploying this version registers a separate seven-day **forward-only hypothetical** experiment when the existing crypto worker starts. It uses `/var/data/entry-comparison-v1.sqlite3` on the mounted disk, and opens the original crypto journal read-only. No additional API key or market-data subscription is needed. Existing `crypto_paper.py` and `guardian.py` and their source hashes are unchanged.

Each variant starts with a separate $50 hypothetical balance, a $5 position cap, one entry attempt per Denver day and BTC/USD before ETH/USD as the frozen tie-break order. Earlier uses a five-observation breakout, Current uses the original 20-observation signal, Later requires two consecutive Current confirmations, and Pullback waits up to ten minutes for a 0.25% retracement above SMA20. All require 21 observations with 40–90 second spacing. Rules and code hashes are saved before subsequent observations are consumed; old history is not backfilled into results. Changed rules require a new experiment, not overwriting this one.

Entry/exit proposals use the next eligible recorded quote within 90 seconds. Both sides model 10bp adverse slippage and 0.5% fees; displayed size and the proposed limit must permit the fill. Stops are 2%, targets 4%, and maximum holding time is one hour before proposing an exit; an exit can remain unfilled. Daily loss of $5 pauses further entries for the experiment. Fractional modeled quantities do not establish broker minimum-size or precision eligibility. Sampling can miss intraminute losses. Open positions and pending orders at window end are censored, never fabricated into closing fills.

The Lab never imports a broker client or submits an order. Current reproduces the entry signal, not every original broker constraint or actual paper fill. All alternatives, including its Current baseline, are hypothetical. The original experiment remains the only paper-order sender.

Authenticated GET endpoints: `/api/lab/status`, `/api/lab/journal?after=0`, `/api/lab/inputs?after=0`. Pagination accepts a fixed `through` upper cursor. The Paper view shows recent outcomes, open marks and closed results separately, and can export all journal events and hashed source inputs through the report cursor. Rejected observations, no-trigger decisions, losses and unfilled proposals persist. Disk persistence is not independent auditing or an off-site backup. No readiness credit or expected profitability is asserted.

## Collection repair v2

Deploy this ZIP as `heartbeat-backend.zip`. No new environment variable, API key or paid subscription is required. The paper worker now starts an independent read-only Alpaca US crypto REST collector, nominally every five seconds. Each request reconnects; transport/auth/rate failures use exponential backoff capped at sixty seconds. Polls and their original source timestamps are saved in `cq_polls` in the existing persistent SQLite database before consumption. No old quote is retimestamped or interpolated. This is polling, not a WebSocket stream or guaranteed uninterrupted data.

Quote validation uses receipt/assessment time, correcting the old pre-request timestamp check that could reject a quote generated during the request. The strategy cycle targets sixty seconds start-to-start instead of sleeping sixty seconds after all network operations. Missing samples and intervals remain in each observation's entry checklist; the unchanged signal still requires 21 observations with 40–90 second gaps, then the original breakout. Recovery cannot guarantee a trade or resolve provider-side inactivity.

The exact prior source hash `97fb09c9db268e4b68ebda8d7687f333466c86f36a5797d8b6c41f4b510d84fc` upgrades automatically, retaining financial state, open/pending orders, daily limits, pause state and journal. It records `COLLECTION_UPGRADE` and clears only warmup history. Unknown source/config hashes remain blocked. Guardian's $50 allocation, $5 position cap, $5 daily-loss entry cutoff and one-entry/day rule are unchanged. Paused workers stay paused. Observe the new collection version separately in analysis.

An existing forward Entry Comparison Lab is frozen as `CENSORED_COLLECTION_CHANGE`, preserving its records and incomplete positions. No automatic new comparison is launched over these changed inputs. Already-complete comparisons remain complete. A lab first registered on this deployment starts its normal seven-day period with the repaired collector. This preserves the predeclared comparison instead of quietly pooling two collection versions.

Paper UI entry checks expose per-symbol quote condition, consecutive observations, breakout/spread conditions, current broker asset increments/minimums and minimum cost including modeled fees. These are prechecks, not Guardian order authorization. The five existing roles remain deterministic modules sharing one source. ETH failures do not block eligible BTC entries.

`order_lifecycle` and a separate latest-30 order-event list persist acceptance, partial fills, terminal broker states and uncertainty. Positions/P&L are reconciled once on terminal orders; partial broker status is visible while reconciliation is pending. Definitive HTTP 422 rejection is recorded without retry; uncertain submissions retain their original intent and are never resubmitted. Orders still use the fixed paper endpoint, limit IOC and the same risk rules.

Validation used fixture data only; it did not send a broker order. Deployment is not proof of a fill. After deployment, check collector version, fresh per-symbol observations, progressing consecutive count, entry reasons and eventual broker order status. The restarted history needs at least 21 valid observations and a qualifying signal. Export the report to diagnose persistent missing/stale ETH data instead of relaxing freshness limits.

## Clarity · Life Stages preview

Frontend-only section at `/#clarity` under The Umbrella Institute. Eight learning chapters reflect the supplied estate-planning contents page: orientation, living trust, funding, wills, financial power of attorney, care planning, support after loss, and an asset map. Three self-reported reflection steps per chapter unlock later chapters. Every overview is readable; loss-support tasks remain accessible at any time. The 3D perspective map has keyboard-operable nodes, a flat-view option and reduced-motion support.

Only completion booleans are saved in this browser under `umbrella-clarity-learning-v1`; no legal documents, names, account numbers or medical details are collected. Progress export/reset are included. This is device-local educational progress, not verified legal completion, trading readiness, a customer account or a secure document vault.

Foundations access works through prerequisites. Plus is a clearly labeled, session-only membership-access preview: it opens tasks without buying a membership, clearing prerequisite work, charging funds or granting a server entitlement. Pricing, checkout, customer identity, billing webhooks, server authorization, cross-device progress and professional services are NOT implemented. Connect those before selling memberships; browser locks are not paid-content security.

The bridge to Heartbeat displays only the authenticated report already loaded by the existing UI, with a stale-report label. No additional broker request, order permission or strategy modification is introduced. This release preserves every backend file from collection repair v2; only index.html and this README change. A Render deploy restarts the process and can interrupt an observation interval, so deploy at a suitable observation boundary. The persistent paper history remains preserved.

Resource links: NIH/NIA planning checklist and advance-care planning; Colorado Judicial Branch official forms. General prompts organize questions for professionals and do not create wills, trusts, powers of attorney, property transfers or tax/medical advice. Reference check: 2026-09-28.

### Clarity rewards v2

Seven small gold coins animate from a newly completed milestone. A gold chess pawn moves to the selected chapter as a navigation marker, including locked chapters being previewed. These are decorative learning rewards with no cash value, account balance or trading effect. Reduced-motion preferences replace the burst with a static brief coin and remove pawn movement animation. Restoring progress or opening a chapter does not replay rewards. Animations remove their temporary elements automatically.

### Strategy Call contact v3

Completing all three Step 1 checks opens a dismissible contact dialog: “Ready to schedule a Strategy Call?”, company “Clarity- Life Stages”, telephone 954-849-6223. A button on completed Step 1 reopens it later, including after reload. The phone link is `tel:+19548496223`; the app does not place a call or reserve an appointment automatically. All rewards and prerequisite behavior are retained. Backend files are unchanged.
