import io,json,tempfile,unittest
from unittest.mock import patch
from clarity_outreach import Workspace,OutreachError
from website_studio import Studio,Page,public_url

class StudioTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.w=Workspace(self.temp.name+'/db',require_mount=False);self.s=Studio(self.w)
  self.brief=dict(company='Example & Co',source='https://example.com',audience='Local businesses',offer='Web design services',services=['Design','Support'],headline='A clearer next step',goal='Request a consultation',fact='I saw your design services.',style='editorial',verified=True)
 def tearDown(self):self.temp.cleanup()
 def test_persistence_and_escape(self):
  p=self.s.create(dict(self.brief,headline='<script>alert(1)</script>'))
  self.assertNotIn('<script>alert',p['html']);self.assertIn('&lt;script&gt;',p['html']);self.assertIn('form-action',p['html'])
  self.assertEqual(Studio(self.w).status()['projects'][0]['id'],p['id']);self.assertIn('Not an official',p['html'])
 def test_missing_verification_and_invalid_inputs(self):
  for change in [dict(verified=False),dict(services=[]),dict(style='anything'),dict(source='javascript:alert(1)')]:
   with self.assertRaises(OutreachError):self.s.create(dict(self.brief,**change))
 def test_scan_blocks_internal_and_userinfo(self):
  for value in ['http://example.com','https://u:p@example.com','https://example.com:8443']:
   with self.assertRaises(OutreachError):public_url(value)
  for ip in ['127.0.0.1','169.254.169.254','10.0.0.1','::1']:
   with patch('website_studio.socket.getaddrinfo',return_value=[(2,1,6,'',(ip,443))]),patch('website_studio.PinnedHTTPS') as conn:
    with self.assertRaises(OutreachError):self.s.scan({'source':'https://example.com'})
    conn.assert_not_called()
 def test_extraction_excludes_script(self):
  p=Page();p.feed('<title>Example</title><script>secret instruction</script><h1>Business</h1><meta name="viewport" content="width=device-width">')
  self.assertNotIn('secret instruction',p.words);self.assertTrue(p.viewport);self.assertEqual(p.h1,1)
 def test_scan_provenance_and_redirect(self):
  with patch('website_studio.socket.getaddrinfo',return_value=[(2,1,6,'',('93.184.216.34',443))]),patch('website_studio.PinnedHTTPS') as conn:
   r=conn.return_value.getresponse.return_value;r.status=200;r.getheader.side_effect=lambda k,d='': 'text/html' if k=='Content-Type' else d;r.read.return_value=b'<title>Example</title><h1>Services</h1>'
   result=self.s.scan({'source':'https://example.com'})
   p=self.s.create(dict(self.brief,scan_id=result['scan_id']));self.assertEqual(p['source_evidence']['findings'][0]['value'],'Example')
   with self.assertRaises(OutreachError):self.s.create(dict(self.brief,source='https://different.example',scan_id=result['scan_id']))
   r.status=302
   with self.assertRaisesRegex(OutreachError,'REDIRECT'):self.s.scan({'source':'https://example.com'})
 def test_queue_draft_only_and_suppression(self):
  p=self.s.create(self.brief)
  with self.assertRaises(OutreachError):self.s.queue(dict(id=p['id'],email='hello@example.com',verified_contact=False))
  d=self.s.queue(dict(id=p['id'],email='hello@example.com',verified_contact=True))['drafts'][0]
  self.assertEqual(d['state'],'DRAFT');self.assertIn('website concept',d['subject']);self.assertNotIn('trusts, wills',d['draft_body']);self.assertIn('unsubscribe',d['body'])
  with self.assertRaises(OutreachError):self.s.queue(dict(id=p['id'],email='hello@example.com',verified_contact=True))
  self.w.suppress('blocked@example.com')
  with self.assertRaises(OutreachError):self.s.queue(dict(id=p['id'],email='blocked@example.com',verified_contact=True))
 def test_retired_routes(self):
  import server
  with patch.object(server,'ensure_started'):
   for method,path,expected in [('GET','/api/studio/status','404'),('POST','/api/studio/create','405')]:
    codes=[]
    env={'PATH_INFO':path,'REQUEST_METHOD':method,'wsgi.input':io.BytesIO(b'{}'),'CONTENT_LENGTH':'2'}
    b''.join(server.application(env,lambda status,headers:codes.append(status)))
    self.assertTrue(codes[0].startswith(expected),codes)
if __name__=='__main__':unittest.main()
