"""Heartbeat research backend. No broker routes. Run with one Gunicorn worker."""
import hashlib
import hmac
import json
import math
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from contextlib import contextmanager

ALLOWED = ('QQQ', 'SPY', 'GLD', 'TLT', 'IEF', 'IWM', 'HYG', 'AAPL', 'MSFT', 'NVDA', 'AMZN', 'TSLA')
SYMBOLS = tuple(dict.fromkeys(s.strip() for s in os.getenv('HB_SYMBOLS', 'QQQ,SPY,GLD').split(',') if s.strip() in ALLOWED))[:12]
KEY = os.getenv('MASSIVE_API_KEY', '')
TOKEN = os.getenv('HB_ACCESS_TOKEN', '')
DB = os.getenv('HB_DB_PATH', '/tmp/heartbeat.sqlite3')
INTERVAL = max(90, int(os.getenv('HB_POLL_SECONDS', '90')))
ORIGIN = 'https://umbrella-heartbeat.onrender.com'
LOCK = threading.RLock()
START_LOCK = threading.Lock()
STARTED = False
STATE = {'symbols': {}, 'market': None, 'market_received': None, 'market_error': 'NOT CONNECTED'}
ROOT = Path(__file__).resolve().parent

def stamp():
    return int(time.time() * 1000)

def iso(ms):
    return datetime.fromtimestamp(ms / 1000, timezone.utc).isoformat()

@contextmanager
def db():
    Path(DB).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB, timeout=10)
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('CREATE TABLE IF NOT EXISTS observations (symbol TEXT, bar_time INTEGER, observed_at INTEGER, digest TEXT, payload TEXT, request_id TEXT, PRIMARY KEY(symbol, bar_time, observed_at, digest))')
    try:
        with con:
            yield con
    finally:
        con.close()

def normalize(rows, now):
    """Only completed, internally consistent minute bars; reject rather than fabricate."""
    found = {}
    for r in rows:
        if not isinstance(r, dict):
            raise ValueError('INVALID_BAR')
        for k in ('t', 'o', 'h', 'l', 'c', 'v'):
            if isinstance(r.get(k), bool) or not isinstance(r.get(k), (int, float)) or not math.isfinite(r[k]):
                raise ValueError('INVALID_BAR')
        t = r['t']
        if t <= 0 or t % 60000 or t > now:
            raise ValueError('INVALID_TIMESTAMP')
        if min(r['o'], r['h'], r['l'], r['c']) <= 0 or r['v'] < 0 or r['h'] < max(r['o'], r['c'], r['l']) or r['l'] > min(r['o'], r['c']):
            raise ValueError('INVALID_OHLCV')
        if t + 60000 > now:
            continue
        bar = {k: r[k] for k in ('t', 'o', 'h', 'l', 'c', 'v')}
        # Missing VWAP stays missing. No inferred buyer volume or quote prices.
        vw = r.get('vw')
        bar['vw'] = vw if isinstance(vw, (int, float)) and not isinstance(vw, bool) and math.isfinite(vw) and r['l'] <= vw <= r['h'] else None
        if t in found and found[t] != bar:
            raise ValueError('CONFLICTING_DUPLICATE')
        found[t] = bar
    return sorted(found.values(), key=lambda b: b['t'])[-120:]

def store(symbol, bars, received, request_id):
    with db() as con:
        for b in bars:
            payload = json.dumps(b, sort_keys=True, separators=(',', ':'))
            digest = hashlib.sha256(payload.encode()).hexdigest()
            previous = con.execute('SELECT digest FROM observations WHERE symbol=? AND bar_time=? ORDER BY observed_at DESC LIMIT 1', (symbol, b['t'])).fetchone()
            if not previous or previous[0] != digest:
                con.execute('INSERT OR IGNORE INTO observations VALUES (?,?,?,?,?,?)', (symbol, b['t'], received, digest, payload, request_id))

def observations(symbol):
    with db() as con:
        rows = con.execute('SELECT bar_time, observed_at, payload, request_id FROM observations WHERE symbol=? ORDER BY observed_at DESC,bar_time DESC LIMIT 2000', (symbol,)).fetchall()
    return [{'bar_time': t, 'observed_at': observed, 'bar': json.loads(p), 'request_id': req} for t, observed, p, req in rows]

class ProviderError(Exception):
    pass

def request(path, params=None):
    url = 'https://api.massive.com' + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + KEY, 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            raw = response.read(2_000_001)
            if len(raw) > 2_000_000:
                raise ProviderError('RESPONSE_TOO_LARGE')
            result = json.loads(raw)
    except urllib.error.HTTPError as e:
        raise ProviderError({401: 'AUTH_REJECTED', 403: 'ENTITLEMENT_DENIED', 429: 'RATE_LIMITED'}.get(e.code, 'PROVIDER_HTTP_ERROR')) from None
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        raise ProviderError('PROVIDER_UNREACHABLE') from None
    if not isinstance(result, dict) or result.get('status') in ('ERROR', 'NOT_AUTHORIZED'):
        raise ProviderError('PROVIDER_REJECTED')
    return result

def collect_market():
    try:
        result = request('/v1/marketstatus/now')
        # Retain only the needed non-secret fields.
        value = {k: result.get(k) for k in ('market', 'serverTime', 'earlyHours', 'afterHours')}
        if value['market'] not in ('open', 'closed', 'extended-hours'):
            raise ProviderError('INVALID_MARKET_STATUS')
        provider_time = datetime.fromisoformat(str(value['serverTime']).replace('Z', '+00:00'))
        if provider_time.tzinfo is None or abs(stamp() - provider_time.timestamp() * 1000) > 180000:
            raise ProviderError('MARKET_CLOCK_STALE')
        with LOCK:
            STATE.update(market=value, market_received=stamp(), market_error=None)
    except (ProviderError, ValueError, TypeError):
        with LOCK:
            STATE['market_error'] = 'MARKET_STATUS_UNAVAILABLE'

def collect_symbol(symbol):
    try:
        now = stamp()
        result = request(f'/v2/aggs/ticker/{symbol}/range/1/minute/{now-7*86400000}/{now-1}', {'sort': 'desc', 'limit': 120, 'adjusted': 'false'})
        if result.get('ticker') != symbol or result.get('adjusted') is not False:
            raise ValueError('SYMBOL_OR_ADJUSTMENT_MISMATCH')
        if result.get('status') not in ('OK', 'DELAYED') or not isinstance(result.get('results', []), list):
            raise ValueError('INVALID_RESPONSE')
        received = stamp()
        bars = normalize(result.get('results', []), received)
        store(symbol, bars, received, str(result.get('request_id', ''))[:128])
        with LOCK:
            STATE['symbols'][symbol] = {'bars': bars, 'received': received, 'error': None, 'provider_status': result.get('status'), 'request_id': result.get('request_id')}
    except (ProviderError, ValueError, sqlite3.Error, OSError) as e:
        safe = str(e) if isinstance(e, (ProviderError, ValueError)) else 'STORAGE_FAILURE'
        with LOCK:
            old = STATE['symbols'].get(symbol, {'bars': [], 'received': None})
            STATE['symbols'][symbol] = {**old, 'error': safe}

def collect_loop():
    # Shared cache prevents browser traffic multiplying upstream requests.
    # At least 15 seconds between attempts; no pagination/backfill in this collector.
    while True:
        start = time.monotonic()
        collect_market()
        for symbol in SYMBOLS:
            time.sleep(15)
            collect_symbol(symbol)
        time.sleep(max(15, INTERVAL - (time.monotonic() - start)))

def ensure_started():
    global STARTED
    if not KEY or len(TOKEN) < 32:
        return
    with START_LOCK:
        if not STARTED:
            STARTED = True
            threading.Thread(target=collect_loop, daemon=True, name='massive-collector').start()

def research(bars, usable, blockers):
    out = {'tokyo': {'status': 'WARMUP'}, 'palermo': {'status': 'WARMUP'}, 'stockholm': {'status': 'BLOCKED', 'reason': 'No bid/ask or depth feed. Candle volume is not liquidity.'}, 'denver': {'status': 'CANDLE DATA OK' if usable else 'BLOCKED', 'issues': blockers}, 'professor': {'status': 'RESEARCH ONLY', 'summary': 'Options research and execution remain blocked; no quotes, contracts, validated edge or broker connection.'}}
    if len(bars) >= 21:
        previous = bars[-21:-1]
        avg_volume = sum(b['v'] for b in previous) / 20
        rvol = bars[-1]['v'] / avg_volume if avg_volume else None
        last20 = bars[-20:]
        volume = sum(b['v'] for b in last20)
        vwap = sum(b['vw'] * b['v'] for b in last20) / volume if volume and all(b['vw'] is not None for b in last20) else None
        sma5 = sum(b['c'] for b in bars[-5:]) / 5
        sma20 = sum(b['c'] for b in last20) / 20
        tr = [max(bars[i]['h']-bars[i]['l'], abs(bars[i]['h']-bars[i-1]['c']), abs(bars[i]['l']-bars[i-1]['c'])) for i in range(len(bars)-14, len(bars))]
        out['tokyo'] = {'status': 'OBSERVED' if usable else 'HISTORICAL ONLY', 'relative_volume_20': rvol, 'buy_share': None, 'reason': 'Equity volume versus previous 20 bars; no options flow or direction inference.'}
        out['palermo'] = {'status': 'OBSERVED' if usable else 'HISTORICAL ONLY', 'sma5': sma5, 'sma20': sma20, 'atr14': sum(tr)/14, 'vwap20': vwap, 'reason': 'Descriptive completed-bar metrics, not an entry signal.'}
    return out

def snapshot(symbol, now=None):
    now = now or stamp()
    with LOCK:
        item = dict(STATE['symbols'].get(symbol, {'bars': [], 'received': None, 'error': 'WAITING FOR COLLECTION'}))
        market = STATE['market']
        market_received = STATE['market_received']
        market_error = STATE['market_error']
    bars = item['bars']
    age = now-bars[-1]['t']-60000 if bars else None
    poll_age = now-item['received'] if item['received'] else None
    issues = []
    if not KEY: issues.append('MASSIVE KEY NOT CONFIGURED')
    if item.get('error'): issues.append(item['error'])
    if poll_age is None or poll_age > max(180000, (len(SYMBOLS)+1)*30000, INTERVAL*2000): issues.append('COLLECTOR STALE')
    market_fresh = bool(market_received and now-market_received <= max(180000, (len(SYMBOLS)+1)*30000, INTERVAL*2000) and not market_error)
    session = market['market'] if market and market_fresh else 'unknown'
    if session != 'open': issues.append('REGULAR SESSION NOT OPEN' if session != 'unknown' else 'SESSION UNKNOWN')
    if age is None or age < 0 or age > 180000: issues.append('CANDLES STALE OR ABSENT')
    if item.get('provider_status') == 'DELAYED': issues.append('PROVIDER DELAYED')
    if len(bars) < 21: issues.append('NEEDS 21 BARS')
    if any(bars[i]['t']-bars[i-1]['t'] != 60000 for i in range(max(1, len(bars)-20), len(bars))): issues.append('RECENT BAR GAPS')
    usable = not issues
    return {'schema': 'HB-US-1', 'symbol': symbol, 'server_time': now, 'source': 'Massive REST', 'interval': '1 minute', 'adjusted': False, 'session': session, 'market_observed_at': market_received, 'collected_at': item['received'], 'latest_bar_age_seconds': age/1000 if age is not None else None, 'state': 'RECENT CANDLES — RESEARCH ONLY' if usable else 'BLOCKED / HISTORICAL', 'issues': issues, 'bars': bars, 'engines': research(bars, usable, issues), 'research_usable': usable, 'realtime_entitlement': 'UNVERIFIED', 'storage': 'SQLite revisions; persistence not verified. Free Render storage is temporary.', 'execution_enabled': False, 'validation_credit': 0}

def application(environ, start_response):
    ensure_started()
    path = environ.get('PATH_INFO', '/')
    method = environ.get('REQUEST_METHOD', 'GET')
    origin = environ.get('HTTP_ORIGIN')
    headers = [('Cache-Control', 'no-store'), ('X-Content-Type-Options', 'nosniff'), ('Referrer-Policy', 'no-referrer')]
    if origin == ORIGIN:
        headers += [('Access-Control-Allow-Origin', ORIGIN), ('Vary', 'Origin'), ('Access-Control-Allow-Headers', 'Authorization'), ('Access-Control-Allow-Methods', 'GET, OPTIONS')]
    def reply(code, data, content_type='application/json'):
        raw = data if isinstance(data, bytes) else json.dumps(data, allow_nan=False).encode()
        start_response(code, headers + [('Content-Type', content_type), ('Content-Length', str(len(raw)))])
        return [raw]
    if method == 'OPTIONS':
        return reply('204 No Content', b'')
    if method != 'GET':
        return reply('405 Method Not Allowed', {'error': 'READ_ONLY'})
    if path == '/healthz':
        return reply('200 OK', {'service': 'heartbeat-us', 'process': 'ok', 'execution_enabled': False})
    if path == '/':
        return reply('200 OK', (ROOT/'index.html').read_bytes(), 'text/html; charset=utf-8')
    if path == '/robots.txt':
        return reply('200 OK', b'User-agent: *\nDisallow: /api/\n', 'text/plain')
    if path not in ('/api/us/status', '/api/us/candles', '/api/us/observations'):
        return reply('404 Not Found', {'error': 'NOT_FOUND'})
    if len(TOKEN) < 32:
        return reply('503 Service Unavailable', {'error': 'ACCESS_TOKEN_NOT_CONFIGURED'})
    if not hmac.compare_digest(environ.get('HTTP_AUTHORIZATION', '').encode(), ('Bearer '+TOKEN).encode()):
        return reply('401 Unauthorized', {'error': 'BACKEND_ACCESS_TOKEN_REQUIRED'})
    if path == '/api/us/status':
        return reply('200 OK', {'symbols': SYMBOLS, 'configured': bool(KEY), 'collector_started': STARTED, 'minimum_cycle_seconds': max(INTERVAL, 15*(len(SYMBOLS)+1)), 'execution_enabled': False, 'storage': 'SQLite; persistence unverified', 'realtime_entitlement': 'UNVERIFIED'})
    symbol = urllib.parse.parse_qs(environ.get('QUERY_STRING', '')).get('symbol', ['QQQ'])[0]
    if symbol not in SYMBOLS:
        return reply('400 Bad Request', {'error': 'SYMBOL_NOT_CONFIGURED', 'symbols': SYMBOLS})
    if path == '/api/us/candles':
        return reply('200 OK', snapshot(symbol))
    try:
        return reply('200 OK', {'symbol': symbol, 'limit': 2000, 'observations': observations(symbol), 'audited': False, 'note': 'First-seen revisions, not historical decision-time knowledge. Not credited to readiness.'})
    except (sqlite3.Error, OSError):
        return reply('503 Service Unavailable', {'error': 'STORAGE_UNAVAILABLE'})

if __name__ == '__main__':
    from wsgiref.simple_server import make_server
    make_server('127.0.0.1', int(os.getenv('PORT', '8000')), application).serve_forever()
