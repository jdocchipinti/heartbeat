"""Heartbeat research backend. No broker routes. Run with one Gunicorn worker."""
import sys
import hashlib
import hmac
import json
import math
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import csv
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from contextlib import contextmanager
import paper_connections
import browser_sessions
import entry_lab
import crypto_paper
import alpaca_data
import decision_journal
import evidence_storage
from option_execution import model_round_trip

ALLOWED = ('QQQ', 'SPY', 'GLD', 'TLT', 'IEF', 'IWM', 'HYG', 'AAPL', 'MSFT', 'NVDA', 'AMZN', 'TSLA')
SYMBOLS = tuple(dict.fromkeys(s.strip() for s in os.getenv('HB_SYMBOLS', 'QQQ,SPY,GLD').split(',') if s.strip() in ALLOWED))[:12]
KEY = os.getenv('MASSIVE_API_KEY', '')
TOKEN = os.getenv('HB_ACCESS_TOKEN', '')
DB = os.getenv('HB_DB_PATH', '/tmp/heartbeat.sqlite3')
DATABASE_URL = os.getenv('DATABASE_URL', '')
SESSION_DB = os.getenv('HB_SESSION_DB_PATH', '/var/data/heartbeat-sessions.sqlite3' if os.path.isdir('/var/data') else DB+'.sessions')
PROCESS_ID = uuid.uuid4().hex
INTERVAL = max(90, int(os.getenv('HB_POLL_SECONDS', '90')))
ORIGIN = 'https://umbrella-heartbeat.onrender.com'
LOCK = threading.RLock()
START_LOCK = threading.Lock()
STARTED = False
STATE = {'symbols': {}, 'market': None, 'market_received': None, 'market_error': 'NOT CONNECTED'}
ROOT = Path(__file__).resolve().parent
UPSTREAM_LOCK = threading.Lock()
LAST_REQUEST = 0.0
PILOT = {'state':'NOT_RUN', 'error':None, 'report':None, 'run_id':None}
ACCESS = {'state':'NOT_CHECKED','result':None}
STORAGE = None

def stamp():
    return int(time.time() * 1000)

def iso(ms):
    return datetime.fromtimestamp(ms / 1000, timezone.utc).isoformat()

@contextmanager
def db():
    with evidence_storage.connect(DB,DATABASE_URL) as con:
        yield con

def normalize(rows, now):
    """Only completed, internally consistent minute bars; reject rather than fabricate."""
    found = {}
    for r in rows:
        if not isinstance(r, dict):
            raise ValueError('INVALID_BAR')
        for k in ('t', 'o', 'h', 'l', 'c', 'v'):
            if isinstance(r.get(k), bool) or not isinstance(r.get(k), (int, float)) or not math.isfinite(r[k]):
                raise ValueError('INVALID_BAR')
        t = r['t']
        if t <= 0 or t % 60000 or t > now:
            raise ValueError('INVALID_TIMESTAMP')
        if min(r['o'], r['h'], r['l'], r['c']) <= 0 or r['v'] < 0 or r['h'] < max(r['o'], r['c'], r['l']) or r['l'] > min(r['o'], r['c']):
            raise ValueError('INVALID_OHLCV')
        if t + 60000 > now:
            continue
        bar = {k: r[k] for k in ('t', 'o', 'h', 'l', 'c', 'v')}
        # Missing VWAP stays missing. No inferred buyer volume or quote prices.
        vw = r.get('vw')
        bar['vw'] = vw if isinstance(vw, (int, float)) and not isinstance(vw, bool) and math.isfinite(vw) and r['l'] <= vw <= r['h'] else None
        if t in found and found[t] != bar:
            raise ValueError('CONFLICTING_DUPLICATE')
        found[t] = bar
    return sorted(found.values(), key=lambda b: b['t'])[-120:]

def store(symbol, bars, received, request_id):
    with db() as con:
        for b in bars:
            payload = json.dumps(b, sort_keys=True, separators=(',', ':'))
            digest = hashlib.sha256(payload.encode()).hexdigest()
            previous = con.execute('SELECT digest FROM observations WHERE symbol=? AND bar_time=? ORDER BY observed_at DESC LIMIT 1', (symbol, b['t'])).fetchone()
            if not previous or previous[0] != digest:
                con.execute('INSERT INTO observations VALUES (?,?,?,?,?,?) ON CONFLICT DO NOTHING', (symbol, b['t'], received, digest, payload, request_id))

def observations(symbol):
    with db() as con:
        rows = con.execute('SELECT bar_time, observed_at, payload, request_id FROM observations WHERE symbol=? ORDER BY observed_at DESC,bar_time DESC LIMIT 2000', (symbol,)).fetchall()
    return [{'bar_time': t, 'observed_at': observed, 'bar': json.loads(p), 'request_id': req} for t, observed, p, req in rows]

class ProviderError(Exception):
    pass

def request(path, params=None):
    global LAST_REQUEST
    # Share the same rate limiter across the live collector and historical jobs.
    with UPSTREAM_LOCK:
        wait=15-(time.monotonic()-LAST_REQUEST)
        if wait>0:time.sleep(wait)
        LAST_REQUEST=time.monotonic()
    url = 'https://api.massive.com' + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + KEY, 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            raw = response.read(2_000_001)
            if len(raw) > 2_000_000:
                raise ProviderError('RESPONSE_TOO_LARGE')
            result = json.loads(raw)
    except urllib.error.HTTPError as e:
        raise ProviderError({401: 'AUTH_REJECTED', 403: 'ENTITLEMENT_DENIED', 429: 'RATE_LIMITED'}.get(e.code, 'PROVIDER_HTTP_ERROR')) from None
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        raise ProviderError('PROVIDER_UNREACHABLE') from None
    if isinstance(result,dict) and result.get('status') in ('NOT_ENTITLED','NOT_AUTHORIZED'):
        raise ProviderError('ENTITLEMENT_DENIED')
    if not isinstance(result, dict) or result.get('status')=='ERROR':
        raise ProviderError('PROVIDER_REJECTED')
    return result

def collect_market():
    try:
        result = request('/v1/marketstatus/now')
        # Retain only the needed non-secret fields.
        value = {k: result.get(k) for k in ('market', 'serverTime', 'earlyHours', 'afterHours')}
        if value['market'] not in ('open', 'closed', 'extended-hours'):
            raise ProviderError('INVALID_MARKET_STATUS')
        provider_time = datetime.fromisoformat(str(value['serverTime']).replace('Z', '+00:00'))
        if provider_time.tzinfo is None or abs(stamp() - provider_time.timestamp() * 1000) > 180000:
            raise ProviderError('MARKET_CLOCK_STALE')
        with LOCK:
            STATE.update(market=value, market_received=stamp(), market_error=None)
    except (ProviderError, ValueError, TypeError):
        with LOCK:
            STATE['market_error'] = 'MARKET_STATUS_UNAVAILABLE'

def collect_symbol(symbol):
    try:
        now = stamp()
        result = request(f'/v2/aggs/ticker/{symbol}/range/1/minute/{now-7*86400000}/{now-1}', {'sort': 'desc', 'limit': 120, 'adjusted': 'false'})
        if result.get('ticker') != symbol or result.get('adjusted') is not False:
            raise ValueError('SYMBOL_OR_ADJUSTMENT_MISMATCH')
        if result.get('status') not in ('OK', 'DELAYED') or not isinstance(result.get('results', []), list):
            raise ValueError('INVALID_RESPONSE')
        received = stamp()
        bars = normalize(result.get('results', []), received)
        store(symbol, bars, received, str(result.get('request_id', ''))[:128])
        with LOCK:
            STATE['symbols'][symbol] = {'bars': bars, 'received': received, 'error': None, 'provider_status': result.get('status'), 'request_id': result.get('request_id')}
        if symbol in decision_journal.CONFIG['universe']:
            observed=snapshot(symbol)
            decision_journal.capture(DB,DATABASE_URL,observed)
            decision_journal.follow(DB,DATABASE_URL,observed)
    except (ProviderError, ValueError, sqlite3.Error, OSError, evidence_storage.StorageError) as e:
        safe = str(e) if isinstance(e, (ProviderError, ValueError)) else 'STORAGE_FAILURE'
        with LOCK:
            old = STATE['symbols'].get(symbol, {'bars': [], 'received': None})
            STATE['symbols'][symbol] = {**old, 'error': safe}

def collect_loop():
    # Shared cache prevents browser traffic multiplying upstream requests.
    # At least 15 seconds between attempts; no pagination/backfill in this collector.
    while True:
        start = time.monotonic()
        collect_market()
        for symbol in SYMBOLS:
            time.sleep(15)
            collect_symbol(symbol)
        time.sleep(max(15, INTERVAL - (time.monotonic() - start)))

def save_alpaca(symbol, payload):
    evidence_storage.save(DB,DATABASE_URL,"alpaca-"+symbol+"-"+uuid.uuid4().hex,"alpaca_option_snapshot",payload)

ALPACA = alpaca_data.Collector(os.getenv("ALPACA_API_KEY", ""), os.getenv("ALPACA_SECRET_KEY", ""), save_alpaca)

CRYPTO = crypto_paper.Experiment(os.getenv("HB_CRYPTO_DB_PATH", "/var/data/crypto-paper.sqlite3"), os.getenv("ALPACA_API_KEY", ""), os.getenv("ALPACA_SECRET_KEY", ""), os.getenv("HB_CRYPTO_PAPER_ENABLED", "false").lower()=="true")

LAB = entry_lab.Lab(CRYPTO.path, str(Path(CRYPTO.path).with_name("entry-comparison-v1.sqlite3")))

def ensure_started():
    global STARTED
    if len(TOKEN) >= 32:
        ALPACA.start()
        CRYPTO.start()
        LAB.start(CRYPTO.started)
    if not KEY or len(TOKEN) < 32:
        return
    with START_LOCK:
        if not STARTED:
            STARTED = True
            threading.Thread(target=collect_loop, daemon=True, name='massive-collector').start()

def pilot_job(run_id):
    """Fetch a fixed universe/date range privately. Keep run artifacts off public GitHub."""
    try:
        import historical_pilot
        folder=Path(DB).parent/'heartbeat-runs'/run_id
        raw=folder/'pilot_raw'
        raw.mkdir(parents=True,exist_ok=False)
        shutil.copyfile(ROOT/'pilot_config.json',folder/'pilot_config.json')
        cfg=json.loads((folder/'pilot_config.json').read_text())
        for symbol,provider in cfg['symbols'].items():
            with LOCK:PILOT['state']='FETCHING '+symbol
            if provider=='Massive':
                result=request(f'/v2/aggs/ticker/{symbol}/range/1/day/{cfg["start"]}/{cfg["end"]}',{'sort':'asc','limit':500,'adjusted':'false'})
                if result.get('ticker')!=symbol or result.get('adjusted') is not False or result.get('next_url') or not result.get('results'):
                    raise ValueError('HISTORICAL_COVERAGE_INCOMPLETE')
                with (raw/(symbol+'.csv')).open('w') as f:
                    writer=csv.DictWriter(f,fieldnames=['t','o','h','l','c','v'],extrasaction='ignore')
                    writer.writeheader();writer.writerows(result['results'])
            else:
                start=int(datetime.fromisoformat(cfg['start']).replace(tzinfo=timezone.utc).timestamp()*1000)
                end=int(datetime.fromisoformat(cfg['end']).replace(tzinfo=timezone.utc).timestamp()*1000)+86400000-1
                url='https://data-api.binance.vision/api/v3/klines?'+urllib.parse.urlencode({'symbol':symbol,'interval':'1d','startTime':start,'endTime':end,'limit':1000})
                with urllib.request.urlopen(url,timeout=20) as response:
                    content=response.read(2_000_001)
                if len(content)>2_000_000:raise ValueError('BINANCE_RESPONSE_TOO_LARGE')
                rows=json.loads(content)
                if not isinstance(rows,list) or len(rows)!=365:raise ValueError('BINANCE_COVERAGE_INCOMPLETE')
                (raw/(symbol+'.json')).write_bytes(content)
        with LOCK:PILOT['state']='EVALUATING'
        result=historical_pilot.run(folder)
        # Store source bytes as well as the report; scratch files alone are not evidence retention.
        for source in sorted(raw.iterdir()):
            evidence_storage.save(DB,DATABASE_URL,run_id+'/'+source.name,'historical_source',{'run_id':run_id,'filename':source.name,'content':source.read_text()})
        evidence_storage.save(DB,DATABASE_URL,run_id,'pilot_report',result)
        with LOCK:PILOT.update(state='COMPLETE — OPTIONS PHASE 1 NOT PASSED',report=result,error=None)
    except Exception as e:
        # Never expose upstream URLs, request headers, or credentials in errors.
        code=str(e) if isinstance(e,ProviderError) else 'HISTORICAL_RUN_FAILED: '+type(e).__name__
        with LOCK:PILOT.update(state='FAILED',error=code)

def start_pilot():
    with LOCK:
        if PILOT['state'].startswith('FETCHING') or PILOT['state']=='EVALUATING':
            return False,'ALREADY_RUNNING'
        if not KEY:return False,'MASSIVE_KEY_NOT_CONFIGURED'
        # Limit storage growth and accidental double submissions: one run per process.
        if PILOT['report'] is not None:return False,'REPORT_ALREADY_AVAILABLE'
        run_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
        PILOT.update(state='FETCHING INPUTS',error=None,run_id=run_id)
        threading.Thread(target=pilot_job,args=(run_id,),daemon=True,name='historical-pilot').start()
        return True,run_id

def restore_pilot():
    if PILOT['report'] is not None or PILOT['state']!='NOT_RUN':return
    saved=evidence_storage.latest(DB,DATABASE_URL,'pilot_report')
    if saved:
        with LOCK:PILOT.update(state='RESTORED — OPTIONS PHASE 1 NOT PASSED',report=saved['payload'],run_id=saved['id'])

def storage_status():
    global STORAGE
    with LOCK:
        if STORAGE is None:STORAGE=evidence_storage.verify(DB,DATABASE_URL,PROCESS_ID)
        return dict(STORAGE)

def option_access_job():
    result={'scope':'Render API key; one expired SPY contract and two historical quote windows only','contract_access':'UNVERIFIED','quote_access':'UNVERIFIED','execution_enabled':False,'readiness_credit':0,'checked_at':iso(stamp())}
    run_id='options-'+uuid.uuid4().hex
    try:
        storage_status()
        response=request('/v3/reference/options/contracts',{'underlying_ticker':'SPY','expiration_date':'2025-06-20','strike_price':600,'contract_type':'call','expired':'false','as_of':'2025-06-02','limit':10})
        evidence_storage.save(DB,DATABASE_URL,run_id+'/contracts','option_source',{k:response.get(k) for k in ('status','request_id','results')})
        rows=response.get('results',[])
        contract=next((c for c in rows if c.get('ticker')=='O:SPY250620C00600000'),None)
        if not contract:
            result['contract_access']='NO_MATCH';raise ProviderError('NO_AS_OF_CONTRACT_MATCH')
        result.update(contract_access='SAMPLE_RETRIEVED',contract=contract)
        entry=int(datetime(2025,6,2,14,0,tzinfo=timezone.utc).timestamp())*1_000_000_000
        exit_time=entry+3600*1_000_000_000
        quotes=[]
        complete=True
        for label,decision in [('entry',entry),('exit',exit_time)]:
            arrival=decision+500_000_000
            q=request('/v3/quotes/O:SPY250620C00600000',{'timestamp.gte':str(arrival-2_000_000_000),'timestamp.lte':str(arrival),'order':'asc','sort':'timestamp','limit':1000})
            # Do not retain credential-bearing pagination URLs. Only note incompleteness.
            captured={k:q.get(k) for k in ('status','request_id','results')}
            captured['pagination_remaining']=bool(q.get('next_url'))
            evidence_storage.save(DB,DATABASE_URL,run_id+'/'+label,'option_source',captured)
            complete=complete and not q.get('next_url')
            quotes.append(q.get('results',[]))
        result.update(quote_access='SAMPLES_RETRIEVED' if all(quotes) else 'EMPTY_SAMPLE_WINDOW',entry_quote_count=len(quotes[0]),exit_quote_count=len(quotes[1]),complete_windows=bool(complete))
        # Fixed limits/costs for a plumbing probe, not an optimized historical strategy.
        result['model']=model_round_trip(contract,*quotes,entry,exit_time,int(datetime(2025,6,20,tzinfo=timezone.utc).timestamp())*1_000_000_000,entry_limit='0.03',exit_limit='0.01',complete=complete)
        result['model_note']='Fixed $0.03 buy limit, $0.01 sell limit, $50 budget and $5 full-premium loss cap. A rejection is expected for most contracts. Not a trade recommendation or performance test.'
        result['state']='CHECK COMPLETE — NO READINESS CREDIT'
    except ProviderError as e:
        result.update(state='ACCESS BLOCKED',error=str(e))
        if result['contract_access']=='SAMPLE_RETRIEVED':result['quote_access']=str(e)
        else:result['contract_access']=str(e)
    except Exception:
        result.update(state='CHECK FAILED',error='DATA_OR_STORAGE_ERROR')
    try:
        evidence_storage.save(DB,DATABASE_URL,run_id,'option_access',result)
        result['saved']=True
    except evidence_storage.StorageError:
        result['saved']=False;result['state']='STORAGE FAILED — RESULT NOT DURABLE'
    with LOCK:ACCESS.update(state=result['state'],result=result)

def start_option_access():
    with LOCK:
        if ACCESS['state']=='RUNNING':return False,'ALREADY_RUNNING'
        if not KEY:return False,'MASSIVE_KEY_NOT_CONFIGURED'
        ACCESS.update(state='RUNNING',result=None)
        threading.Thread(target=option_access_job,daemon=True,name='options-access').start()
        return True,'RUNNING'

def research(bars, usable, blockers):
    out = {'tokyo': {'status': 'WARMUP'}, 'palermo': {'status': 'WARMUP'}, 'stockholm': {'status': 'BLOCKED', 'reason': 'No bid/ask or depth feed. Candle volume is not liquidity.'}, 'denver': {'status': 'CANDLE DATA OK' if usable else 'BLOCKED', 'issues': blockers}, 'professor': {'status': 'RESEARCH ONLY', 'summary': 'Options research and execution remain blocked; no quotes, contracts, validated edge or broker connection.'}}
    if len(bars) >= 21:
        previous = bars[-21:-1]
        avg_volume = sum(b['v'] for b in previous) / 20
        rvol = bars[-1]['v'] / avg_volume if avg_volume else None
        last20 = bars[-20:]
        volume = sum(b['v'] for b in last20)
        vwap = sum(b['vw'] * b['v'] for b in last20) / volume if volume and all(b['vw'] is not None for b in last20) else None
        sma5 = sum(b['c'] for b in bars[-5:]) / 5
        sma20 = sum(b['c'] for b in last20) / 20
        tr = [max(bars[i]['h']-bars[i]['l'], abs(bars[i]['h']-bars[i-1]['c']), abs(bars[i]['l']-bars[i-1]['c'])) for i in range(len(bars)-14, len(bars))]
        out['tokyo'] = {'status': 'OBSERVED' if usable else 'HISTORICAL ONLY', 'relative_volume_20': rvol, 'buy_share': None, 'reason': 'Equity volume versus previous 20 bars; no options flow or direction inference.'}
        out['palermo'] = {'status': 'OBSERVED' if usable else 'HISTORICAL ONLY', 'sma5': sma5, 'sma20': sma20, 'atr14': sum(tr)/14, 'vwap20': vwap, 'reason': 'Descriptive completed-bar metrics, not an entry signal.'}
    out['professor'] = {
        'status': 'RESEARCH ONLY' if usable else 'BLOCKED',
        'mode': 'Deterministic aggregation; no LLM call',
        'inputs': {name: out[name]['status'] for name in ('tokyo','palermo','denver','stockholm')},
        'summary': 'Tokyo and Palermo evaluated completed underlying candles. Denver found '+str(len(blockers))+' candle-data blockers. Stockholm cannot verify liquidity without bid/ask quotes. Options decisions remain blocked.',
        'execution_enabled': False
    }
    for name, output in out.items():
        output['source_scope'] = 'Massive underlying candles and market status; no options feed'
    return out

def snapshot(symbol, now=None):
    now = now or stamp()
    with LOCK:
        item = dict(STATE['symbols'].get(symbol, {'bars': [], 'received': None, 'error': 'WAITING FOR COLLECTION'}))
        market = STATE['market']
        market_received = STATE['market_received']
        market_error = STATE['market_error']
    bars = item['bars']
    age = now-bars[-1]['t']-60000 if bars else None
    poll_age = now-item['received'] if item['received'] else None
    issues = []
    if not KEY: issues.append('MASSIVE KEY NOT CONFIGURED')
    if item.get('error'): issues.append(item['error'])
    if poll_age is None or poll_age > max(180000, (len(SYMBOLS)+1)*30000, INTERVAL*2000): issues.append('COLLECTOR STALE')
    market_fresh = bool(market_received and now-market_received <= max(180000, (len(SYMBOLS)+1)*30000, INTERVAL*2000) and not market_error)
    session = market['market'] if market and market_fresh else 'unknown'
    if session != 'open': issues.append('REGULAR SESSION NOT OPEN' if session != 'unknown' else 'SESSION UNKNOWN')
    if age is None or age < 0 or age > 180000: issues.append('CANDLES STALE OR ABSENT')
    if item.get('provider_status') == 'DELAYED': issues.append('PROVIDER DELAYED')
    if len(bars) < 21: issues.append('NEEDS 21 BARS')
    if any(bars[i]['t']-bars[i-1]['t'] != 60000 for i in range(max(1, len(bars)-20), len(bars))): issues.append('RECENT BAR GAPS')
    usable = not issues
    return {'schema': 'HB-US-1', 'symbol': symbol, 'server_time': now, 'source': 'Massive REST', 'interval': '1 minute', 'adjusted': False, 'session': session, 'market_observed_at': market_received, 'collected_at': item['received'], 'latest_bar_age_seconds': age/1000 if age is not None else None, 'state': 'RECENT CANDLES — RESEARCH ONLY' if usable else 'BLOCKED / HISTORICAL', 'issues': issues, 'bars': bars, 'engines': research(bars, usable, issues), 'research_usable': usable, 'realtime_entitlement': 'UNVERIFIED', 'storage': 'PostgreSQL configured; verify recovery and backups in Evidence.' if DATABASE_URL else 'SQLite revisions; persistence not verified. Free Render storage is temporary.', 'execution_enabled': False, 'validation_credit': 0}

CRYPTO_CONTROL_ERRORS={'CYCLE_BUSY_RETRY','WORKER_NOT_STARTED','WORKER_DISABLED','ALPACA_KEYS_MISSING','PERSISTENT_DISK_REQUIRED','STORAGE_OR_SINGLE_WORKER_LOCK_FAILED'}

def crypto_report():
    report=CRYPTO.status()
    report['controls_available']=bool(CRYPTO.enabled and CRYPTO.started and isinstance(report.get('state'),dict) and not report.get('cycle_in_progress'))
    try:report['connections']=paper_connections.check(CRYPTO,report)
    except Exception as error:
        # Never put provider responses, request headers, credentials or exception text in logs.
        print('heartbeat crypto_diagnostics_failed exception='+type(error).__name__,file=sys.stderr,flush=True)
        report['connections']={'checks':[{'name':'Connection diagnostics','state':'UNAVAILABLE','detail':'Diagnostics could not be calculated. The worker report below is retained.'}],'forced_trade':False}
    return report

def application(environ, start_response):
    ensure_started()
    path = environ.get('PATH_INFO', '/')
    method = environ.get('REQUEST_METHOD', 'GET')
    origin = environ.get('HTTP_ORIGIN')
    headers = [('Cache-Control', 'no-store'), ('X-Content-Type-Options', 'nosniff'), ('Referrer-Policy', 'no-referrer'), ('X-Frame-Options', 'DENY')]
    if origin == ORIGIN:
        headers += [('Access-Control-Allow-Origin', ORIGIN), ('Vary', 'Origin'), ('Access-Control-Allow-Headers', 'Authorization'), ('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')]
    def reply(code, data, content_type='application/json'):
        raw = data if isinstance(data, bytes) else json.dumps(data, allow_nan=False).encode()
        start_response(code, headers + [('Content-Type', content_type), ('Content-Length', str(len(raw)))])
        return [raw]
    if path in ('/api/session', '/api/session/login', '/api/session/logout'):
        if len(TOKEN) < 32:
            return reply('503 Service Unavailable', {'error':'ACCESS_TOKEN_NOT_CONFIGURED'})
        expected = 'GET' if path == '/api/session' else 'POST'
        if method != expected:
            return reply('405 Method Not Allowed', {'error':'METHOD_NOT_ALLOWED'})
        if not browser_sessions.secure(environ):
            return reply('403 Forbidden', {'error':'HTTPS_REQUIRED'})
        if method == 'POST' and not browser_sessions.same_origin(environ):
            return reply('403 Forbidden', {'error':'SAME_ORIGIN_REQUIRED'})
        try:
            if path == '/api/session/logout':
                browser_sessions.revoke(SESSION_DB,environ)
                headers.append(('Set-Cookie',browser_sessions.cookie_header()))
                return reply('200 OK',{'authenticated':False})
            if path == '/api/session/login':
                if not hmac.compare_digest(environ.get('HTTP_AUTHORIZATION','').encode(),('Bearer '+TOKEN).encode()):
                    return reply('401 Unauthorized',{'error':'ACCESS_TOKEN_REJECTED'})
                remember = urllib.parse.parse_qs(environ.get('QUERY_STRING','')).get('remember') == ['1']
                value,expiry = browser_sessions.create(SESSION_DB,TOKEN,remember,browser_sessions.cookie_value(environ))
                headers.append(('Set-Cookie',browser_sessions.cookie_header(value,remember)))
                return reply('200 OK',{'authenticated':True,'expires_at':expiry,'remembered':remember})
            expiry = browser_sessions.validate(SESSION_DB,TOKEN,environ)
            return reply('200 OK',{'authenticated':bool(expiry),'expires_at':expiry})
        except (sqlite3.Error,OSError,ValueError):
            return reply('503 Service Unavailable',{'error':'SESSION_STORAGE_UNAVAILABLE'})
    if method == 'OPTIONS':
        return reply('204 No Content', b'')
    if method != 'GET' and not (method=='POST' and path in ('/api/research/run','/api/options/check','/api/storage/check','/api/crypto/pause','/api/crypto/resume')):
        return reply('405 Method Not Allowed', {'error': 'READ_ONLY'})
    if path == '/healthz':
        return reply('200 OK', {'service': 'heartbeat-us', 'process': 'ok', 'execution_enabled': False})
    if path == '/':
        return reply('200 OK', (ROOT/'index.html').read_bytes(), 'text/html; charset=utf-8')
    if path == '/robots.txt':
        return reply('200 OK', b'User-agent: *\nDisallow: /api/\n', 'text/plain')
    if path not in ('/api/lab/status','/api/lab/journal','/api/lab/inputs','/api/us/status', '/api/us/candles', '/api/us/observations', '/api/research/run', '/api/research/report','/api/options/check','/api/options/access','/api/storage/check','/api/decisions','/api/data/alpaca','/api/crypto/paper','/api/crypto/pause','/api/crypto/resume'):
        return reply('404 Not Found', {'error': 'NOT_FOUND'})
    if len(TOKEN) < 32:
        return reply('503 Service Unavailable', {'error': 'ACCESS_TOKEN_NOT_CONFIGURED'})
    bearer = hmac.compare_digest(environ.get('HTTP_AUTHORIZATION', '').encode(), ('Bearer '+TOKEN).encode())
    if not bearer:
        try:
            session = browser_sessions.validate(SESSION_DB,TOKEN,environ)
        except (sqlite3.Error,OSError):
            return reply('503 Service Unavailable',{'error':'SESSION_STORAGE_UNAVAILABLE'})
        if not session:
            return reply('401 Unauthorized', {'error': 'BACKEND_ACCESS_TOKEN_REQUIRED'})
        if method == 'POST' and not browser_sessions.same_origin(environ):
            return reply('403 Forbidden',{'error':'SAME_ORIGIN_REQUIRED'})
    if path.startswith('/api/lab/'):
        try:
            if path=='/api/lab/status':return reply('200 OK',LAB.status())
            query=urllib.parse.parse_qs(environ.get('QUERY_STRING',''))
            after=int(query.get('after',['0'])[0]);through=int(query['through'][0]) if 'through' in query else None
            if after<0 or (through is not None and (through<after or through>2**63-1)):raise ValueError()
            return reply('200 OK',(LAB.journal if path.endswith('journal') else LAB.inputs)(after,through))
        except ValueError:return reply('400 Bad Request',{'error':'INVALID_CURSOR'})
        except (sqlite3.Error,OSError):return reply('503 Service Unavailable',{'error':'LAB_STORAGE_UNAVAILABLE'})
    if path in ('/api/crypto/paper','/api/crypto/pause','/api/crypto/resume'):
        try:
            if path!='/api/crypto/paper':
                if method!='POST':return reply('405 Method Not Allowed',{'error':'POST_REQUIRED'})
                if not CRYPTO.enabled or not CRYPTO.started:
                    code='WORKER_DISABLED' if not CRYPTO.enabled else CRYPTO.error if CRYPTO.error in CRYPTO_CONTROL_ERRORS else 'WORKER_NOT_STARTED'
                    return reply('409 Conflict',{'error':code,'detail':'Resume only unpauses an initialized worker. Resolve the connection-checklist blocker first.','report':crypto_report()})
                CRYPTO.pause(path.endswith('/pause'))
            return reply('200 OK',crypto_report())
        except crypto_paper.PaperError as error:
            code=str(error) if str(error) in CRYPTO_CONTROL_ERRORS else 'CRYPTO_CONTROL_BLOCKED'
            return reply('409 Conflict',{'error':code,'detail':'No successful control change was confirmed. Refresh the worker report.'})
        except (sqlite3.Error,OSError):
            print('heartbeat crypto_report_or_control_failed category=storage',file=sys.stderr,flush=True)
            return reply('503 Service Unavailable',{'error':'CRYPTO_STORAGE_UNAVAILABLE','detail':'The paper-state database could not be read or written. Check the persistent disk; do not reset the ledger.'})
        except Exception as error:
            print('heartbeat crypto_report_or_control_failed exception='+type(error).__name__,file=sys.stderr,flush=True)
            return reply('503 Service Unavailable',{'error':'CRYPTO_REPORT_UNAVAILABLE','detail':'The server could not build the worker report. No successful control change is confirmed.'})
    if path=='/api/data/alpaca':
        return reply('200 OK',ALPACA.status())
    if path=='/api/decisions':
        try:return reply('200 OK',decision_journal.listing(DB,DATABASE_URL))
        except evidence_storage.StorageError:return reply('503 Service Unavailable',{'error':'DECISION_STORAGE_UNAVAILABLE'})
    if path=='/api/storage/check':
        if method!='POST':return reply('405 Method Not Allowed',{'error':'POST_REQUIRED'})
        try:return reply('200 OK',storage_status())
        except evidence_storage.StorageError:return reply('503 Service Unavailable',{'error':'STORAGE_UNAVAILABLE'})
    if path=='/api/options/check':
        if method!='POST':return reply('405 Method Not Allowed',{'error':'POST_REQUIRED'})
        ok,detail=start_option_access()
        return reply('202 Accepted' if ok else '409 Conflict',{'accepted':ok,'detail':detail})
    if path=='/api/options/access':
        if ACCESS['state']=='NOT_CHECKED':
            try:
                saved=evidence_storage.latest(DB,DATABASE_URL,'option_access')
                if saved:
                    with LOCK:ACCESS.update(state='RESTORED PREVIOUS CHECK',result=saved['payload'])
            except evidence_storage.StorageError:return reply('503 Service Unavailable',{'error':'STORAGE_UNAVAILABLE'})
        with LOCK:value=dict(ACCESS)
        return reply('200 OK',value)
    if path=='/api/research/run':
        if method!='POST':return reply('405 Method Not Allowed',{'error':'POST_REQUIRED'})
        ok,detail=start_pilot()
        return reply('202 Accepted' if ok else '409 Conflict',{'accepted':ok,'detail':detail})
    if path=='/api/research/report':
        try:restore_pilot()
        except evidence_storage.StorageError:return reply('503 Service Unavailable',{'error':'STORAGE_UNAVAILABLE'})
        with LOCK:result=dict(PILOT)
        return reply('200 OK',result)
    if path == '/api/us/status':
        return reply('200 OK', {'symbols': SYMBOLS, 'configured': bool(KEY), 'collector_started': STARTED, 'minimum_cycle_seconds': max(INTERVAL, 15*(len(SYMBOLS)+1)), 'execution_enabled': False, 'storage': 'PostgreSQL configured; recovery unverified' if DATABASE_URL else 'SQLite; persistence unverified', 'realtime_entitlement': 'UNVERIFIED'})
    symbol = urllib.parse.parse_qs(environ.get('QUERY_STRING', '')).get('symbol', ['QQQ'])[0]
    if symbol not in SYMBOLS:
        return reply('400 Bad Request', {'error': 'SYMBOL_NOT_CONFIGURED', 'symbols': SYMBOLS})
    if path == '/api/us/candles':
        return reply('200 OK', snapshot(symbol))
    try:
        return reply('200 OK', {'symbol': symbol, 'limit': 2000, 'observations': observations(symbol), 'audited': False, 'note': 'First-seen revisions, not historical decision-time knowledge. Not credited to readiness.'})
    except (sqlite3.Error, OSError, evidence_storage.StorageError):
        return reply('503 Service Unavailable', {'error': 'STORAGE_UNAVAILABLE'})

if __name__ == '__main__':
    from wsgiref.simple_server import make_server
    make_server('127.0.0.1', int(os.getenv('PORT', '8000')), application).serve_forever()
