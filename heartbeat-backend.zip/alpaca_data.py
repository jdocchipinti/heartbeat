"""Read-only options snapshot collector. No account or order endpoints."""
import json
import math
import threading
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone, timedelta

class DataError(Exception): pass

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise DataError('UNEXPECTED_REDIRECT')

def request_data(key, secret, path, params):
    allowed=('/v1beta1/options/snapshots/SPY','/v1beta1/options/snapshots/QQQ','/v1beta1/options/bars','/v1beta1/options/trades')
    if path not in allowed: raise DataError('ENDPOINT_NOT_ALLOWED')
    req=urllib.request.Request('https://data.alpaca.markets'+path+'?'+urllib.parse.urlencode(params),headers={'APCA-API-KEY-ID':key,'APCA-API-SECRET-KEY':secret,'Accept':'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=12) as r:
            raw=r.read(2000001)
        if len(raw)>2000000: raise DataError('RESPONSE_TOO_LARGE')
        data=json.loads(raw)
        if not isinstance(data,dict): raise DataError('INVALID_RESPONSE')
        return data
    except urllib.error.HTTPError as e:
        raise DataError({401:'AUTH_REJECTED',403:'ACCESS_DENIED',429:'RATE_LIMITED'}.get(e.code,'PROVIDER_HTTP_ERROR')) from None
    except (urllib.error.URLError,TimeoutError,ValueError): raise DataError('PROVIDER_UNAVAILABLE') from None

def fetch(key, secret, symbol):
    if symbol not in ('SPY','QQQ'): raise DataError('SYMBOL_NOT_ALLOWED')
    tomorrow=(datetime.now(timezone.utc)+timedelta(days=1)).date().isoformat()
    data=request_data(key,secret,'/v1beta1/options/snapshots/'+symbol,{'feed':'indicative','limit':100,'expiration_date_gte':tomorrow})
    if not isinstance(data.get('snapshots'),dict): raise DataError('INVALID_RESPONSE')
    return data

def history_probe(key,secret):
    # Two bounded requests, no current OPRA request, no pagination or auto-upgrade.
    symbol='SPY250620C00600000'
    params={'symbols':symbol,'start':'2025-06-02T14:00:00Z','end':'2025-06-02T15:00:00Z','limit':100,'sort':'asc'}
    report={'checked_at':time.time(),'contract':symbol,'start':params['start'],'end':params['end'],'results':{},'historical_bid_ask':'NOT_TESTED: these documented endpoints return bars and trades, not historical quotes','execution_enabled':False,'readiness_credit':0,'scope':'One expired SPY contract and one hour. Empty results do not prove entitlement denial or broad coverage.'}
    for kind in ('bars','trades'):
        try:
            data=request_data(key,secret,'/v1beta1/options/'+kind,{**params,**({'timeframe':'1Min'} if kind=='bars' else {})})
            grouped=data.get(kind)
            if not isinstance(grouped,dict):raise DataError('INVALID_RESPONSE')
            rows=grouped.get(symbol,[])
            if not isinstance(rows,list):raise DataError('INVALID_RESPONSE')
            report['results'][kind]={'state':'SAMPLE_RECEIVED' if rows else 'EMPTY_SAMPLE','count':len(rows),'pagination_remaining':bool(data.get('next_page_token')),'sample':rows}
        except DataError as e:report['results'][kind]={'state':'BLOCKED','error':str(e)}
    return report

def summarize(data, now):
    rows=[]
    for symbol,s in data['snapshots'].items():
        if not isinstance(s,dict): continue
        q=s.get('latestQuote') or {}
        if not isinstance(q,dict): continue
        vals=[q.get(k) for k in ('bp','ap','bs','as')]
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in vals): continue
        bid,ask,bs,asz=vals
        try:
            date=datetime.fromisoformat(str(q.get('t')).replace('Z','+00:00'))
            if date.tzinfo is None: continue
            age=now-date.timestamp()
        except (ValueError,TypeError): continue
        valid=bid>0 and ask>=bid and bs>0 and asz>0 and 0<=age<=30
        rows.append({'contract':symbol,'quote_at':q.get('t'),'bid':bid,'ask':ask,'bid_size':bs,'ask_size':asz,'spread':ask-bid,'quote_age_seconds':age,'recent_valid_quote':False,'recent_indicative_observation':valid})
    return {'quotes':rows,'valid_recent_quote_count':sum(r['recent_valid_quote'] for r in rows),'pagination_remaining':bool(data.get('next_page_token')),'coverage':'First 100 snapshots only; not a full chain or a selected strategy universe','source':'Alpaca / indicative (modified quotes)','source_family':'OPRA-derived indicative','usable_for_execution_model':False,'execution_enabled':False,'readiness_credit':0}

class Collector:
    def __init__(self,key,secret,save):
        self.key=key;self.secret=secret;self.save=save;self.lock=threading.RLock();self.started=False;self.items={};self.history={'state':'NOT_CHECKED'}
    def start(self):
        with self.lock:
            if not self.started and self.key and self.secret:
                self.started=True
                threading.Thread(target=self.loop,daemon=True,name='alpaca-data').start()
    def cycle(self,symbol):
        now=time.time()
        try:
            data=fetch(self.key,self.secret,symbol);now=time.time();item=summarize(data,now)
            item.update(state='INDICATIVE_SAMPLE_RECEIVED',received_at=now,error=None)
            # Source timestamps and received time retained; credentials never stored.
            self.save(symbol,{'received_at':now,'feed':'indicative','snapshots':data['snapshots'],'pagination_remaining':bool(data.get('next_page_token'))})
            item['saved']=True
        except Exception as e:
            item={'state':'BLOCKED','error':str(e) if isinstance(e,DataError) else 'DATA_OR_STORAGE_ERROR','received_at':now,'quotes':[],'saved':False}
        with self.lock:self.items[symbol]=item
    def check_history(self):
        try:
            report=history_probe(self.key,self.secret)
            self.save('historical-probe',report)
            report.update(state='CHECK_COMPLETE',saved=True)
        except Exception:
            report={'state':'CHECK_FAILED','error':'DATA_OR_STORAGE_ERROR','saved':False,'readiness_credit':0}
        with self.lock:self.history=report
    def loop(self):
        self.check_history()
        while True:
            for symbol in ('SPY','QQQ'):self.cycle(symbol)
            time.sleep(90)
    def status(self):
        with self.lock:
            items=json.loads(json.dumps(self.items));history=json.loads(json.dumps(self.history))
        now=time.time()
        for item in items.values():
            item['collection_age_seconds']=now-item['received_at']
            for q in item.get('quotes',[]):
                q['quote_age_seconds']+=item['collection_age_seconds']
                q['recent_valid_quote']=False
                q['recent_indicative_observation']=q.get('recent_indicative_observation',False) and 0<=q['quote_age_seconds']<=30
            item['valid_recent_quote_count']=sum(q['recent_valid_quote'] for q in item.get('quotes',[]))
            if item['collection_age_seconds']>180:item['state']='COLLECTOR_STALE'
        return {'provider':'Alpaca','configured':bool(self.key and self.secret),'collector_started':self.started,'poll_seconds':90,'mode':'FREE_RESEARCH','requested_feed':'indicative','historical_access':history,'symbols':items,'execution_enabled':False,'readiness_credit':0,'note':'Free research mode: modified indicative quotes, not executable OPRA prices. Historical bars/trades probe runs once per process. No premium snapshot requests, paper fills, orders or readiness credit. Separate from the frozen strategy.'}
