"""Read-only options snapshot collector. No account or order endpoints."""
import json
import math
import threading
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone, timedelta

class DataError(Exception): pass

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise DataError('UNEXPECTED_REDIRECT')

def fetch(key, secret, symbol):
    if symbol not in ('SPY','QQQ'): raise DataError('SYMBOL_NOT_ALLOWED')
    tomorrow=(datetime.now(timezone.utc)+timedelta(days=1)).date().isoformat()
    params=urllib.parse.urlencode({'feed':'opra','limit':100,'expiration_date_gte':tomorrow})
    req=urllib.request.Request('https://data.alpaca.markets/v1beta1/options/snapshots/'+symbol+'?'+params,headers={'APCA-API-KEY-ID':key,'APCA-API-SECRET-KEY':secret,'Accept':'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=12) as r:
            raw=r.read(2000001)
        if len(raw)>2000000: raise DataError('RESPONSE_TOO_LARGE')
        data=json.loads(raw)
        if not isinstance(data,dict) or not isinstance(data.get('snapshots'),dict): raise DataError('INVALID_RESPONSE')
        return data
    except urllib.error.HTTPError as e:
        raise DataError({401:'AUTH_REJECTED',403:'OPRA_ACCESS_DENIED',429:'RATE_LIMITED'}.get(e.code,'PROVIDER_HTTP_ERROR')) from None
    except (urllib.error.URLError,TimeoutError,ValueError): raise DataError('PROVIDER_UNAVAILABLE') from None

def summarize(data, now):
    rows=[]
    for symbol,s in data['snapshots'].items():
        if not isinstance(s,dict): continue
        q=s.get('latestQuote') or {}
        if not isinstance(q,dict): continue
        vals=[q.get(k) for k in ('bp','ap','bs','as')]
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in vals): continue
        bid,ask,bs,asz=vals
        try:
            date=datetime.fromisoformat(str(q.get('t')).replace('Z','+00:00'))
            if date.tzinfo is None: continue
            age=now-date.timestamp()
        except (ValueError,TypeError): continue
        valid=bid>0 and ask>=bid and bs>0 and asz>0 and 0<=age<=30
        rows.append({'contract':symbol,'quote_at':q.get('t'),'bid':bid,'ask':ask,'bid_size':bs,'ask_size':asz,'spread':ask-bid,'quote_age_seconds':age,'recent_valid_quote':valid})
    return {'quotes':rows,'valid_recent_quote_count':sum(r['recent_valid_quote'] for r in rows),'pagination_remaining':bool(data.get('next_page_token')),'coverage':'First 100 snapshots only; not a full chain or a selected strategy universe','source':'Alpaca / OPRA','source_family':'OPRA','execution_enabled':False,'readiness_credit':0}

class Collector:
    def __init__(self,key,secret,save):
        self.key=key;self.secret=secret;self.save=save;self.lock=threading.RLock();self.started=False;self.items={}
    def start(self):
        with self.lock:
            if not self.started and self.key and self.secret:
                self.started=True
                threading.Thread(target=self.loop,daemon=True,name='alpaca-data').start()
    def cycle(self,symbol):
        now=time.time()
        try:
            data=fetch(self.key,self.secret,symbol);now=time.time();item=summarize(data,now)
            item.update(state='OPRA_SAMPLE_RECEIVED',received_at=now,error=None)
            # Source timestamps and received time retained; credentials never stored.
            self.save(symbol,{'received_at':now,'feed':'opra','snapshots':data['snapshots'],'pagination_remaining':bool(data.get('next_page_token'))})
            item['saved']=True
        except Exception as e:
            item={'state':'BLOCKED','error':str(e) if isinstance(e,DataError) else 'DATA_OR_STORAGE_ERROR','received_at':now,'quotes':[],'saved':False}
        with self.lock:self.items[symbol]=item
    def loop(self):
        while True:
            for symbol in ('SPY','QQQ'):self.cycle(symbol)
            time.sleep(90)
    def status(self):
        with self.lock:items=json.loads(json.dumps(self.items))
        now=time.time()
        for item in items.values():
            item['collection_age_seconds']=now-item['received_at']
            for q in item.get('quotes',[]):
                q['quote_age_seconds']+=item['collection_age_seconds']
                q['recent_valid_quote']=q['recent_valid_quote'] and 0<=q['quote_age_seconds']<=30
            item['valid_recent_quote_count']=sum(q['recent_valid_quote'] for q in item.get('quotes',[]))
            if item['collection_age_seconds']>180:item['state']='COLLECTOR_STALE'
        return {'provider':'Alpaca','configured':bool(self.key and self.secret),'collector_started':self.started,'poll_seconds':90,'requested_feed':'opra','symbols':items,'execution_enabled':False,'readiness_credit':0,'note':'Separate quote-access collector. Not yet used by the frozen decision strategy; no indicative fallback, historical backfill, paper fills or order calls.'}
