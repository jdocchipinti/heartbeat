"""HB-CRYPTO-PAPER-001. Dedicated Alpaca PAPER account only; no live URL configurable."""
import guardian
import crypto_feed
import copy
import fcntl
import hashlib
import json
import math
import os
import sqlite3
import shutil
import threading
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN, ROUND_UP
from pathlib import Path
from zoneinfo import ZoneInfo
from alpaca_data import NoRedirect

CONFIG={'version':'HB-CRYPTO-PAPER-001','symbols':['BTC/USD','ETH/USD'],'paper_budget':50,'position_cap':5,'daily_loss_limit':5,'max_entries_per_day':1,'fee_allowance_per_side':0.005,'max_spread':0.005,'quote_max_age':15,'stop_fraction':0.02,'target_fraction':0.04,'max_hold_seconds':3600,'interval_seconds':60,'warmup_observations':21,'day_timezone':'America/Denver'}
CONFIG_HASH=hashlib.sha256(json.dumps(CONFIG,sort_keys=True).encode()).hexdigest()
SOURCE_HASH=hashlib.sha256(Path(__file__).read_bytes()+Path(guardian.__file__).read_bytes()+Path(crypto_feed.__file__).read_bytes()).hexdigest()
PRE_GUARDIAN_HASH='9298dcd9009be0e12752019cd07ac83208b03536802f1b36c6dfc02e07f7eaca'
PRE_COLLECTION_HASH='97fb09c9db268e4b68ebda8d7687f333466c86f36a5797d8b6c41f4b510d84fc'
TERMINAL={'filled','canceled','expired','rejected'}
class PaperError(Exception):pass

def api(key,secret,route,params=None,body=None):
    market=route=='/v1beta3/crypto/us/latest/quotes'
    if not (market or route in ('/v2/account','/v2/assets','/v2/positions','/v2/orders','/v2/orders:by_client_order_id')):raise PaperError('ROUTE_BLOCKED')
    if body is not None:
        try:guardian.order_shape(body)
        except guardian.GuardianBlocked as e:raise PaperError('GUARDIAN_'+str(e)) from None
        if route!='/v2/orders' or body.get('type')!='limit' or body.get('time_in_force')!='ioc' or body.get('symbol') not in CONFIG['symbols'] or body.get('side') not in ('buy','sell') or not body.get('client_order_id','').startswith('hbcp1-'):raise PaperError('ORDER_BLOCKED')
    url=('https://data.alpaca.markets' if market else 'https://paper-api.alpaca.markets')+route
    if params:url+='?'+urllib.parse.urlencode(params)
    req=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,headers={'APCA-API-KEY-ID':key,'APCA-API-SECRET-KEY':secret,'Content-Type':'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=12) as r:raw=r.read(2000001)
        if len(raw)>2000000:raise PaperError('RESPONSE_TOO_LARGE')
        return json.loads(raw)
    except urllib.error.HTTPError as e:raise PaperError({401:'AUTH_REJECTED',403:'PAPER_ACCESS_DENIED',404:'NOT_FOUND',422:'ORDER_REJECTED',429:'RATE_LIMITED'}.get(e.code,'BROKER_HTTP_ERROR')) from None
    except Exception as e:
        if isinstance(e,PaperError):raise
        raise PaperError('REQUEST_UNCERTAIN') from None

def number(v):
    if isinstance(v,bool):raise PaperError('INVALID_NUMBER')
    try:f=float(v)
    except (ValueError,TypeError):raise PaperError('INVALID_NUMBER') from None
    if not math.isfinite(f):raise PaperError('INVALID_NUMBER')
    return f

def quote(q,now):
    try:
        t=datetime.fromisoformat(q['t'].replace('Z','+00:00'))
        if t.tzinfo is None:raise ValueError()
        age=now-t.timestamp()
        bid,ask,bs,asz=[number(q[k]) for k in ('bp','ap','bs','as')]
        if not 0<=age<=CONFIG['quote_max_age'] or not 0<bid<=ask or min(bs,asz)<=0:raise ValueError()
        return {'t':q['t'],'bid':bid,'ask':ask,'bid_size':bs,'ask_size':asz,'mid':(bid+ask)/2,'spread_fraction':(ask-bid)/((ask+bid)/2)}
    except (KeyError,ValueError,TypeError):raise PaperError('STALE_OR_INVALID_QUOTE') from None

def size_order(asset,q,budget,side='buy',qty=None):
    if asset.get('tradable') is not True or asset.get('class')!='crypto' or asset.get('status')!='active':raise PaperError('ASSET_NOT_ELIGIBLE')
    try:
        step=Decimal(str(asset['min_trade_increment']));tick=Decimal(str(asset['price_increment']));minimum=Decimal(str(asset['min_order_size']))
        if min(step,tick,minimum)<=0:raise ValueError()
        price=(Decimal(str(q['ask'] if side=='buy' else q['bid']))/tick).to_integral_value(rounding=ROUND_UP if side=='buy' else ROUND_DOWN)*tick
        amount=(Decimal(str(budget))/(Decimal('1.005')*price) if qty is None else Decimal(str(qty)))
        amount=(amount/step).to_integral_value(rounding=ROUND_DOWN)*step
        if amount<minimum:raise PaperError('MINIMUM_EXCEEDS_POSITION_LIMIT')
        if float(amount)>q['ask_size' if side=='buy' else 'bid_size']:raise PaperError('DISPLAYED_SIZE_INSUFFICIENT')
        if price<=0 or amount<=0:raise ValueError()
        return format(amount,'f'),format(price,'f')
    except (KeyError,ValueError,ArithmeticError):raise PaperError('ASSET_RULES_INVALID') from None

def signal(history):
    if len(history)<21:return False
    rows=history[-21:]
    if any(not 40<=rows[i]['at']-rows[i-1]['at']<=90 for i in range(1,21)):return False
    values=[r['mid'] for r in rows]
    return values[-1]>max(values[:-1]) and sum(values[-5:])/5>sum(values[-20:])/20

class Experiment:
    def __init__(self,path,key,secret,enabled=False):
        self.path=path;self.key=key;self.secret=secret;self.enabled=enabled;self.lock=threading.RLock();self.started=False;self.filelock=None;self.error=None;self.last_tick=None;self.view={};self.guardian_review=None;self.guardian_loss=0;self.s=None;self.cached_status=None;self.feed=None
    def db(self):
        c=sqlite3.connect(self.path,timeout=10);c.execute('PRAGMA journal_mode=WAL');return c
    def initialize(self):
        os.makedirs(os.path.dirname(self.path),exist_ok=True)
        self.filelock=open(self.path+'.lock','a')
        fcntl.flock(self.filelock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with self.db() as c:
            c.execute('CREATE TABLE IF NOT EXISTS cp_state (id INTEGER PRIMARY KEY, payload TEXT NOT NULL)')
            c.execute('CREATE TABLE IF NOT EXISTS cp_events (id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL, payload TEXT NOT NULL)')
            row=c.execute('SELECT payload FROM cp_state WHERE id=1').fetchone()
        self.s=json.loads(row[0]) if row else {'config_hash':CONFIG_HASH,'source_hash':SOURCE_HASH,'cash':50.0,'position':None,'pending':None,'entries':{},'history':{},'paused':False,'realized_estimate':0.0,'closed_trades':0,'wins':0,'peak':50.0,'max_drawdown':0.0,'benchmark':{},'day_start':{},'last_observation':None}
        if self.s['config_hash']==CONFIG_HASH and self.s.get('source_hash') in (PRE_GUARDIAN_HASH,PRE_COLLECTION_HASH):
            # Exact predecessor only; retain cash, open/pending orders, journal and pause state.
            previous=self.s['source_hash'];self.s['source_hash']=SOURCE_HASH;self.s['history']={};self.s['collection_version']=crypto_feed.VERSION
            self.persist({'kind':'COLLECTION_UPGRADE','at':time.time(),'previous_source_hash':previous,'source_hash':SOURCE_HASH,'guardian_version':guardian.POLICY['version'],'note':'Independent quote polling and receive-time validation. Warmup restarted; financial state, pending orders and limits preserved.'})
        if self.s['config_hash']!=CONFIG_HASH or self.s.get('source_hash')!=SOURCE_HASH:raise PaperError('CONFIG_CHANGED_START_NEW_EXPERIMENT')
    def persist(self,event):
        with self.db() as c:
            c.execute('INSERT INTO cp_state VALUES (1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload',(json.dumps(self.s,allow_nan=False),))
            c.execute('INSERT INTO cp_events(at,payload) VALUES (?,?)',(time.time(),json.dumps(event,allow_nan=False)))
    def backup(self,now):
        day=datetime.fromtimestamp(now,timezone.utc).date().isoformat()
        target=self.path+'.'+day+'.backup'
        if os.path.exists(target):return
        # SQLite native online backup, not a copy of an open WAL database.
        with self.db() as source:
            dest=sqlite3.connect(target+'.tmp')
            try:source.backup(dest)
            finally:dest.close()
        os.replace(target+'.tmp',target)
        old=sorted(Path(self.path).parent.glob(Path(self.path).name+'.*.backup'))
        for path in old[:-2]:path.unlink()
    def call(self,route,params=None,body=None):return api(self.key,self.secret,route,params,body)
    def start(self):
        with self.lock:
            if self.started or not self.enabled:return
            if not self.key or not self.secret:self.error='ALPACA_KEYS_MISSING';return
            # Require real mounted storage, not a path that merely resembles a disk.
            if not os.path.ismount('/var/data') or not os.path.realpath(self.path).startswith('/var/data/'):
                self.error='PERSISTENT_DISK_REQUIRED';return
            try:self.initialize()
            except Exception:self.error='STORAGE_OR_SINGLE_WORKER_LOCK_FAILED';return
            self.feed=crypto_feed.Collector(self.path,lambda:self.call('/v1beta3/crypto/us/latest/quotes',{'symbols':','.join(CONFIG['symbols'])}))
            self.feed.start()
            self.started=True
            threading.Thread(target=self.loop,daemon=True,name='crypto-paper').start()
    def submit(self,symbol,side,q,asset,now,day,reason,qty=None):
        if self.started:
            now=time.time();day=datetime.fromtimestamp(now,ZoneInfo('America/Denver')).date().isoformat() # Recheck source age immediately before authorization.
        amount,price=size_order(asset,q,min(CONFIG['position_cap'],self.s['cash']),side,qty)
        cid='hbcp1-'+hashlib.sha256(f'{symbol}:{side}:{now}:{self.s["closed_trades"]}'.encode()).hexdigest()[:30]
        order={'symbol':symbol,'qty':amount,'side':side,'type':'limit','time_in_force':'ioc','limit_price':price,'client_order_id':cid}
        try:
            verdict=guardian.authorize(order,self.s,q,now,day,self.guardian_review,self.s['history'].get(symbol,[]),self.guardian_loss)
        except guardian.GuardianBlocked as e:
            self.persist({'kind':'GUARDIAN_BLOCK','at':now,'symbol':symbol,'side':side,'reason':str(e),'policy_version':guardian.POLICY['version']})
            raise PaperError('GUARDIAN_'+str(e)) from None
        self.persist({'kind':'GUARDIAN_ALLOW','at':now,'symbol':symbol,'side':side,'order_id':cid,**verdict,'policy_version':guardian.POLICY['version']})
        self.s['pending']={'order':order,'at':now,'quote':q,'reason':reason}
        if side=='buy':self.s['entries'][day]=self.s['entries'].get(day,0)+1
        # Commit intent before network call; an uncertain call is NEVER resubmitted.
        self.persist({'kind':'ORDER_INTENT','paper_only':True,**self.s['pending']})
        try:
            response=self.call('/v2/orders',body=order)
            self.s['order_lifecycle']={'client_order_id':cid,'status':response.get('status','unknown'),'received_at':time.time(),'symbol':symbol,'side':side,'filled_qty':response.get('filled_qty'),'filled_avg_price':response.get('filled_avg_price'),'broker_at':response.get('updated_at')};self.persist({'kind':'SUBMIT_RESPONSE',**self.s['order_lifecycle']})
        except PaperError as e:
            if str(e)=='ORDER_REJECTED':
                self.s['pending']=None;self.s['order_lifecycle']={'client_order_id':cid,'status':'rejected','received_at':time.time(),'symbol':symbol,'side':side,'filled_qty':'0','error':'ORDER_REJECTED'};self.persist({'kind':'SUBMIT_REJECTED',**self.s['order_lifecycle']});return
            self.s['order_lifecycle']={'client_order_id':cid,'status':'submission_uncertain','received_at':time.time(),'symbol':symbol,'side':side,'error':str(e)};self.persist({'kind':'SUBMIT_UNCERTAIN',**self.s['order_lifecycle']})
    def reconcile(self,now):
        p=self.s['pending']
        if not p:return
        r=self.call('/v2/orders:by_client_order_id',{'client_order_id':p['order']['client_order_id']})
        if r.get('client_order_id')!=p['order']['client_order_id']:raise PaperError('ORDER_ID_MISMATCH')
        lifecycle={'client_order_id':p['order']['client_order_id'],'status':r.get('status','unknown'),'symbol':p['order']['symbol'],'side':p['order']['side'],'filled_qty':r.get('filled_qty'),'filled_avg_price':r.get('filled_avg_price'),'broker_at':r.get('updated_at') or r.get('filled_at')}
        previous=self.s.get('order_lifecycle',{})
        if any(previous.get(k)!=v for k,v in lifecycle.items()):
            self.s['order_lifecycle']={**lifecycle,'received_at':now};self.persist({'kind':'ORDER_STATUS',**self.s['order_lifecycle']})
        if r.get('status') not in TERMINAL:
            if now-p['at']>120:self.s['paused']=True;raise PaperError('ORDER_NOT_TERMINAL')
            return
        qty=number(r.get('filled_qty',0));price=number(r.get('filled_avg_price') or 0)
        if qty<0 or qty>number(p['order']['qty'])+1e-10 or (qty>0 and price<=0):raise PaperError('INVALID_BROKER_FILL')
        value=qty*price;fee=value*CONFIG['fee_allowance_per_side']
        if qty:
            if p['order']['side']=='buy':
                if value+fee>CONFIG['position_cap']+1e-6 or self.s['position']:raise PaperError('FILL_RISK_MISMATCH')
                self.s['cash']-=value+fee
                self.s['position']={'symbol':p['order']['symbol'],'qty':qty,'cost':value+fee,'entry_price':price,'entered_at':now}
            else:
                pos=self.s['position']
                if not pos or qty>pos['qty']+1e-10:raise PaperError('POSITION_MISMATCH')
                fraction=min(1,qty/pos['qty']);cost=pos['cost']*fraction
                pnl=value-fee-cost;self.s['cash']+=value-fee;self.s['realized_estimate']+=pnl
                pos['qty']-=qty;pos['cost']-=cost
                if pos['qty']<=1e-10:
                    self.s['position']=None;self.s['closed_trades']+=1
                    if self.s['cash']>self.s.get('cash_before_entry',50):self.s['wins']+=1
        self.s['pending']=None
        self.persist({'kind':'PAPER_ORDER_RECONCILED','order':p['order'],'broker_status':r['status'],'filled_qty':qty,'filled_avg_price':price,'broker_filled_at':r.get('filled_at'),'modeled_fee_allowance':fee,'fee_note':'Assumed 0.5% per side; not verified account fees. Fee-related quantity differences block further orders.','decision_quote':p['quote']})
    def tick(self,now=None):
        if shutil.disk_usage(os.path.dirname(self.path)).free<64*1024*1024:raise PaperError('DISK_SPACE_LOW')
        supplied_now=now is not None
        now=now or time.time();day=datetime.fromtimestamp(now,ZoneInfo('America/Denver')).date().isoformat()
        self.reconcile(now)
        acct=self.call('/v2/account')
        if acct.get('status')!='ACTIVE' or acct.get('trading_blocked') or acct.get('account_blocked'):raise PaperError('PAPER_ACCOUNT_BLOCKED')
        # Use a dedicated paper account: unknown orders/positions cause a stop.
        orders=self.call('/v2/orders',{'status':'open','limit':100})
        known=self.s['pending']['order']['client_order_id'] if self.s['pending'] else None
        if not isinstance(orders,list) or any(o.get('client_order_id')!=known for o in orders):raise PaperError('UNMANAGED_OPEN_ORDERS')
        positions=self.call('/v2/positions');pos=self.s['position']
        if not isinstance(positions,list):raise PaperError('INVALID_POSITIONS')
        if not pos and positions:raise PaperError('DEDICATED_PAPER_ACCOUNT_REQUIRED')
        if pos:
            matched=[p for p in positions if p.get('symbol','').replace('/','')==pos['symbol'].replace('/','')]
            if len(positions)!=1 or len(matched)!=1 or abs(number(matched[0].get('qty'))-pos['qty'])>1e-9:raise PaperError('POSITION_OR_FEE_QUANTITY_MISMATCH')
        assets=self.call('/v2/assets',{'asset_class':'crypto','status':'active'})
        if not isinstance(assets,list):raise PaperError('INVALID_ASSETS')
        assets={a['symbol']:a for a in assets if a.get('symbol') in CONFIG['symbols']}
        if self.feed:
            if not supplied_now:now=time.time()
            feed_status=self.feed.snapshot(now);data={'quotes':feed_status['quotes']}
        else:
            data=self.call('/v1beta3/crypto/us/latest/quotes',{'symbols':','.join(CONFIG['symbols'])})
            if not supplied_now:now=time.time()
            feed_status={'version':crypto_feed.VERSION,'diagnostics':{s:crypto_feed.diagnose(data.get('quotes',{}).get(s),now) for s in CONFIG['symbols']}}
        day=datetime.fromtimestamp(now,ZoneInfo('America/Denver')).date().isoformat()
        checklist={}
        quotes={};findings={}
        for symbol in CONFIG['symbols']:
            previous_history_at=(self.s['history'].get(symbol) or [{}])[-1].get('at')
            try:
                q=quote(data.get('quotes',{}).get(symbol,{}),now);quotes[symbol]=q
                h=self.s['history'].setdefault(symbol,[])
                if not h or now-h[-1]['at']>=40:h.append({'at':now,'mid':q['mid'],'source_at':q['t']})
                self.s['history'][symbol]=h[-21:]
                self.s['benchmark'].setdefault(symbol,q['mid'])
                findings[symbol]={'tokyo':'Quote-price activity only; no volume/flow inference','palermo':'BREAKOUT' if signal(h) else 'NO_TRIGGER','denver':'Experimental rule; events not screened; no proven edge','stockholm':{'spread_fraction':q['spread_fraction'],'displayed_bid_size':q['bid_size'],'displayed_ask_size':q['ask_size']},'professor':'Paper experiment only; hard limits govern orders'}
            except PaperError as e:findings[symbol]={'blocked':feed_status['diagnostics'][symbol]['reason']}
            h=self.s['history'].get(symbol,[]);streak=1 if h and 0<=now-h[-1]['at']<=15 else 0
            if streak:
                for a,b in reversed(list(zip(h,h[1:]))):
                    if 40<=b['at']-a['at']<=90:streak+=1
                    else:break
            check={'sample_interval_seconds':now-previous_history_at if previous_history_at is not None else None,'missing_sample':symbol not in quotes,'quote':feed_status['diagnostics'][symbol],'consecutive_observations':streak,'required':21,'breakout':signal(h) if streak>=21 else False,'spread_pass':bool(symbol in quotes and quotes[symbol]['spread_fraction']<=CONFIG['max_spread']),'broker_minimum':'NOT_CHECKED_NO_FRESH_QUOTE'}
            if symbol in quotes:
                asset=assets.get(symbol,{})
                try:
                    amount,price=size_order(asset,quotes[symbol],min(5,self.s['cash']))
                    check.update(broker_minimum='PASS',proposed_qty=amount,limit_price=price,cost_with_fee=float(amount)*float(price)*1.005)
                except PaperError as e:check['broker_minimum']=str(e)
                check['asset_rules']={k:asset.get(k) for k in ('min_order_size','min_trade_increment','price_increment','tradable')}
                try:
                    minimum=Decimal(str(asset['min_order_size']));step=Decimal(str(asset['min_trade_increment']));tick=Decimal(str(asset['price_increment']))
                    minimum=(minimum/step).to_integral_value(rounding=ROUND_UP)*step
                    price=(Decimal(str(quotes[symbol]['ask']))/tick).to_integral_value(rounding=ROUND_UP)*tick
                    check['minimum_cost_with_fee']=float(minimum*price*Decimal('1.005'))
                except (KeyError,ValueError,ArithmeticError):pass
            check['blocker']=check['quote']['reason'] if symbol not in quotes else 'WARMUP_OR_DATA_GAP' if streak<21 else 'BREAKOUT_NOT_CONFIRMED' if not check['breakout'] else 'SPREAD_LIMIT' if not check['spread_pass'] else check['broker_minimum'] if check['broker_minimum']!='PASS' else 'ENTRY_CHECKS_PASSED'
            checklist[symbol]=check
        equity=self.s['cash']
        if pos:
            if pos['symbol'] not in quotes:raise PaperError('OPEN_POSITION_QUOTE_STALE')
            equity+=pos['qty']*quotes[pos['symbol']]['bid']*(1-CONFIG['fee_allowance_per_side'])
        self.s['peak']=max(self.s['peak'],equity)
        self.s['max_drawdown']=max(self.s['max_drawdown'],1-equity/self.s['peak'])
        self.s['day_start'].setdefault(day,equity)
        loss=self.s['day_start'][day]-equity
        if loss>=CONFIG['daily_loss_limit']:self.s['paused']=True
        self.guardian_loss=loss
        self.guardian_review=guardian.review(findings,quotes,self.s['history'],now)
        for symbol,check in checklist.items():
            check['guardian']=self.guardian_review['symbols'][symbol]['complete']
            if self.s['pending']:check['blocker']='PENDING_ORDER'
            elif self.s['position']:check['blocker']='POSITION_OPEN'
            elif self.s['paused']:check['blocker']='ENTRIES_PAUSED'
            elif self.s['entries'].get(day,0)>=1:check['blocker']='DAILY_ENTRY_LIMIT'
            elif number(acct.get('non_marginable_buying_power',0))<5:check['blocker']='INSUFFICIENT_PAPER_BUYING_POWER'
        reason='; '.join(s+': '+c['blocker'] for s,c in checklist.items())
        if not self.s['pending'] and pos:
            q=quotes[pos['symbol']];change=q['bid']/pos['entry_price']-1
            if change<=-CONFIG['stop_fraction'] or change>=CONFIG['target_fraction'] or now-pos['entered_at']>=CONFIG['max_hold_seconds'] or loss>=CONFIG['daily_loss_limit']:
                reason='EXIT_CONDITION'
                self.submit(pos['symbol'],'sell',q,assets.get(pos['symbol'],{}),now,day,reason,pos['qty'])
        elif not self.s['pending'] and not self.s['paused'] and self.s['entries'].get(day,0)<CONFIG['max_entries_per_day']:
            for symbol in CONFIG['symbols']:
                if symbol not in quotes:continue
                q=quotes[symbol]
                if q['spread_fraction']>CONFIG['max_spread'] or not signal(self.s['history'][symbol]):continue
                if number(acct.get('non_marginable_buying_power',0))<CONFIG['position_cap']:raise PaperError('INSUFFICIENT_PAPER_BUYING_POWER')
                self.s['cash_before_entry']=self.s['cash']
                try:self.submit(symbol,'buy',q,assets.get(symbol,{}),now,day,'21-observation breakout');reason='PAPER_ENTRY_SUBMITTED'
                except PaperError as e:reason=str(e)
                break
        self.s['last_observation']=now
        self.view={'collection_version':crypto_feed.VERSION,'feed':feed_status,'entry_checklist':checklist,'guardian':self.guardian_review,'broker_paper_buying_power':number(acct['non_marginable_buying_power']) if acct.get('non_marginable_buying_power') is not None else None,'equity_estimate':equity,'reason':reason,'quotes':quotes,'agents':findings,'day_loss_estimate':loss,'benchmark_gross':50*sum(quotes[s]['mid']/self.s['benchmark'][s] for s in CONFIG['symbols'])/2 if len(quotes)==2 else None,'benchmark_note':'Equal-weight BTC/ETH buy-and-hold reference, gross midpoint prices; not a net execution comparison.'}
        self.persist({'kind':'OBSERVATION','at':now,**self.view})
        self.backup(now)
    def loop(self):
        while True:
            cycle_started=time.monotonic()
            with self.lock:
                try:self.tick();self.error=None
                except Exception as e:
                    self.error=str(e) if isinstance(e,PaperError) else 'DATA_OR_STORAGE_FAILURE'
                    # Stop new entries after any error; pending reconciliation continues.
                    if self.s:
                        self.s['paused']=True
                        try:self.persist({'kind':'ERROR','error':self.error})
                        except Exception:pass
                self.last_tick=time.time()
            time.sleep(max(1,CONFIG['interval_seconds']-(time.monotonic()-cycle_started)))
    def status(self):
        if not self.lock.acquire(timeout=0.05):
            cached=copy.deepcopy(self.cached_status) if self.cached_status else {'experiment':CONFIG,'enabled':self.enabled,'worker_started':self.started,'error':None,'state':None,'events':[],'execution_enabled':False,'readiness_credit':0}
            cached.update(cycle_in_progress=True,last_tick=self.last_tick,heartbeat_age_seconds=time.time()-self.last_tick if self.last_tick else None)
            return cached
        try:
            events=[];orders=[]
            if self.s:
                with self.db() as c:
                    events=[json.loads(r[0]) for r in c.execute('SELECT payload FROM cp_events ORDER BY id DESC LIMIT 50')]
                    orders=[{'recorded_at':r[0],**json.loads(r[1])} for r in c.execute("SELECT at,payload FROM cp_events WHERE json_extract(payload,'$.kind') IN ('ORDER_INTENT','SUBMIT_RESPONSE','SUBMIT_UNCERTAIN','SUBMIT_REJECTED','ORDER_STATUS','PAPER_ORDER_RECONCILED','GUARDIAN_BLOCK') ORDER BY id DESC LIMIT 30")]
            self.cached_status={'guardian_policy':dict(guardian.POLICY),'guardian':copy.deepcopy(self.guardian_review),'experiment':CONFIG,'config_sha256':CONFIG_HASH,'enabled':self.enabled,'worker_started':self.started,'last_tick':self.last_tick,'heartbeat_age_seconds':time.time()-self.last_tick if self.last_tick else None,'error':self.error,'state':copy.deepcopy(self.s),'latest':copy.deepcopy(self.view),'events':events,'order_events':orders,'collection_version':crypto_feed.VERSION,'execution_enabled':False,'paper_order_submission_enabled':self.enabled,'readiness_credit':0,'note':'Alpaca PAPER orders only. P&L deducts modeled fees, not reconciled actual fees. Not revenue. Pausing blocks entries; exits and pending-order reconciliation continue.'}
            return copy.deepcopy(self.cached_status)
        finally:self.lock.release()
    def pause(self,value):
        if not self.lock.acquire(timeout=0.2):raise PaperError('CYCLE_BUSY_RETRY')
        try:
            if self.s is None:raise PaperError('WORKER_NOT_STARTED')
            self.s['paused']=value;self.persist({'kind':'PAUSE' if value else 'RESUME'})
        finally:self.lock.release()
