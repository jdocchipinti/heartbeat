import unittest,tempfile,sqlite3,json,os
from pathlib import Path
from datetime import datetime,timezone
import entry_lab as lab

def quote(mid,at):return {'t':datetime.fromtimestamp(at,timezone.utc).isoformat(),'bid':mid-.01,'ask':mid+.01,'mid':mid,'bid_size':100.,'ask_size':100.}
class ComparisonTests(unittest.TestCase):
 def feed(self,s,i,mid):
  at=s['start']+i*60
  return lab.advance(s,i,at,{'quotes':{'BTC/USD':quote(mid,at)}})
 def test_next_quote_only_costs_and_losing_exit(self):
  s=lab.initial(100000,0)
  for i in range(21):events=self.feed(s,i,100+i*.1)
  a=s['accounts']['current'];self.assertIsNone(a['position']);self.assertIsNotNone(a['pending'])
  self.feed(s,21,102);self.assertLess(a['cash'],50);self.assertLessEqual(a['position']['cost'],5.00000001)
  self.feed(s,22,98);self.assertEqual(a['pending']['side'],'sell')
  events=self.feed(s,23,98);closed=next(e for e in events if e['variant']=='current' and e['kind']=='CLOSED')
  self.assertLess(closed['net_outcome'],0);self.assertGreater(closed['max_observed_loss'],0);self.assertAlmostEqual(a['cash']-50,closed['net_outcome'])
 def test_missed_limit_retained(self):
  s=lab.initial(100000,0)
  for i in range(22):events=self.feed(s,i,100+i*.1)
  self.assertIsNone(s['accounts']['current']['position']);self.assertTrue(any(e['kind']=='UNFILLED' and e['variant']=='current' for e in events))
 def test_stale_future_and_gap(self):
  self.assertFalse(lab.good_quote(quote(100,120),100));self.assertFalse(lab.good_quote(quote(100,80),100))
  s=lab.initial(100000,0)
  for i in range(21):self.feed(s,i,100+i*.1)
  self.assertFalse(lab.breakout([{'at':i*120,'mid':100+i} for i in range(21)]))
 def test_earlier_and_later_are_distinct(self):
  h=[{'at':i*60,'mid':v} for i,v in enumerate([110]+[100]*14+[101,102,103,104,105,106])]
  self.assertTrue(lab.breakout(h,5));self.assertFalse(lab.breakout(h))
  s=lab.initial(100000,0)
  for i in range(21):self.feed(s,i,100+i*.1)
  self.assertIsNone(s['accounts']['later']['pending']);self.feed(s,21,102.1);self.assertIsNotNone(s['accounts']['later']['pending'])
 def test_pullback_expires_and_window_censors(self):
  s=lab.initial(100000,0);a=s['accounts']['pullback'];a['armed']['BTC/USD']={'at':100000,'price':100}
  events=self.feed(s,11,100);self.assertTrue(any(e['reason']=='PULLBACK_NEVER_REACHED' for e in events))
  a['armed']['BTC/USD']={'at':100660,'price':100};self.assertTrue(any(e['kind']=='CENSORED' for e in lab.finish(s)));self.assertEqual(s['status'],'COMPLETE')
 def test_registration_idempotence_readonly_and_restart(self):
  with tempfile.TemporaryDirectory() as d:
   source=d+'/source';path=d+'/lab'
   with sqlite3.connect(source) as db:
    db.execute('CREATE TABLE cp_events(id INTEGER PRIMARY KEY,at REAL,payload TEXT)');db.execute('INSERT INTO cp_events VALUES(1,90,?)',(json.dumps({'kind':'OBSERVATION'}),))
   x=lab.Lab(source,path);x.initialize(100)
   with sqlite3.connect(source) as db:db.execute('INSERT INTO cp_events VALUES(2,160,?)',(json.dumps({'kind':'OBSERVATION','quotes':{'BTC/USD':quote(100,160)}}),))
   original=Path(source).read_bytes();x.tick(161);x.tick(162);self.assertEqual(x.status()['state']['inputs'],1);self.assertEqual(Path(source).read_bytes(),original)
   self.assertEqual(len(x.inputs()['inputs']),1);self.assertEqual(x.journal()['events'][0]['kind'],'REGISTERED')
   x.filelock.close();y=lab.Lab(source,path);y.initialize(200);self.assertEqual(y.status()['state']['start'],100);y.filelock.close()
   state=x.status()['state'];state['code_hash']='changed'
   with self.assertRaises(ValueError):x.validate(state)
if __name__=='__main__':unittest.main()

class ApiTests(unittest.TestCase):
 def test_auth_and_no_mutation(self):
  import server
  from unittest.mock import patch
  with patch.object(server,'TOKEN','x'*32),patch.object(server,'ensure_started'),patch.object(server.browser_sessions,'validate',return_value=None):
   for method,auth,expected in [('GET','',401),('POST','Bearer '+'x'*32,405),('GET','Bearer '+'x'*32,200)]:
    status=[]
    with patch.object(server.LAB,'status',return_value={'hypothetical_only':True}):
     raw=b''.join(server.application({'PATH_INFO':'/api/lab/status','REQUEST_METHOD':method,'HTTP_AUTHORIZATION':auth},lambda code,headers:status.append(code)))
    self.assertTrue(status[0].startswith(str(expected)))
