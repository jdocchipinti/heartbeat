import json,sqlite3,tempfile,unittest,time
from pathlib import Path
from unittest.mock import patch
from datetime import datetime,timezone
import crypto_feed as f
import crypto_paper as c
from test_crypto_paper import ASSET

def raw(at):return {'t':datetime.fromtimestamp(at,timezone.utc).isoformat(),'bp':100,'ap':100.01,'bs':2,'as':2}
class FeedTests(unittest.TestCase):
 def test_diagnostics_distinguish_failures(self):
  for q,expected in [(None,'MISSING'),({},'MALFORMED'),(raw(80),'STALE'),(raw(101),'FUTURE'),(raw(99),'FRESH')]:self.assertEqual(f.diagnose(q,100)['state'],expected)
 def test_receipt_time_not_request_start_and_restart(self):
  with tempfile.TemporaryDirectory() as d:
   x=f.Collector(d+'/db',lambda:{'quotes':{'BTC/USD':raw(105),'ETH/USD':raw(80)}});x.initialize();x.poll(lambda:106)
   self.assertEqual(x.snapshot(106)['diagnostics']['BTC/USD']['state'],'FRESH')
   self.assertEqual(x.snapshot(106)['diagnostics']['ETH/USD']['state'],'STALE')
   y=f.Collector(d+'/db',None);y.initialize();self.assertEqual(y.snapshot(122)['diagnostics']['BTC/USD']['state'],'STALE')
   self.assertEqual(y.snapshot(106)['quotes']['BTC/USD']['t'],raw(105)['t'])
 def test_failures_are_safe_and_persisted(self):
  with tempfile.TemporaryDirectory() as d:
   def fail():raise ValueError('secret')
   x=f.Collector(d+'/db',fail);x.initialize();x.poll(lambda:100)
   self.assertEqual(x.snapshot(100)['error'],'FEED_UNAVAILABLE');self.assertNotIn('secret',json.dumps(x.snapshot(100)))
 def test_migration_keeps_financial_state_and_restarts_warmup(self):
  with tempfile.TemporaryDirectory() as d:
   x=c.Experiment(d+'/db','key','secret');x.initialize();x.s.update(source_hash=c.PRE_COLLECTION_HASH,cash=48,paused=True,pending={'order':{'client_order_id':'keep'}},history={'BTC/USD':[{'at':1,'mid':1}]});x.persist({'kind':'fixture'});x.filelock.close()
   y=c.Experiment(d+'/db','key','secret');y.initialize();self.assertEqual(y.s['cash'],48);self.assertTrue(y.s['paused']);self.assertEqual(y.s['pending']['order']['client_order_id'],'keep');self.assertEqual(y.s['history'],{})
   self.assertEqual(y.status()['events'][0]['kind'],'COLLECTION_UPGRADE');y.filelock.close()
 def test_checklist_detects_minimum_before_breakout_and_isolates_eth(self):
  with tempfile.TemporaryDirectory() as d:
   x=c.Experiment(d+'/db','key','secret');x.initialize()
   def api(route,*args):
    if route=='/v2/account':return {'status':'ACTIVE','non_marginable_buying_power':100000}
    if route in ('/v2/orders','/v2/positions'):return []
    if route=='/v2/assets':return [{**ASSET,'min_order_size':'1'}]
    return {'quotes':{'BTC/USD':raw(1000),'ETH/USD':raw(900)}}
   with patch.object(x,'call',side_effect=api):x.tick(1000)
   checks=x.view['entry_checklist'];self.assertEqual(checks['BTC/USD']['broker_minimum'],'MINIMUM_EXCEEDS_POSITION_LIMIT');self.assertEqual(checks['BTC/USD']['consecutive_observations'],1);self.assertEqual(checks['ETH/USD']['quote']['state'],'STALE');self.assertIsNone(x.s['pending']);x.filelock.close()
 def test_contiguous_warmup_gap_and_qualifying_order(self):
  with tempfile.TemporaryDirectory() as d:
   x=c.Experiment(d+'/db','key','secret');x.initialize();now=1000;calls=[]
   def api(route,params=None,body=None):
    if body is not None:calls.append(body);return {'status':'accepted','filled_qty':'0'}
    if route=='/v2/account':return {'status':'ACTIVE','non_marginable_buying_power':100000}
    if route in ('/v2/orders','/v2/positions'):return []
    if route=='/v2/assets':return [ASSET]
    q=raw(now);q.update(bp=100+(now-1000)/60,ap=100.01+(now-1000)/60);return {'quotes':{'BTC/USD':q}}
   with patch.object(x,'call',side_effect=api):
    for i in range(21):now=1000+i*60;x.tick(now)
   self.assertEqual(len(calls),1);self.assertEqual(x.view['entry_checklist']['BTC/USD']['consecutive_observations'],21);self.assertLessEqual(float(calls[0]['qty'])*float(calls[0]['limit_price'])*1.005,5);self.assertEqual(x.s['order_lifecycle']['status'],'accepted');self.assertIsNone(x.s['position']);x.filelock.close()
 def test_partial_status_is_visible_but_not_double_booked(self):
  from test_crypto_paper import Q
  with tempfile.TemporaryDirectory() as d:
   x=c.Experiment(d+'/db','key','secret');x.initialize();x.s['pending']={'at':1000,'order':{'client_order_id':'hbcp1-fixture','qty':'0.01','symbol':'BTC/USD','side':'buy'},'quote':Q}
   r={'client_order_id':'hbcp1-fixture','status':'partially_filled','filled_qty':'0.005','filled_avg_price':'100'}
   with patch.object(x,'call',return_value=r):x.reconcile(1001);x.reconcile(1002)
   self.assertEqual(x.s['order_lifecycle']['status'],'partially_filled');self.assertEqual(x.s['cash'],50);self.assertIsNotNone(x.s['pending'])
   self.assertEqual(len([e for e in x.status()['order_events'] if e['kind']=='ORDER_STATUS']),1);x.filelock.close()
 def test_gap_is_explicit_not_filled_with_cached_values(self):
  with tempfile.TemporaryDirectory() as d:
   x=c.Experiment(d+'/db','key','secret');x.initialize();x.s['history']['BTC/USD']=[{'at':800,'mid':99}]
   def api(route,*args):
    if route=='/v2/account':return {'status':'ACTIVE','non_marginable_buying_power':100000}
    if route in ('/v2/orders','/v2/positions'):return []
    if route=='/v2/assets':return [ASSET]
    return {'quotes':{'BTC/USD':raw(1000)}}
   with patch.object(x,'call',side_effect=api):x.tick(1000)
   check=x.view['entry_checklist']['BTC/USD'];self.assertEqual(check['sample_interval_seconds'],200);self.assertEqual(check['consecutive_observations'],1);self.assertEqual(check['blocker'],'WARMUP_OR_DATA_GAP');x.filelock.close()
