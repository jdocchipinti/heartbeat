import io
import json
import tempfile
import unittest
from unittest.mock import patch
import server as s

NOW = 1800000000000

def bars():
    return [{'t': NOW - (22-i)*60000, 'o': 100, 'h': 102, 'l': 99, 'c': 101, 'v': 10, 'vw': 100} for i in range(21)]

class BackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        s.DB = self.tmp.name + '/test.sqlite3'
        s.KEY = ''
        s.TOKEN = 'x'*32
        s.STATE = {'symbols': {}, 'market': {'market': 'open'}, 'market_received': NOW, 'market_error': None}

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, path, auth='', method='GET'):
        out = {}
        def start(code, headers):
            out.update(code=code, headers=dict(headers))
        response = b''.join(s.application({'PATH_INFO':path,'REQUEST_METHOD':method,'HTTP_AUTHORIZATION':auth,'QUERY_STRING':'symbol=QQQ'},start))
        return out['code'], json.loads(response)

    def test_auth_fail_closed(self):
        self.assertEqual(self.call('/api/us/candles')[0], '401 Unauthorized')
        self.assertEqual(self.call('/api/us/status','Bearer '+s.TOKEN)[0], '200 OK')
        self.assertEqual(self.call('/api/order','Bearer '+s.TOKEN,'POST')[0], '405 Method Not Allowed')
        s.TOKEN = ''
        self.assertEqual(self.call('/api/us/candles')[0], '503 Service Unavailable')

    def test_reject_future_invalid_and_incomplete(self):
        good = bars()
        self.assertEqual(len(s.normalize(good,NOW)),21)
        with self.assertRaises(ValueError):s.normalize([{**good[0],'t':NOW+60000}],NOW)
        with self.assertRaises(ValueError):s.normalize([{**good[0],'h':98}],NOW)
        with self.assertRaises(ValueError):s.normalize([{**good[0],'v':float('nan')}],NOW)
        with self.assertRaises(ValueError):s.normalize([good[0],{**good[0],'c':100}],NOW)
        self.assertEqual(s.normalize([{**good[0],'t':NOW}],NOW),[])

    def test_revision_history_including_reversion(self):
        b=s.normalize(bars(),NOW)[0]
        s.store('QQQ',[b],NOW,'a')
        s.store('QQQ',[b],NOW+1,'b')
        self.assertEqual(len(s.observations('QQQ')),1)
        s.store('QQQ',[{**b,'c':100}],NOW+2,'c')
        s.store('QQQ',[b],NOW+3,'d')
        rows=s.observations('QQQ')
        self.assertEqual(len(rows),3)
        self.assertEqual(rows[0]['observed_at'],NOW+3)

    def test_freshness_closed_session_gaps_and_delay(self):
        s.KEY='test'
        item={'bars':s.normalize(bars(),NOW),'received':NOW,'error':None,'provider_status':'OK'}
        s.STATE['symbols']['QQQ']=item
        good=s.snapshot('QQQ',NOW)
        self.assertTrue(good['research_usable'])
        self.assertFalse(good['execution_enabled'])
        self.assertEqual(good['engines']['stockholm']['status'],'BLOCKED')
        self.assertEqual(good['engines']['palermo']['sma20'],101)
        self.assertEqual(good['engines']['tokyo']['relative_volume_20'],1)
        self.assertFalse(s.snapshot('QQQ',NOW+300000)['research_usable'])
        item['provider_status']='DELAYED'
        self.assertFalse(s.snapshot('QQQ',NOW)['research_usable'])
        item['provider_status']='OK'
        s.STATE['market']['market']='closed'
        self.assertFalse(s.snapshot('QQQ',NOW)['research_usable'])
        s.STATE['market']['market']='open'
        item['bars'][10]['t']-=60000
        self.assertIn('RECENT BAR GAPS',s.snapshot('QQQ',NOW)['issues'])

    def test_upstream_error_preserves_but_blocks_old_data(self):
        s.KEY='test'
        s.STATE['symbols']['QQQ']={'bars':s.normalize(bars(),NOW),'received':NOW,'error':None}
        with patch.object(s,'request',side_effect=s.ProviderError('ENTITLEMENT_DENIED')):
            s.collect_symbol('QQQ')
        result=s.snapshot('QQQ',NOW)
        self.assertEqual(len(result['bars']),21)
        self.assertIn('ENTITLEMENT_DENIED',result['issues'])
        self.assertFalse(result['research_usable'])

    def test_provider_response_and_storage(self):
        with patch.object(s,'stamp',return_value=NOW),patch.object(s,'request',return_value={'ticker':'QQQ','adjusted':False,'status':'OK','results':bars(),'request_id':'r'}):
            s.collect_symbol('QQQ')
        self.assertEqual(len(s.observations('QQQ')),21)
        self.assertIsNone(s.STATE['symbols']['QQQ']['error'])

if __name__=='__main__':unittest.main()
