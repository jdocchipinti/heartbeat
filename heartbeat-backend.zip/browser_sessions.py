"""Opaque, revocable browser sessions; never stores provider or access tokens."""
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time
from contextlib import contextmanager
from http.cookies import SimpleCookie, CookieError

COOKIE = '__Host-hb_session'
REMEMBER_SECONDS = 30 * 24 * 3600
SESSION_SECONDS = 12 * 3600


def secure(environ):
    # Render terminates TLS and supplies X-Forwarded-Proto to Gunicorn.
    return environ.get('wsgi.url_scheme') == 'https' or environ.get('HTTP_X_FORWARDED_PROTO') == 'https'


def same_origin(environ):
    host = environ.get('HTTP_HOST', '')
    return bool(host) and secure(environ) and environ.get('HTTP_ORIGIN') == 'https://' + host and environ.get('HTTP_SEC_FETCH_SITE', 'same-origin') == 'same-origin'


def cookie_value(environ):
    try:
        jar = SimpleCookie(environ.get('HTTP_COOKIE', '')[:8192])
        value = jar[COOKIE].value if COOKIE in jar else ''
        return value if re.fullmatch(r'[A-Za-z0-9_-]{43}', value) else ''
    except CookieError:
        return ''


def cookie_header(value='', remember=False):
    header = f'{COOKIE}={value}; Path=/; Secure; HttpOnly; SameSite=Strict'
    if not value:
        return header + '; Max-Age=0'
    return header + (f'; Max-Age={REMEMBER_SECONDS}' if remember else '')


def key_id(access_token):
    return hmac.new(access_token.encode(), b'heartbeat-browser-session-v1', hashlib.sha256).hexdigest()


@contextmanager
def database(path):
    # Do not silently create a missing mount: fail closed if the configured path is absent.
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    os.close(fd)
    con = sqlite3.connect(path, timeout=5)
    try:
        con.execute('CREATE TABLE IF NOT EXISTS browser_sessions (digest TEXT PRIMARY KEY, key_id TEXT NOT NULL, expires REAL NOT NULL)')
        yield con
        con.commit()
    finally:
        con.close()


def create(path, access_token, remember, old_value=''):
    value = secrets.token_urlsafe(32)
    now = time.time()
    expiry = now + (REMEMBER_SECONDS if remember else SESSION_SECONDS)
    with database(path) as con:
        con.execute('DELETE FROM browser_sessions WHERE expires<=? OR key_id<>?', (now, key_id(access_token)))
        if old_value:
            con.execute('DELETE FROM browser_sessions WHERE digest=?', (hashlib.sha256(old_value.encode()).hexdigest(),))
        # Cap abandoned sessions without silently revoking still-valid devices.
        if con.execute('SELECT COUNT(*) FROM browser_sessions').fetchone()[0] >= 100:
            raise ValueError('SESSION_LIMIT_REACHED')
        con.execute('INSERT INTO browser_sessions VALUES (?,?,?)', (hashlib.sha256(value.encode()).hexdigest(), key_id(access_token), expiry))
    return value, expiry


def validate(path, access_token, environ):
    value = cookie_value(environ)
    if not value or not secure(environ):
        return None
    with database(path) as con:
        row = con.execute('SELECT expires FROM browser_sessions WHERE digest=? AND key_id=? AND expires>?', (hashlib.sha256(value.encode()).hexdigest(), key_id(access_token), time.time())).fetchone()
    return row[0] if row else None


def revoke(path, environ):
    value = cookie_value(environ)
    if value:
        with database(path) as con:
            con.execute('DELETE FROM browser_sessions WHERE digest=?', (hashlib.sha256(value.encode()).hexdigest(),))
