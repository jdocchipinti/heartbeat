import json,unittest
from pathlib import Path
from urllib.parse import urlparse
class ResourcesTests(unittest.TestCase):
 def test_directory_and_embedded_data_match(self):
  root=Path(__file__).parent
  data=json.loads((root/'resources-directory.json').read_text())
  html=(root/'index.html').read_text()
  embedded=json.JSONDecoder().raw_decode(html.split('const resourceStates=',1)[1])[0]
  self.assertEqual(data,embedded)
  self.assertEqual(len(data),50)
  for key in ['code','name','capital','fips']:
   self.assertEqual(len({s[key] for s in data}),50)
  for s in data:
   self.assertTrue(s['path'].startswith('M'))
   self.assertEqual(len(s['point']),2)
   self.assertTrue(0 <= s['point'][0] <= 975)
   self.assertTrue(0 <= s['point'][1] <= 610)
   for field in ['health','social','government']:
    self.assertIn(urlparse(s[field]).scheme,('http','https'))
    self.assertTrue(urlparse(s[field]).hostname)
  self.assertEqual(next(s['capital'] for s in data if s['code']=='FL'),'Tallahassee')
if __name__=='__main__':unittest.main()
