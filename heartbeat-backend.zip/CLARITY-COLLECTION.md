# Clarity collection deployment
Adds a homepage collection link, Resources product section, free sample and free consultation card, and an owner-only workbook endpoint.

Monthly buyer group is included in the proposed product offer. Checkout remains disabled until the schedule, time zone, platform, access duration and buyer delivery are configured. No meetings are created by this deployment.

Paid PDFs are deliberately excluded from this public GitHub deployment archive. Use the separately supplied Your-Next-Chapter-Monthly-Group.pdf for private fulfillment. To enable the existing owner-only preview endpoint, place that PDF in private persistent server storage and set HB_CLARITY_WORKBOOK_PATH to its absolute path. Do not put the full paid file or meeting access links in public assets or the public repository. Owner sign-in is not purchaser authentication.

Free files: /assets/clarity-free-sample.pdf and /assets/clarity-consultation-card.pdf.
Owner endpoint: /api/clarity/workbook. Missing private configuration reports PRIVATE_WORKBOOK_NOT_CONFIGURED.
Trading strategies and risk controls are unchanged.
