"""Forward-only hypothetical comparison. No broker client, keys, orders or network."""
import copy,fcntl,hashlib,json,math,os,sqlite3,threading,time
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from urllib.parse import quote as quote_path

VARIANTS=('earlier','current','later','pullback')
CONFIG={'version':'HB-ENTRY-LAB-001','duration_days':7,'symbols':['BTC/USD','ETH/USD'],'budget':50.,'position_cap':5.,'daily_loss_limit':5.,'max_entries_per_day':1,'fee_fraction':.005,'slippage_fraction':.001,'max_spread':.005,'quote_age_seconds':15,'next_quote_timeout':90,'stop_fraction':.02,'target_fraction':.04,'max_hold_seconds':3600,'timezone':'America/Denver','pullback_fraction':.0025,'pullback_timeout':600,'rules':{'earlier':'21 observations; last midpoint above prior 5; SMA5 > SMA20.','current':'21 observations; last midpoint above prior 20; SMA5 > SMA20 (original signal rule).','later':'Current breakout condition holds on two consecutive observations.','pullback':'Arm on Current breakout; within 10 minutes buy after a 0.25% retracement from that midpoint while above SMA20.'},'execution':'Decision limit = ask +10bp (buy) or bid -10bp (sell). Next recorded quote only, within 90s; effective ask +10bp / bid -10bp must meet the limit and displayed size. Fractional quantities; exchange increments/minimums are NOT verified. Both sides charge 0.5%.','scope':'Hypothetical quote-based comparisons, not broker fills, executable returns, audited results, or options-readiness evidence. Current matches the signal, not all broker/account constraints. Maximum loss is observed at sampled bids; moves between samples are unknown.'}
PRE_COLLECTION_LAB_HASH='64f505aa0d18beb53292d9071ba1a25176d67c33f2ccf5e5c7ac82a2b9055703'
CONFIG_HASH=hashlib.sha256(json.dumps(CONFIG,sort_keys=True).encode()).hexdigest()
CODE_HASH=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def day(at):return datetime.fromtimestamp(at,ZoneInfo(CONFIG['timezone'])).date().isoformat()
def good_quote(q,at):
    if not isinstance(q,dict):return False
    try:
        stamp=datetime.fromisoformat(q['t'].replace('Z','+00:00'))
        return stamp.tzinfo is not None and 0<=at-stamp.timestamp()<=15 and all(finite(q.get(k)) for k in ('bid','ask','bid_size','ask_size','mid')) and 0<q['bid']<=q['ask'] and min(q['bid_size'],q['ask_size'])>0 and abs(q['mid']-(q['bid']+q['ask'])/2)<1e-7
    except (KeyError,TypeError,ValueError):return False

def breakout(h,n=20):
    if len(h)<21:return False
    r=h[-21:]
    if any(not 40<=r[i]['at']-r[i-1]['at']<=90 for i in range(1,21)):return False
    v=[x['mid'] for x in r]
    return v[-1]>max(v[-n-1:-1]) and sum(v[-5:])/5>sum(v[-20:])/20

def initial(start,cursor):
    return {'start':start,'end':start+7*86400,'cursor':cursor,'last_at':None,'status':'COLLECTING','config_hash':CONFIG_HASH,'code_hash':CODE_HASH,'history':{},'inputs':0,'accounts':{v:{'cash':50.,'position':None,'pending':None,'entries':{},'day_start':{},'realized':0.,'closed':0,'unfilled':0,'rejected':0,'peak':50.,'drawdown':0.,'equity':50.,'equity_at':start,'armed':{},'paused':False} for v in VARIANTS}}

def emit(events,v,symbol,kind,reason,at,**fields):events.append({'variant':v,'symbol':symbol,'kind':kind,'reason':reason,'at':at,**fields})
def mark(a,q,at):
    pos=a['position'];value=a['cash']
    if pos:
        liquidation=pos['qty']*q['bid']*.999*.995
        observed=liquidation-pos['cost'];pos['max_observed_loss']=max(pos['max_observed_loss'],max(0,-observed));pos['last_mark']=observed;pos['mark_at']=at;value+=liquidation
    a['equity']=value;a['equity_at']=at;a['peak']=max(a['peak'],value);a['drawdown']=max(a['drawdown'],1-value/a['peak'])
    a['day_start'].setdefault(day(at),value)
    if a['day_start'][day(at)]-value>=5:a['paused']=True

def settle(a,v,quotes,at,events):
    p=a['pending']
    if not p:return False
    if at<=p['decision_at']:return True
    q=quotes.get(p['symbol']);fresh=good_quote(q,at)
    if not fresh and at-p['decision_at']<=90:return True
    reason='NEXT_QUOTE_TIMEOUT' if at-p['decision_at']>90 else 'NO_FILL_AT_LIMIT'
    price=(q['ask']*1.001 if p['side']=='buy' else q['bid']*.999) if fresh else None
    liquid=fresh and (q['ask']-q['bid'])/q['mid']<=.005 and p['qty']<=q['ask_size' if p['side']=='buy' else 'bid_size']
    fills=at-p['decision_at']<=90 and liquid and (price<=p['limit']+1e-10 if p['side']=='buy' else price>=p['limit']-1e-10)
    if fills:
        value=p['qty']*price;fee=value*.005
        if p['side']=='buy':
            cost=value+fee
            if cost>min(a['cash'],5)+1e-8:raise ValueError('MODEL_CAP_BREACH')
            a['cash']-=cost;a['position']={'trade_id':p['trade_id'],'symbol':p['symbol'],'qty':p['qty'],'cost':cost,'entry_price':price,'entry_at':at,'max_observed_loss':0.,'last_mark':None}
            emit(events,v,p['symbol'],'MODELED_ENTRY','NEXT_QUOTE_LIMIT_FILL',at,trade_id=p['trade_id'],entry_price=price,qty=p['qty'],fee=fee,decision_at=p['decision_at'])
        else:
            pos=a['position'];net=value-fee-pos['cost'];pos['max_observed_loss']=max(pos['max_observed_loss'],max(0,-net));a['cash']+=value-fee;a['realized']+=net;a['closed']+=1
            emit(events,v,p['symbol'],'CLOSED',p['reason'],at,trade_id=p['trade_id'],entry_price=pos['entry_price'],entry_at=pos['entry_at'],exit_price=price,qty=p['qty'],net_outcome=net,max_observed_loss=pos['max_observed_loss'],exit_fee=fee)
            a['position']=None
    else:
        a['unfilled']+=1
        emit(events,v,p['symbol'],'UNFILLED',reason,at,trade_id=p['trade_id'],side=p['side'],limit_price=p['limit'],decision_at=p['decision_at'])
    a['pending']=None
    return True

def advance(state,source_id,available_at,payload):
    events=[];at=available_at
    if not finite(at) or at<state['start'] or (state['last_at'] is not None and at<=state['last_at']):
        emit(events,'all',None,'REJECTED','NONCHRONOLOGICAL_INPUT',at if finite(at) else state['start']);return events
    if at>state['end']:return events
    quotes=payload.get('quotes',{}) if isinstance(payload,dict) else {}
    if not isinstance(quotes,dict):quotes={}
    state['inputs']+=1;state['last_at']=at
    for symbol in CONFIG['symbols']:
        q=quotes.get(symbol)
        if good_quote(q,at):
            h=state['history'].setdefault(symbol,[])
            if not h or at-h[-1]['at']>=40:h.append({'at':at,'mid':q['mid'],'quote_at':q['t']})
            state['history'][symbol]=h[-22:]
    for v,a in state['accounts'].items():
        for symbol,arm in list(a['armed'].items()):
            if at-arm['at']>600:
                emit(events,v,symbol,'UNFILLED','PULLBACK_NEVER_REACHED',at,armed_at=arm['at'],reference_price=arm['price']);a['unfilled']+=1;del a['armed'][symbol]
        resolved=settle(a,v,quotes,at,events)
        pos=a['position']
        if pos:
            q=quotes.get(pos['symbol'])
            if not good_quote(q,at):
                a['rejected']+=1;emit(events,v,pos['symbol'],'REJECTED','POSITION_QUOTE_MISSING_OR_STALE',at,trade_id=pos['trade_id']);continue
            mark(a,q,at)
            if not a['pending']:
                change=q['bid']/pos['entry_price']-1
                reason='STOP' if change<=-.02 else 'TARGET' if change>=.04 else 'MAX_HOLD' if at-pos['entry_at']>=3600 else 'DAILY_LOSS' if a['paused'] else None
                if reason:
                    a['pending']={'side':'sell','symbol':pos['symbol'],'qty':pos['qty'],'limit':q['bid']*.999,'decision_at':at,'reason':reason,'trade_id':pos['trade_id']}
                    emit(events,v,pos['symbol'],'EXIT_PROPOSED',reason,at,trade_id=pos['trade_id'],limit_price=a['pending']['limit'])
                else:emit(events,v,pos['symbol'],'HOLD','NO_EXIT_CONDITION',at,trade_id=pos['trade_id'],net_mark=pos['last_mark'],max_observed_loss=pos['max_observed_loss'])
            continue
        mark(a,None,at)
        for symbol in CONFIG['symbols']:
            q=quotes.get(symbol);h=state['history'].get(symbol,[])
            reason=None;trigger=False
            if not good_quote(q,at):reason='QUOTE_MISSING_OR_STALE'
            elif a['pending'] or resolved:reason='ORDER_OR_FILL_THIS_OBSERVATION'
            elif a['paused']:reason='DAILY_LOSS_PAUSED'
            elif a['entries'].get(day(at),0)>=1:reason='DAILY_ENTRY_LIMIT'
            elif not h or h[-1]['at']!=at:reason='OBSERVATION_TOO_CLOSE'
            elif len(h)<21 or any(not 40<=h[i]['at']-h[i-1]['at']<=90 for i in range(len(h)-20,len(h))):reason='WARMUP_OR_DATA_GAP'
            elif (q['ask']-q['bid'])/q['mid']>.005:reason='SPREAD_LIMIT'
            else:
                current=breakout(h)
                if v=='earlier':trigger=breakout(h,5)
                elif v=='current':trigger=current
                elif v=='later':trigger=current and breakout(h[:-1])
                else:
                    arm=a['armed'].get(symbol)
                    if arm and at-arm['at']>600:
                        emit(events,v,symbol,'UNFILLED','PULLBACK_NEVER_REACHED',at,armed_at=arm['at'],reference_price=arm['price']);a['unfilled']+=1;del a['armed'][symbol];arm=None
                    if arm and at>arm['at'] and q['mid']<=arm['price']*.9975 and q['mid']>sum(x['mid'] for x in h[-20:])/20:
                        trigger=True;del a['armed'][symbol]
                    elif not arm and current:a['armed'][symbol]={'at':at,'price':q['mid']};emit(events,v,symbol,'ARMED','WAIT_FOR_0_25_PERCENT_PULLBACK',at,reference_price=q['mid'])
            if trigger:
                limit=q['ask']*1.001;budget=min(5,a['cash']);qty=budget/(limit*1.005)
                a['entries'][day(at)]=a['entries'].get(day(at),0)+1
                if budget<=0 or qty>q['ask_size']:reason='CASH_OR_DISPLAYED_SIZE'
                else:
                    tid=f'{v}-{source_id}-{symbol}'
                    a['pending']={'side':'buy','symbol':symbol,'qty':qty,'limit':limit,'decision_at':at,'trade_id':tid,'reason':v}
                    emit(events,v,symbol,'ENTRY_PROPOSED','WAIT_FOR_NEXT_QUOTE',at,trade_id=tid,limit_price=limit,qty=qty);continue
            if reason:a['rejected']+=1;emit(events,v,symbol,'REJECTED',reason,at)
            else:emit(events,v,symbol,'NO_TRIGGER','ENTRY_CONDITION_NOT_MET',at)
    return events

def finish(state):
    events=[]
    for v,a in state['accounts'].items():
        if a['pending']:emit(events,v,a['pending']['symbol'],'CENSORED','WINDOW_ENDED_WITH_PENDING_ORDER',state['end'],trade_id=a['pending']['trade_id'])
        if a['position']:
            pos=a['position'];emit(events,v,pos['symbol'],'CENSORED','WINDOW_ENDED_WITH_OPEN_POSITION',state['end'],trade_id=pos['trade_id'],entry_price=pos['entry_price'],max_observed_loss=pos['max_observed_loss'],last_observed_net=pos['last_mark'])
        for symbol,arm in a['armed'].items():emit(events,v,symbol,'CENSORED','PULLBACK_WINDOW_INCOMPLETE_AT_END',state['end'],armed_at=arm['at'])
    state['status']='COMPLETE';return events

class Lab:
    def __init__(self,source,path):self.source=source;self.path=path;self.started=False;self.error=None;self.lock=threading.Lock();self.filelock=None;self.last_cycle=None
    def source_db(self):return sqlite3.connect('file:'+quote_path(os.path.abspath(self.source),safe='/')+'?mode=ro',uri=True,timeout=2)
    def db(self):return sqlite3.connect(self.path,timeout=3)
    def initialize(self,now=None):
        now=time.time() if now is None else now
        self.filelock=open(self.path+'.lock','a');fcntl.flock(self.filelock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with self.source_db() as source:cursor=source.execute('SELECT COALESCE(MAX(id),0) FROM cp_events').fetchone()[0]
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS lab_state (id INTEGER PRIMARY KEY,payload TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS lab_inputs (source_id INTEGER PRIMARY KEY,available_at REAL,payload TEXT,sha256 TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS lab_events (id INTEGER PRIMARY KEY,source_id INTEGER,payload TEXT NOT NULL)')
            row=db.execute('SELECT payload FROM lab_state WHERE id=1').fetchone()
            if not row:
                state=initial(now,cursor);db.execute('INSERT INTO lab_state VALUES(1,?)',(json.dumps(state),));self.write_events(db,None,[{'kind':'REGISTERED','at':now,'config':CONFIG,'config_hash':CONFIG_HASH,'code_hash':CODE_HASH,'source_cursor':cursor}])
            else:
                state=json.loads(row[0])
                if state.get('config_hash')==CONFIG_HASH and state.get('code_hash')==PRE_COLLECTION_LAB_HASH:
                    state['code_hash']=CODE_HASH;events=[]
                    if state['status']=='COLLECTING':
                        state['planned_end']=state['end'];state['end']=min(now,state['end']);events=finish(state);state['status']='CENSORED_COLLECTION_CHANGE'
                    events.append({'kind':'COLLECTION_CHANGE','at':now,'reason':'Quote collection changed. Prior comparison retained; do not pool across versions.'})
                    self.write_events(db,None,events);db.execute('UPDATE lab_state SET payload=? WHERE id=1',(json.dumps(state),))
                else:self.validate(state)
    def validate(self,state):
        if state['config_hash']!=CONFIG_HASH or state['code_hash']!=CODE_HASH:raise ValueError('LAB_RULES_CHANGED_NEW_EXPERIMENT_REQUIRED')
    def write_events(self,db,source_id,events):
        db.executemany('INSERT INTO lab_events(source_id,payload) VALUES(?,?)',[(source_id,json.dumps(e,allow_nan=False)) for e in events])
    def tick(self,now=None):
        now=time.time() if now is None else now
        with self.lock,self.db() as db:
            state=json.loads(db.execute('SELECT payload FROM lab_state WHERE id=1').fetchone()[0]);self.validate(state)
            if state['status']!='COLLECTING':return
            with self.source_db() as source:rows=source.execute('SELECT id,at,payload FROM cp_events WHERE id>? ORDER BY id LIMIT 100',(state['cursor'],)).fetchall()
            for source_id,available_at,raw in rows:
                payload=json.loads(raw)
                if payload.get('kind')=='OBSERVATION' and state['start']<=available_at<=state['end']:
                    db.execute('INSERT INTO lab_inputs VALUES(?,?,?,?)',(source_id,available_at,raw,hashlib.sha256(raw.encode()).hexdigest()))
                    self.write_events(db,source_id,advance(state,source_id,available_at,payload))
                state['cursor']=source_id
            if now>state['end'] and len(rows)<100:self.write_events(db,None,finish(state))
            db.execute('UPDATE lab_state SET payload=? WHERE id=1',(json.dumps(state,allow_nan=False),))
            self.last_cycle=now
    def start(self,worker_started):
        if self.started or not worker_started:return
        with self.lock:
            if self.started:return
            if not os.path.ismount('/var/data') or not os.path.realpath(self.path).startswith('/var/data/'):self.error='LAB_PERSISTENT_DISK_REQUIRED';return
            try:self.initialize()
            except Exception as e:
                if self.filelock:self.filelock.close();self.filelock=None
                self.error='LAB_RULES_CHANGED_NEW_EXPERIMENT_REQUIRED' if str(e)=='LAB_RULES_CHANGED_NEW_EXPERIMENT_REQUIRED' else 'LAB_STORAGE_OR_LOCK_UNAVAILABLE';return
            self.started=True;self.error=None;threading.Thread(target=self.loop,daemon=True,name='entry-comparison').start()
    def loop(self):
        while True:
            try:self.tick();self.error=None
            except Exception:self.error='LAB_PROCESSING_FAILED_NO_RESULTS_ADVANCED'
            time.sleep(15)
    def status(self):
        if not os.path.exists(self.path):return {'status':'WAITING_FOR_PAPER_WORKER','error':self.error,'config':CONFIG,'hypothetical_only':True,'execution_enabled':False}
        with self.db() as db:
            row=db.execute('SELECT payload FROM lab_state WHERE id=1').fetchone();state=json.loads(row[0]) if row else None
            events=[{'journal_id':i,**json.loads(raw)} for i,raw in db.execute('SELECT id,payload FROM lab_events ORDER BY id DESC LIMIT 100')]
            total=db.execute('SELECT COUNT(*) FROM lab_events').fetchone()[0]
            outcomes=[{'journal_id':i,**json.loads(raw)} for i,raw in db.execute("SELECT id,payload FROM lab_events WHERE json_extract(payload,'$.kind') IN ('MODELED_ENTRY','CLOSED','UNFILLED','CENSORED','ENTRY_PROPOSED') ORDER BY id DESC LIMIT 100")]
        return {'status':state['status'] if state else 'WAITING','error':self.error,'config':CONFIG,'config_hash':CONFIG_HASH,'code_hash':CODE_HASH,'state':state,'events':events,'outcomes':outcomes,'journal_count':total,'last_cycle':self.last_cycle,'hypothetical_only':True,'execution_enabled':False,'note':CONFIG['scope']}
    def journal(self,after=0,through=None):
        with self.db() as db:
            maximum=db.execute('SELECT COALESCE(MAX(id),0) FROM lab_events').fetchone()[0] if through is None else through
            rows=db.execute('SELECT id,source_id,payload FROM lab_events WHERE id>? AND id<=? ORDER BY id LIMIT 500',(after,maximum)).fetchall()
            events=[{'journal_id':i,'source_id':sid,**json.loads(raw)} for i,sid,raw in rows]
        cursor=rows[-1][0] if rows else after
        return {'events':events,'next_cursor':cursor,'through':maximum,'has_more':cursor<maximum}

    def inputs(self,after=0,through=None):
        with self.db() as db:
            maximum=db.execute('SELECT COALESCE(MAX(source_id),0) FROM lab_inputs').fetchone()[0] if through is None else through
            rows=db.execute('SELECT source_id,available_at,payload,sha256 FROM lab_inputs WHERE source_id>? AND source_id<=? ORDER BY source_id LIMIT 500',(after,maximum)).fetchall()
        cursor=rows[-1][0] if rows else maximum
        return {'inputs':[{'source_id':i,'available_at':at,'payload':json.loads(raw),'sha256':sha} for i,at,raw,sha in rows],'next_cursor':cursor,'through':maximum,'has_more':cursor<maximum}
