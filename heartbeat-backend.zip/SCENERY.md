# Clarity scenery v4

Original AI-generated smiling-male-friends lifestyle image and mountain/beach scenery. Two 12-second H.264 1280x720 scenic camera-movement loops made from still artwork. This is not filmed scenery, physical simulation, or full generative-motion video. UI discloses these limitations.

Garden/Mountain/Beach selector; explicit play/pause; separate opt-in Web Audio synthesized wind/surf-like noise, low default volume and volume slider. No field recordings, no voice narration, no actual scent/taste delivery. Sensory words evoke each setting. Scene changes, page visibility loss and navigation away stop sound. Playback is manual; reduced-motion changes pause the scenic loop. No additional services, keys or tracking.

Source assets bundled. Production asset routes support byte ranges. Existing financial modules unchanged. Rename archive heartbeat-backend.zip and use the existing GitHub/Render deployment.
