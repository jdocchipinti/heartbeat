"""One bounded, deterministic review round. No provider calls or LLM consensus scores."""
import copy
import hashlib
import json
from pathlib import Path

ROLES=('tokyo','palermo','denver','stockholm','professor')
VERSION='HB-REVIEW-001'
SOURCE_HASH=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def board(snapshot):
    # Source families are conservative: multiple candles and agents from one provider
    # do not create independently corroborating sources. No news lineage is inferred.
    unique={}
    for b in snapshot['bars']:
        fact={'source':snapshot['source'],'symbol':snapshot['symbol'],'type':'underlying_candle','event_at':b['t'],'payload':b}
        id='EV-'+sha(fact)[:24]
        unique.setdefault(id,{'id':id,**fact,'observed_at':snapshot['collected_at'],'origin_family':snapshot['source']})
    return {'items':list(unique.values()),'unique_items':len(unique),'source_families':len({v['origin_family'] for v in unique.values()}),'independent_corroboration':'NOT_ESTABLISHED','news_lineage':'No news ingested in this review. Syndication detection is not implemented.','upstream_requests_by_review':0,'duplicate_items_removed':len(snapshot['bars'])-len(unique)}

def deduplicate(messages):
    output={}
    for msg in messages:
        key=sha({k:msg[k] for k in ('kind','evidence_ids','claim_ids','body')})
        if key not in output:output[key]={**copy.deepcopy(msg),'id':'MSG-'+key[:24],'contributors':[msg['from']]}
        else:
            existing=output[key]
            existing['to']=sorted(set(existing['to']+msg['to']))
            existing['contributors']=sorted(set(existing['contributors']+[msg['from']]))
    return list(output.values())

def run(snapshot,initial):
    frozen=copy.deepcopy(initial);evidence=board(snapshot)
    refs=[v['id'] for v in evidence['items'][-21:]]
    claims=[{'id':'CL-'+sha({'agent':name,'assessment':frozen[name],'evidence_ids':refs})[:24],'agent':name,'assessment':frozen[name],'evidence_ids':refs,'phase':'INDEPENDENT_INITIAL'} for name in ROLES]
    ids={c['agent']:c['id'] for c in claims}
    messages=[]
    def send(sender,to,kind,body,roles):
        messages.append({'from':sender,'to':to,'kind':kind,'body':body,'evidence_ids':refs,'claim_ids':[ids[r] for r in roles],'phase':'BOUNDED_REVIEW','recorded_at':snapshot['server_time']})
    volume=frozen['tokyo']['status']=='WATCH';structure=frozen['palermo']['status']=='STRUCTURE_WATCH'
    send('tokyo',['palermo'],'QUESTION','Volume trigger '+('met' if volume else 'not met')+'. Does the independently assessed structure support a watch?',['tokyo'])
    send('palermo',['tokyo','denver'],'ANSWER','Upward structure '+('present' if structure else 'absent')+'. This does not establish option tradability.',['palermo','tokyo'])
    send('denver',['tokyo','palermo'],'CONTRADICTION','Do not interpret the underlying watch as an eligible trade. Event coverage, option quotes and validation remain incomplete.',['denver','tokyo','palermo'])
    send('stockholm',['palermo','professor'],'BLOCKER','No verified option bid/ask or displayed size. An executable entry and cost cannot be assessed.',['stockholm'])
    send('palermo',['stockholm'],'ACKNOWLEDGEMENT','Entry proposal remains withheld until the referenced liquidity blocker is resolved.',['palermo','stockholm'])
    send('denver',['professor'],'REVIEW','Retain all hard blockers. Agreement between modules using the same candles adds no independent source.',['denver','stockholm'])
    resolution={'decision':'NO_QUALIFYING_TRADE','agreement':['Initial candle observations use one shared provider family.','No verified options fill is available.'],'disagreement':['Activity and price structure do not both support the watch.'] if volume!=structure else [],'unresolved':list(frozen['denver']['issues']),'reason':'Missing options execution, event and validation evidence independently blocks entry.','initial_sha256':sha(frozen),'risk_override_allowed':False}
    send('professor',['tokyo','palermo','denver','stockholm'],'RESOLUTION',resolution['reason'],list(ROLES))
    clean=deduplicate(messages)
    assert len(clean)<=8
    for m in clean:
        assert m['from'] in ROLES and all(n in ROLES for n in m['to'])
        assert set(m['claim_ids'])<=set(ids.values())
        assert set(m['evidence_ids'])<=set(v['id'] for v in evidence['items'])
    return {'version':VERSION,'source_sha256':SOURCE_HASH,'mode':'Deterministic local message routing; not five autonomous LLM conversations','max_rounds':1,'rounds_completed':1,'max_unique_messages':8,'shared_evidence':evidence,'initial_claims':claims,'messages':clean,'duplicate_messages_removed':len(messages)-len(clean),'resolution':resolution,'health':{'feed': 'RECENT_UNDERLYING_CANDLES' if snapshot.get('research_usable') else 'UNVERIFIED_OR_BLOCKED','analysis':'COMPLETE_WITH_MISSING_INPUTS','trade_eligible':False},'comparison':{'without_review':'NO_QUALIFYING_TRADE','with_review':'NO_QUALIFYING_TRADE','eligibility_changed':False,'profit_improvement':None,'missed_opportunities':None,'ablation_status':'NOT_MEASURED; paired decision labels are not performance evidence'},'cost':{'llm_calls':0,'additional_market_requests':0},'execution_enabled':False}
