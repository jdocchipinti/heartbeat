"""Long standard-equity-option limit-fill approximation, never a broker order."""
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR

class NoFill(ValueError):
    pass

def number(value):
    if isinstance(value,bool):raise NoFill('INVALID_NUMBER')
    try:d=Decimal(str(value))
    except Exception:raise NoFill('INVALID_NUMBER') from None
    if not d.is_finite():raise NoFill('INVALID_NUMBER')
    return d

def quote_at(rows,arrival_ns,contracts,max_age_ns=2_000_000_000,max_spread_fraction=Decimal('.20')):
    if not isinstance(arrival_ns,int) or not isinstance(contracts,int) or isinstance(contracts,bool) or contracts<1:raise NoFill('INVALID_TIME_OR_SIZE')
    # Quotes later than arrival are never used; the latest quote cannot be skipped
    # merely because its price, size or spread would fail the trade.
    known=[q for q in rows if isinstance(q.get('sip_timestamp'),int) and not isinstance(q['sip_timestamp'],bool) and q['sip_timestamp']<=arrival_ns]
    if not known:raise NoFill('NO_QUOTE_AT_OR_BEFORE_ARRIVAL')
    latest=max(q['sip_timestamp'] for q in known)
    candidates=[q for q in known if q['sip_timestamp']==latest]
    # Sequence numbers resolve same-timestamp quotes; conflicting same-sequence rows fail.
    for q in candidates:
        if not isinstance(q.get('sequence_number'),int):raise NoFill('SEQUENCE_MISSING')
    sequence=max(q['sequence_number'] for q in candidates)
    candidates=[q for q in candidates if q['sequence_number']==sequence]
    fields=('bid_price','ask_price','bid_size','ask_size')
    if len({tuple(str(q.get(k)) for k in fields) for q in candidates})!=1:raise NoFill('CONFLICTING_QUOTES')
    q=candidates[0]
    if arrival_ns-latest>max_age_ns:raise NoFill('STALE_QUOTE')
    bid,ask,bs,ass=(number(q.get(k)) for k in fields)
    if bid<=0 or ask<=0 or bid>ask:raise NoFill('ZERO_OR_CROSSED_QUOTE')
    if bs!=bs.to_integral_value() or ass!=ass.to_integral_value() or min(bs,ass)<contracts:raise NoFill('INSUFFICIENT_DISPLAYED_SIZE')
    if (ask-bid)/((ask+bid)/2)>max_spread_fraction:raise NoFill('SPREAD_TOO_WIDE')
    return {'timestamp_ns':latest,'bid':bid,'ask':ask,'bid_size':int(bs),'ask_size':int(ass)}

def model_round_trip(contract,entry_quotes,exit_quotes,entry_decision_ns,exit_decision_ns,
                     expiration_ns,entry_limit,exit_limit,contracts=1,latency_ns=500_000_000,
                     slippage_per_share='0.01',fee_per_contract_side='0.65',tick_size='0.01',
                     max_loss='5',budget='50',complete=True):
    """Fixed slippage/fees are disclosed assumptions; real execution is not guaranteed.

    Caller must supply complete relevant quote windows and point-in-time metadata.
    The function never fills an unmarketable limit or crosses the expiration boundary.
    """
    try:
        if not complete:raise NoFill('INCOMPLETE_QUOTE_WINDOW')
        if contract.get('shares_per_contract')!=100 or contract.get('additional_underlyings') or contract.get('contract_type') not in ('call','put'):raise NoFill('NONSTANDARD_CONTRACT')
        if not isinstance(contracts,int) or isinstance(contracts,bool) or contracts<1:raise NoFill('INVALID_CONTRACT_COUNT')
        if not all(isinstance(t,int) and not isinstance(t,bool) and t>0 for t in [entry_decision_ns,exit_decision_ns,expiration_ns]):raise NoFill('INVALID_TIMESTAMP')
        if not isinstance(latency_ns,int) or latency_ns<0:raise NoFill('INVALID_LATENCY')
        if entry_decision_ns>=exit_decision_ns or exit_decision_ns+latency_ns>=expiration_ns:raise NoFill('INVALID_CHRONOLOGY_OR_EXPIRATION')
        slip,fee,tick,cap,loss,el,xl=map(number,[slippage_per_share,fee_per_contract_side,tick_size,budget,max_loss,entry_limit,exit_limit])
        if min(slip,fee,xl)<0 or min(tick,cap,loss,el)<=0:raise NoFill('INVALID_EXECUTION_ASSUMPTIONS')
        en=quote_at(entry_quotes,entry_decision_ns+latency_ns,contracts)
        ex=quote_at(exit_quotes,exit_decision_ns+latency_ns,contracts)
        buy=((en['ask']+slip)/tick).to_integral_value(rounding=ROUND_CEILING)*tick
        sell=((ex['bid']-slip)/tick).to_integral_value(rounding=ROUND_FLOOR)*tick
        if sell<0:raise NoFill('SLIPPAGE_EXCEEDS_BID')
        if buy>el or sell<xl:raise NoFill('LIMIT_NOT_MARKETABLE_UNDER_ASSUMPTIONS')
        multiplier=Decimal(100*contracts)
        fees=2*fee*contracts
        debit=buy*multiplier+fee*contracts
        conservative_loss=buy*multiplier+fees
        if debit>cap:raise NoFill('BUDGET_EXCEEDED')
        if conservative_loss>loss:raise NoFill('FULL_PREMIUM_LOSS_EXCEEDS_LIMIT')
        net=(sell-buy)*multiplier-fees
        return {'state':'MODELED_FILL_ONLY','entry_fill':str(buy),'exit_fill':str(sell),'contracts':contracts,'fees':str(fees),'net_pnl':str(net),'full_premium_plus_assumed_fees':str(conservative_loss),'entry_quote_ns':en['timestamp_ns'],'exit_quote_ns':ex['timestamp_ns'],'assumptions':{'latency_ns':latency_ns,'slippage_per_share':str(slip),'fee_per_contract_side':str(fee),'tick_size':str(tick),'quote_max_age_seconds':2},'theta':'Included in observed option price change; no extra theta charge.','execution_enabled':False,'readiness_credit':0,'limitations':['Displayed size does not prove a fill or queue priority.','Tick size and fee schedule must be verified for the actual contract and venue.','Does not simulate exercise, assignment, event eligibility or marked-to-market drawdown.']}
    except NoFill as e:
        return {'state':'NO_FILL','reason':str(e),'execution_enabled':False,'readiness_credit':0}
