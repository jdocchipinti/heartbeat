# Homepage for every adult chapter

Adds an illustrative image of adult men and women in their twenties alongside existing imagery welcoming older adults.

Includes an immediate five-step, self-guided planning exercise. It does not collect personal answers and is not therapy or a facilitated workshop.

Links to NAMI recorded learning, NAMI adult peer support, and SMART Recovery meeting directories. External schedules, registration, and capacity must be checked with providers. A separate US emotional-distress/crisis section links to 988; this is not an Institute counseling or appointment service.

Provider information checked October 28, 2026. No live availability is claimed. Trading rules are unchanged.
