import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch
import server as s
class ClarityAssetTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.book=Path(self.tmp.name)/'book.pdf';self.book.write_bytes(b'%PDF-test')
 def tearDown(self):self.tmp.cleanup()
 def request(self,path,auth='',method='GET'):
  meta={}
  def start(status,headers):meta.update(status=status,headers=dict(headers))
  with patch.dict(s.os.environ,{'HB_CLARITY_WORKBOOK_PATH':str(self.book)}),patch.object(s,'ensure_started'),patch.object(s,'TOKEN','test-token-'*4),patch.object(s.browser_sessions,'validate',return_value=None):
   body=b''.join(s.application({'PATH_INFO':path,'REQUEST_METHOD':method,'HTTP_AUTHORIZATION':auth},start))
  return meta,body
 def test_public_card_and_sample(self):
  for name in ['clarity-free-sample.pdf','clarity-consultation-card.pdf']:
   meta,body=self.request('/assets/'+name)
   self.assertEqual(meta['status'],'200 OK');self.assertEqual(meta['headers']['Content-Type'],'application/pdf');self.assertTrue(body.startswith(b'%PDF'))
 def test_owner_only_workbook(self):
  meta,_=self.request('/api/clarity/workbook');self.assertEqual(meta['status'],'401 Unauthorized')
  meta,body=self.request('/api/clarity/workbook','Bearer '+'test-token-'*4);self.assertEqual(meta['status'],'200 OK');self.assertTrue(body.startswith(b'%PDF'));self.assertEqual(meta['headers']['Cache-Control'],'no-store')
  for path in ['/products/your-next-chapter.pdf','/assets/your-next-chapter.pdf']:
   meta,_=self.request(path);self.assertEqual(meta['status'],'404 Not Found')
 def test_public_asset_methods(self):
  meta,body=self.request('/assets/clarity-consultation-card.pdf',method='HEAD');self.assertEqual(meta['status'],'200 OK');self.assertEqual(body,b'')
  meta,_=self.request('/assets/clarity-consultation-card.pdf',method='POST');self.assertEqual(meta['status'],'405 Method Not Allowed')
