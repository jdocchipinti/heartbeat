import io,json,sqlite3,tempfile,unittest
from contextlib import redirect_stderr
from unittest.mock import patch
import server as s
import crypto_paper as c

class StatusErrors(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.w=c.Experiment(self.tmp.name+'/paper.db','test-key','test-secret',True)
    def tearDown(self):
        if self.w.filelock:self.w.filelock.close()
        self.tmp.cleanup()
    def call(self,path='/api/crypto/paper',method='GET'):
        status=[]
        with patch.object(s,'CRYPTO',self.w),patch.object(s,'TOKEN','x'*32),patch.object(s,'ensure_started'):
            raw=b''.join(s.application({'PATH_INFO':path,'REQUEST_METHOD':method,'HTTP_AUTHORIZATION':'Bearer '+'x'*32},lambda code,h:status.append(code)))
        return status[0],json.loads(raw)
    def test_resume_unstarted_returns_report_and_reason(self):
        self.w.error='PERSISTENT_DISK_REQUIRED'
        code,d=self.call('/api/crypto/resume','POST')
        self.assertEqual(code,'409 Conflict');self.assertEqual(d['error'],'PERSISTENT_DISK_REQUIRED');self.assertFalse(d['report']['controls_available']);self.assertTrue(d['report']['connections']['checks'])
        self.assertIsNone(self.w.s)
    def test_disabled_worker_is_not_unpaused(self):
        self.w.enabled=False
        code,d=self.call('/api/crypto/resume','POST')
        self.assertEqual(d['error'],'WORKER_DISABLED');self.assertEqual(code,'409 Conflict')
    def test_get_unstarted_keeps_useful_status(self):
        code,d=self.call();self.assertEqual(code,'200 OK');self.assertFalse(d['worker_started']);self.assertFalse(d['controls_available']);self.assertIsNone(d['state'])
    def test_busy_control_returns_retry_code(self):
        self.w.started=True
        with patch.object(self.w,'pause',side_effect=c.PaperError('CYCLE_BUSY_RETRY')):
            code,d=self.call('/api/crypto/resume','POST')
        self.assertEqual(code,'409 Conflict');self.assertEqual(d['error'],'CYCLE_BUSY_RETRY')
    def test_failed_diagnostics_does_not_hide_report(self):
        with patch.object(s.paper_connections,'check',side_effect=ValueError('secret fixture')),redirect_stderr(io.StringIO()) as logs:
            code,d=self.call()
        self.assertEqual(code,'200 OK');self.assertEqual(d['connections']['checks'][0]['state'],'UNAVAILABLE');self.assertNotIn('secret fixture',logs.getvalue()+json.dumps(d))
    def test_storage_and_unexpected_errors_safe_and_specific(self):
        for err,expected in [(sqlite3.OperationalError('secret database path'),'CRYPTO_STORAGE_UNAVAILABLE'),(ValueError('secret provider body'),'CRYPTO_REPORT_UNAVAILABLE')]:
            with patch.object(self.w,'status',side_effect=err),redirect_stderr(io.StringIO()) as logs:code,d=self.call()
            self.assertEqual(code,'503 Service Unavailable');self.assertEqual(d['error'],expected);self.assertNotIn('secret',logs.getvalue()+json.dumps(d))
