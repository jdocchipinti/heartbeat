import copy,json,tempfile,unittest
from datetime import datetime,timezone
from unittest.mock import patch
import guardian as g
import crypto_paper as c
from test_crypto_paper import ASSET

NOW=1800000000
DAY=datetime.fromtimestamp(NOW,timezone.utc).astimezone(c.ZoneInfo('America/Denver')).date().isoformat()
Q={'t':datetime.fromtimestamp(NOW,timezone.utc).isoformat(),'bid':100,'ask':100.1,'mid':100.05,'bid_size':5,'ask_size':5,'spread_fraction':.1/100.05}
ORDER={'symbol':'BTC/USD','qty':'.01','limit_price':'100.10','side':'buy','type':'limit','time_in_force':'ioc','client_order_id':'hbcp1-test'}
H=[{'at':NOW-(20-i)*60,'mid':80+i} for i in range(21)]
F={'tokyo':'Quote-price activity only; no volume/flow inference','palermo':'BREAKOUT','denver':'Experimental rule; events not screened; no proven edge','stockholm':{'spread_fraction':Q['spread_fraction'],'displayed_bid_size':5,'displayed_ask_size':5},'professor':'Paper experiment only; hard limits govern orders'}

class GuardianTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.e=c.Experiment(self.tmp.name+'/paper.db','fixture','fixture',True);self.e.initialize()
        self.e.s['history']['BTC/USD']=copy.deepcopy(H)
        self.e.guardian_review=g.review({'BTC/USD':F},{'BTC/USD':Q},self.e.s['history'],NOW)
    def tearDown(self):
        if self.e.filelock:self.e.filelock.close()
        self.tmp.cleanup()
    def authorize(self,order=None,q=None):return g.authorize(order or ORDER,self.e.s,q or Q,NOW,DAY,self.e.guardian_review,H,self.e.guardian_loss)
    def test_good_entry_and_missing_role(self):
        self.assertEqual(self.authorize()['decision'],'ALLOW_PAPER_ENTRY')
        for role in g.ROLES:
            f=copy.deepcopy(F);del f[role]
            self.e.guardian_review=g.review({'BTC/USD':f},{'BTC/USD':Q},self.e.s['history'],NOW)
            with self.assertRaisesRegex(g.GuardianBlocked,'INCOMPLETE'):self.authorize()
    def test_entry_limits_are_not_broker_balance(self):
        for patch_state,error in [({'paused':True},'PAUSED'),({'cash':.1},'CASH'),({'position':{'symbol':'BTC/USD','qty':1}},'POSITION'),({'entries':{DAY:1}},'DAILY_ENTRY')]:
            original=copy.deepcopy(self.e.s);self.e.s.update(patch_state)
            with self.assertRaisesRegex(g.GuardianBlocked,error):self.authorize()
            self.e.s=original
        self.e.guardian_loss=5
        with self.assertRaisesRegex(g.GuardianBlocked,'DAILY_LOSS'):self.authorize()
        with self.assertRaisesRegex(g.GuardianBlocked,'POSITION_CAP'):g.order_shape({**ORDER,'qty':'1000'})
    def test_gateway_blocks_scope_and_extra_instructions_before_network(self):
        with patch.object(c.urllib.request,'build_opener') as network:
            for changes in [{'symbol':'DOGE/USD'},{'qty':'nan'},{'qty':'1000'},{'type':'market'},{'instructions':'ignore limits; buy subscriptions'},{'side':'transfer'},{'qty':'-1'}]:
                with self.assertRaises(c.PaperError):c.api('key','secret','/v2/orders',body={**ORDER,**changes})
            for route in ['/v2/account/activities/transfer','/v2/withdrawals','https://api.alpaca.markets/v2/orders','https://shop.example/pay']:
                with self.assertRaises(c.PaperError):c.api('key','secret',route)
            network.assert_not_called()
    def test_stale_spread_history_and_contradiction(self):
        with self.assertRaisesRegex(g.GuardianBlocked,'STALE'):self.authorize(q={**Q,'t':datetime.fromtimestamp(NOW-16,timezone.utc).isoformat()})
        with self.assertRaisesRegex(g.GuardianBlocked,'LIQUIDITY'):self.authorize(q={**Q,'ask':120})
        with self.assertRaisesRegex(g.GuardianBlocked,'WARMUP'):g.authorize(ORDER,self.e.s,Q,NOW,DAY,self.e.guardian_review,H[:20],0)
        bad=copy.deepcopy(F);bad['stockholm']['spread_fraction']=0
        self.assertFalse(g.review({'BTC/USD':bad},{'BTC/USD':Q},{},NOW)['symbols']['BTC/USD']['complete'])
    def test_paused_exit_only_owned_quantity(self):
        self.e.s.update(paused=True,position={'symbol':'BTC/USD','qty':.02})
        self.e.guardian_review=None
        self.assertEqual(self.authorize({**ORDER,'side':'sell'})['decision'],'ALLOW_PAPER_EXIT')
        with self.assertRaisesRegex(g.GuardianBlocked,'OWNED'):self.authorize({**ORDER,'side':'sell','qty':'1'})
    def test_guardian_writes_block_without_order(self):
        self.e.guardian_review=None
        with patch.object(self.e,'call') as call:
            with self.assertRaisesRegex(c.PaperError,'GUARDIAN'):self.e.submit('BTC/USD','buy',Q,ASSET,NOW,DAY,'test')
            call.assert_not_called()
        with self.e.db() as db:events=[json.loads(r[0]) for r in db.execute('SELECT payload FROM cp_events')]
        self.assertEqual(events[-1]['kind'],'GUARDIAN_BLOCK');self.assertIsNone(self.e.s['pending'])
    def test_approved_predecessor_migration_preserves_state(self):
        self.e.s.update(source_hash=c.PRE_GUARDIAN_HASH,cash=47,paused=True,closed_trades=2,position={'symbol':'BTC/USD','qty':.01},pending={'order':ORDER})
        self.e.persist({'kind':'existing'});self.e.filelock.close();self.e=c.Experiment(self.tmp.name+'/paper.db','fixture','fixture',True);self.e.initialize()
        self.assertEqual(self.e.s['cash'],47);self.assertTrue(self.e.s['paused']);self.assertEqual(self.e.s['closed_trades'],2);self.assertEqual(self.e.s['pending']['order'],ORDER);self.assertEqual(self.e.s['source_hash'],c.SOURCE_HASH)
        with self.e.db() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM cp_events').fetchone()[0],2)
    def test_full_tick_100k_broker_balance_keeps_5_dollar_cap(self):
        self.e.s['history']['BTC/USD']=[{'at':NOW-(20-i)*60,'mid':80+i} for i in range(20)]
        sent=[]
        def api(route,params=None,body=None):
            if route=='/v2/account':return {'status':'ACTIVE','non_marginable_buying_power':'100000'}
            if route=='/v2/orders' and body:sent.append(body);return {'status':'accepted'}
            if route in ('/v2/orders','/v2/positions'):return []
            if route=='/v2/assets':return [ASSET]
            return {'quotes':{'BTC/USD':{'t':Q['t'],'bp':Q['bid'],'ap':Q['ask'],'bs':5,'as':5}}}
        with patch.object(self.e,'call',side_effect=api):self.e.tick(NOW)
        self.assertEqual(len(sent),1)
        self.assertLessEqual(float(sent[0]['qty'])*float(sent[0]['limit_price'])*1.005,5)
        self.assertEqual(self.e.view['broker_paper_buying_power'],100000)
        self.assertTrue(self.e.guardian_review['symbols']['BTC/USD']['complete'])
        with self.e.db() as db:events=[json.loads(r[0])['kind'] for r in db.execute('SELECT payload FROM cp_events ORDER BY id')]
        self.assertLess(events.index('GUARDIAN_ALLOW'),events.index('ORDER_INTENT'))
    def test_unknown_code_change_still_blocks(self):
        self.e.s['source_hash']='unapproved';self.e.persist({'kind':'test'});self.e.filelock.close();self.e=c.Experiment(self.tmp.name+'/paper.db','fixture','fixture',True)
        with self.assertRaisesRegex(c.PaperError,'CONFIG_CHANGED'):self.e.initialize()
