import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
import evidence_storage as storage
from option_execution import model_round_trip

class OptionTests(unittest.TestCase):
    def setUp(self):
        self.contract={'shares_per_contract':100,'contract_type':'call'}
        self.q={'sip_timestamp':10_000_000_000,'sequence_number':1,'bid_price':.02,'ask_price':.02,'bid_size':2,'ask_size':2}
        self.x={**self.q,'sip_timestamp':20_000_000_000,'bid_price':.04,'ask_price':.04}
    def run_model(self,**kw):
        args=dict(contract=self.contract,entry_quotes=[self.q],exit_quotes=[self.x],entry_decision_ns=10_000_000_000,exit_decision_ns=20_000_000_000,expiration_ns=30_000_000_000,entry_limit='.03',exit_limit='.03')
        args.update(kw)
        return model_round_trip(**args)
    def test_cost_multiplier_no_double_theta(self):
        r=self.run_model()
        self.assertEqual(r['state'],'MODELED_FILL_ONLY')
        self.assertEqual(r['net_pnl'],'-1.30')
        self.assertEqual(r['full_premium_plus_assumed_fees'],'4.30')
        self.assertFalse(r['execution_enabled'])
    def test_future_and_stale_quotes(self):
        self.assertEqual(self.run_model(entry_quotes=[{**self.q,'sip_timestamp':11_000_000_000}])['state'],'NO_FILL')
        self.assertEqual(self.run_model(entry_quotes=[{**self.q,'sip_timestamp':7_000_000_000}])['reason'],'STALE_QUOTE')
    def test_no_cherry_picking_bad_latest_quote(self):
        bad={**self.q,'sip_timestamp':10_100_000_000,'bid_price':.10}
        self.assertEqual(self.run_model(entry_quotes=[self.q,bad])['reason'],'ZERO_OR_CROSSED_QUOTE')
    def test_limits_depth_budget_and_incomplete(self):
        for kw,reason in [({'entry_limit':'.02'},'LIMIT_NOT_MARKETABLE_UNDER_ASSUMPTIONS'),({'max_loss':'4'},'FULL_PREMIUM_LOSS_EXCEEDS_LIMIT'),({'budget':'3'},'BUDGET_EXCEEDED'),({'complete':False},'INCOMPLETE_QUOTE_WINDOW'),({'entry_quotes':[{**self.q,'ask_size':0}]},'INSUFFICIENT_DISPLAYED_SIZE')]:
            self.assertEqual(self.run_model(**kw)['reason'],reason)
    def test_nonstandard_expired_and_conflicting(self):
        self.assertEqual(self.run_model(contract={'shares_per_contract':10,'contract_type':'call'})['reason'],'NONSTANDARD_CONTRACT')
        self.assertEqual(self.run_model(expiration_ns=20_100_000_000)['reason'],'INVALID_CHRONOLOGY_OR_EXPIRATION')
        self.assertEqual(self.run_model(entry_quotes=[self.q,{**self.q,'ask_price':.03}])['reason'],'CONFLICTING_QUOTES')

class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=self.tmp.name+'/evidence.sqlite3'
    def tearDown(self):self.tmp.cleanup()
    def test_reopen_recovery_and_id_conflict(self):
        storage.save(self.path,'','report1','pilot_report',{'count':27})
        self.assertEqual(storage.latest(self.path,'','pilot_report')['payload']['count'],27)
        with self.assertRaises(storage.StorageError):storage.save(self.path,'','report1','pilot_report',{'count':28})
        self.assertEqual(storage.latest(self.path,'','pilot_report')['payload']['count'],27)
    def test_cross_process_probe(self):
        self.assertFalse(storage.verify(self.path,'','first')['prior_process_record_read'])
        self.assertTrue(storage.verify(self.path,'','second')['prior_process_record_read'])
    def test_postgres_failure_never_falls_back(self):
        with self.assertRaises(storage.StorageError):
            with storage.connect(self.path,'invalid-database-url'):pass
        self.assertFalse(Path(self.path).exists())
    def test_quote_access_denial_keeps_evidence(self):
        import server as s
        contract={'ticker':'O:SPY250620C00600000','shares_per_contract':100,'contract_type':'call'}
        with patch.object(s,'DB',self.path),patch.object(s,'DATABASE_URL',''),patch.object(s,'STORAGE',None),patch.object(s,'request',side_effect=[{'results':[contract]},s.ProviderError('ENTITLEMENT_DENIED')]):
            s.option_access_job()
            self.assertEqual(s.ACCESS['result']['quote_access'],'ENTITLEMENT_DENIED')
            saved=storage.latest(self.path,'','option_access')
            self.assertEqual(saved['payload']['readiness_credit'],0)

if __name__=='__main__':unittest.main()
