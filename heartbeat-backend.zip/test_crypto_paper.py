import json
import tempfile
import time
import unittest
from unittest.mock import patch
from datetime import datetime,timezone
import crypto_paper as c
import server

ASSET={'symbol':'BTC/USD','tradable':True,'status':'active','class':'crypto','min_order_size':'0.000001','min_trade_increment':'0.000001','price_increment':'0.01'}
Q={'bid':100,'ask':100.1,'bid_size':5,'ask_size':5,'mid':100.05,'spread_fraction':0.001,'t':'2026-09-28T19:00:00Z'}
class CryptoTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=self.tmp.name+'/paper.db'
        self.e=c.Experiment(self.path,'fixture-key','fixture-secret',True);self.e.initialize()
    def submit(self,symbol,side,q,asset,now,day,reason,qty=None):
        # Valid current assessments for existing order/reconciliation fixtures.
        q={**q,'t':datetime.fromtimestamp(now,timezone.utc).isoformat()}
        self.e.s['history'][symbol]=[{'at':now-(20-i)*60,'mid':80+i} for i in range(21)]
        self.e.guardian_review={'checked_at':now,'symbols':{symbol:{'complete':True,'entry_trigger':True}}}
        return self.e.submit(symbol,side,q,asset,now,day,reason,qty)
    def tearDown(self):
        if self.e.filelock:self.e.filelock.close()
        self.tmp.cleanup()
    def test_position_cap_includes_fee(self):
        qty,price=c.size_order(ASSET,Q,5)
        self.assertLessEqual(float(qty)*float(price)*1.005,5)
        self.assertGreater(float(qty),0)
    def test_minimum_cannot_override_cap(self):
        with self.assertRaisesRegex(c.PaperError,'MINIMUM_EXCEEDS'):c.size_order({**ASSET,'min_order_size':'1'},Q,5)
    def test_stale_future_crossed_invalid(self):
        now=datetime(2026,9,28,19,tzinfo=timezone.utc).timestamp()
        raw={'t':Q['t'],'bp':100,'ap':101,'bs':1,'as':1}
        self.assertGreater(c.quote(raw,now)['bid'],0)
        for t in [now+16,now-1]:
            with self.assertRaises(c.PaperError):c.quote(raw,t)
        for bad in [{'bp':102},{'bp':float('nan')},{'as':0}]:
            with self.assertRaises(c.PaperError):c.quote({**raw,**bad},now)
    def test_signal_requires_chronology(self):
        h=[{'at':i*60,'mid':100+i} for i in range(21)]
        self.assertTrue(c.signal(h));self.assertFalse(c.signal(h[:-1]))
        h[8]['at']+=500;self.assertFalse(c.signal(h))
    def test_persist_before_uncertain_submit_and_no_resubmit(self):
        def uncertain(*args,**kwargs):
            with self.e.db() as db:state=json.loads(db.execute('SELECT payload FROM cp_state').fetchone()[0])
            self.assertTrue(state['pending']);raise c.PaperError('REQUEST_UNCERTAIN')
        with patch.object(self.e,'call',side_effect=uncertain):self.submit('BTC/USD','buy',Q,ASSET,1000,'2026-09-28','test')
        cid=self.e.s['pending']['order']['client_order_id']
        self.e.filelock.close();self.e=c.Experiment(self.path,'fixture-key','fixture-secret',True);self.e.initialize()
        self.assertEqual(self.e.s['pending']['order']['client_order_id'],cid)
        with patch.object(self.e,'call',side_effect=c.PaperError('NOT_FOUND')) as api:
            with self.assertRaises(c.PaperError):self.e.reconcile(1100)
            self.assertEqual(api.call_args.args[0],'/v2/orders:by_client_order_id')
    def test_fill_only_counted_once_and_fee_deducted(self):
        with patch.object(self.e,'call',return_value={'status':'accepted'}):self.submit('BTC/USD','buy',Q,ASSET,1000,'2026-09-28','test')
        p=self.e.s['pending']['order']
        response={'client_order_id':p['client_order_id'],'status':'filled','filled_qty':p['qty'],'filled_avg_price':p['limit_price']}
        with patch.object(self.e,'call',return_value=response):self.e.reconcile(1001);first=self.e.s['cash'];self.e.reconcile(1002)
        self.assertEqual(self.e.s['cash'],first);self.assertLess(first,50)
        self.assertAlmostEqual(50-first,float(p['qty'])*float(p['limit_price'])*1.005)
    def test_partial_fill_terminal_becomes_position(self):
        with patch.object(self.e,'call',return_value={}):self.submit('BTC/USD','buy',Q,ASSET,1000,'2026-09-28','test')
        p=self.e.s['pending']['order'];r={'client_order_id':p['client_order_id'],'status':'canceled','filled_qty':'0.01','filled_avg_price':'100'}
        with patch.object(self.e,'call',return_value=r):self.e.reconcile(1001)
        self.assertEqual(self.e.s['position']['qty'],0.01);self.assertIsNone(self.e.s['pending'])
    def test_dedicated_account_required(self):
        def api(route,*args):
            return {'status':'ACTIVE'} if route=='/v2/account' else [] if route=='/v2/orders' else [{'symbol':'DOGEUSD','qty':'10'}]
        with patch.object(self.e,'call',side_effect=api):
            with self.assertRaisesRegex(c.PaperError,'DEDICATED'):self.e.tick(1000)
    def test_mount_required_and_no_live_routes(self):
        e=c.Experiment(self.path,'key','secret',True)
        with patch.object(c.os.path,'ismount',return_value=False):e.start()
        self.assertEqual(e.error,'PERSISTENT_DISK_REQUIRED');self.assertFalse(e.started)
        with self.assertRaises(c.PaperError):c.api('key','secret','https://api.alpaca.markets/v2/orders')
        with self.assertRaises(c.PaperError):c.api('key','secret','/v2/orders',body={'type':'market'})
    def test_http_post_targets_paper_only(self):
        class Response:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,*args):return b'{"status":"accepted"}'
        class Opener:
            def open(_,request,timeout):
                self.assertTrue(request.full_url.startswith('https://paper-api.alpaca.markets/'))
                return Response()
        with patch.object(c.urllib.request,'build_opener',return_value=Opener()):
            c.api('key','secret','/v2/orders',body={'type':'limit','time_in_force':'ioc','symbol':'BTC/USD','side':'buy','client_order_id':'hbcp1-test','qty':'0.001','limit_price':'1'})
    def test_http_auth_and_controls(self):
        self.e.started=True
        def call(path,method='GET',auth=''):
            codes=[];body=b''.join(server.application({'PATH_INFO':path,'REQUEST_METHOD':method,'HTTP_AUTHORIZATION':auth},lambda code,h:codes.append(code)))
            return codes[0],body
        with patch.object(server,'ensure_started',lambda:None),patch.object(server,'TOKEN','x'*32),patch.object(server,'CRYPTO',self.e):
            self.assertEqual(call('/api/crypto/paper')[0],'401 Unauthorized')
            self.assertEqual(call('/api/crypto/pause','POST','Bearer '+'x'*32)[0],'200 OK');self.assertTrue(self.e.s['paused'])
            self.assertEqual(call('/api/crypto/resume','GET','Bearer '+'x'*32)[0],'405 Method Not Allowed')
            self.assertNotIn(b'fixture-secret',call('/api/crypto/paper','GET','Bearer '+'x'*32)[1])
    def test_round_trip_pnl_and_day_entry_limit(self):
        with patch.object(self.e,'call',return_value={}):self.submit('BTC/USD','buy',Q,ASSET,1000,'2026-09-28','test')
        buy=self.e.s['pending']['order']
        with patch.object(self.e,'call',return_value={'client_order_id':buy['client_order_id'],'status':'filled','filled_qty':buy['qty'],'filled_avg_price':buy['limit_price']}):self.e.reconcile(1001)
        qty=self.e.s['position']['qty'];cost=self.e.s['position']['cost']
        with patch.object(self.e,'call',return_value={}):self.submit('BTC/USD','sell',{**Q,'bid':110,'ask':110.1},ASSET,2000,'2026-09-28','test',qty)
        sell=self.e.s['pending']['order']
        with patch.object(self.e,'call',return_value={'client_order_id':sell['client_order_id'],'status':'filled','filled_qty':sell['qty'],'filled_avg_price':sell['limit_price']}):self.e.reconcile(2001)
        self.assertEqual(self.e.s['closed_trades'],1);self.assertEqual(self.e.s['entries']['2026-09-28'],1)
        self.assertAlmostEqual(self.e.s['realized_estimate'],qty*110*.995-cost)
        self.assertIsNone(self.e.s['position'])
        def api(route,*args):
            if route=='/v2/account':return {'status':'ACTIVE','non_marginable_buying_power':'1000'}
            if route in ('/v2/orders','/v2/positions'):return []
            if route=='/v2/assets':return [ASSET]
            return {'quotes':{}}
        with patch.object(self.e,'call',side_effect=api),patch.object(self.e,'submit') as submit:
            self.e.tick(datetime(2026,9,28,19,tzinfo=timezone.utc).timestamp());submit.assert_not_called()
    def test_sqlite_backup_recovers_state(self):
        self.e.persist({'kind':'test'});self.e.backup(1000)
        import sqlite3
        with sqlite3.connect(self.path+'.1970-01-01.backup') as db:
            state=json.loads(db.execute('SELECT payload FROM cp_state').fetchone()[0])
        self.assertEqual(state['cash'],50)
