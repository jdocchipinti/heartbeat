import copy
import unittest
import agent_review as a
import decision_journal as j
from test_decision_journal import observation

class ReviewTests(unittest.TestCase):
    def test_five_initials_and_bounded_review(self):
        r=j.build(observation());c=r['collaboration']
        self.assertEqual(len(c['initial_claims']),5)
        self.assertEqual({m['from'] for m in c['messages']},set(a.ROLES))
        self.assertLessEqual(len(c['messages']),c['max_unique_messages'])
        self.assertEqual(c['rounds_completed'],1)
        self.assertEqual(c['resolution']['initial_sha256'],a.sha(r['initial_assessments']))
        self.assertEqual(c['shared_evidence']['source_families'],1)
        self.assertEqual(c['cost']['additional_market_requests'],0)
    def test_references_resolve(self):
        c=j.build(observation())['collaboration']
        evidence={e['id'] for e in c['shared_evidence']['items']}
        claims={e['id'] for e in c['initial_claims']}
        for m in c['messages']:
            self.assertTrue(set(m['evidence_ids'])<=evidence)
            self.assertTrue(set(m['claim_ids'])<=claims)
            self.assertTrue(m['claim_ids'])
    def test_exact_duplicates_removed(self):
        s=observation();s['bars'].append(copy.deepcopy(s['bars'][0]))
        b=a.board(s);self.assertEqual(b['unique_items'],21);self.assertEqual(b['duplicate_items_removed'],1)
        m={'from':'tokyo','to':['denver'],'kind':'FINDING','evidence_ids':['e'],'claim_ids':['c'],'body':'Same finding'}
        n={**m,'from':'palermo','to':['professor']}
        result=a.deduplicate([m,n])
        self.assertEqual(len(result),1)
        self.assertEqual(set(result[0]['contributors']),{'tokyo','palermo'})
        self.assertEqual(set(result[0]['to']),{'denver','professor'})
    def test_cannot_override_gate(self):
        r=j.build(observation());c=r['collaboration']
        self.assertTrue(r['underlying_watch']);self.assertFalse(c['health']['trade_eligible'])
        self.assertFalse(c['resolution']['risk_override_allowed'])
        self.assertIsNone(c['comparison']['profit_improvement'])
        self.assertEqual(c['comparison']['without_review'],c['comparison']['with_review'])
    def test_initials_unchanged(self):
        r=j.build(observation());initial=copy.deepcopy(r['initial_assessments']);before=copy.deepcopy(initial)
        c=a.run(r['snapshot'],initial);c['initial_claims'][0]['assessment']['status']='changed'
        self.assertEqual(initial,before)
    def test_disagreement_preserved(self):
        s=observation()
        for i,b in enumerate(s['bars']):b['c']=200-i;b['o']=200-i;b['h']=201-i;b['l']=199-i
        c=j.build(s)['collaboration']
        self.assertTrue(c['resolution']['disagreement'])
    def test_reproducible(self):
        self.assertEqual(j.build(observation())['collaboration'],j.build(observation())['collaboration'])

if __name__=='__main__':unittest.main()
