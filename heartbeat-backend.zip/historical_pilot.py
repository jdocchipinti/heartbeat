"""Reproducible, retrospective underlying-price pilot. Never awards readiness."""
import csv
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_bars(path):
    if path.suffix == '.csv':
        with path.open() as f:
            rows = [{k: float(v) for k, v in r.items()} for r in csv.DictReader(f)]
    else:
        raw = json.loads(path.read_text())
        rows = [dict(zip(('t','o','h','l','c','v'),map(float,r[:6]))) for r in raw]
    result=[]
    for r in rows:
        b={k:r[k] for k in ('t','o','h','l','c','v')}
        if not all(math.isfinite(v) for v in b.values()) or b['t']<=0 or min(b['o'],b['h'],b['l'],b['c'])<=0 or b['v']<0 or b['h']<max(b['o'],b['l'],b['c']) or b['l']>min(b['o'],b['c']):
            raise ValueError('Invalid OHLCV '+path.name)
        b['t']=int(b['t'])
        b['date']=datetime.fromtimestamp(b['t']/1000,timezone.utc).date().isoformat()
        if result and (b['t']<=result[-1]['t'] or b['date']<=result[-1]['date']):
            raise ValueError('Duplicate or unordered daily bar '+path.name)
        result.append(b)
    return result

def decision(history, cfg):
    """Receives only observations through decision bar. No forward prices."""
    if len(history)<21:return {'accepted':False,'reason':'WARMUP','rvol':None,'regime':'UNKNOWN'}
    baseline=sum(b['v'] for b in history[-21:-1])/20
    rvol=history[-1]['v']/baseline if baseline else None
    fast=sum(b['c'] for b in history[-5:])/5
    slow=sum(b['c'] for b in history[-20:])/20
    # A descriptive past-only regime proxy, not a macroeconomic classifier.
    move=history[-1]['c']/history[-21]['c']-1
    regime='UP_20BAR' if move>.02 else 'DOWN_20BAR' if move<-.02 else 'RANGE_20BAR'
    reasons=[]
    if rvol is None or rvol<cfg['relative_volume_minimum']:reasons.append('VOLUME BELOW RULE')
    if fast<=slow:reasons.append('TREND NOT CONFIRMED')
    return {'accepted':not reasons,'reason':'; '.join(reasons) or 'RULE MATCH','rvol':rvol,'regime':regime}

def replay(symbol,provider,bars,cfg):
    ledger=[]
    for w,(start,end) in enumerate(cfg['windows']):
        occupied=-1
        for i,b in enumerate(bars):
            if not start<=b['date']<end:continue
            d=decision(bars[:i+1],cfg)
            entry=i+2
            exit_index=entry+cfg['holding_bars']-1
            future=exit_index<len(bars) and bars[exit_index]['date']<end
            # Reject censored observations instead of carrying outcomes into another window.
            state='ACCEPTED' if d['accepted'] else 'REJECTED'
            reason=d['reason']
            if not future:state,reason='CENSORED','OUTCOME CROSSES WINDOW OR DATA END'
            elif d['accepted'] and entry<=occupied:state,reason='REJECTED','EXISTING POSITION IN THIS SYMBOL'
            cost=2*cfg['cost_bps_per_side'][provider]/10000
            gross=bars[exit_index]['c']/bars[entry]['o']-1 if future else None
            if state=='ACCEPTED':occupied=exit_index
            ledger.append({'id':f'{cfg["version"]}-{symbol}-{b["date"]}','symbol':symbol,'provider':provider,'window':w+1,'decision_date':b['date'],'latest_feature_bar_time':b['t'],'entry_date':bars[entry]['date'] if future else None,'exit_date':bars[exit_index]['date'] if future else None,'decision':state,'reason':reason,'regime':d['regime'],'relative_volume':d['rvol'],'gross_return_pct':gross*100 if gross is not None else None,'assumed_roundtrip_cost_bps':cost*10000,'net_return_pct':(gross-cost)*100 if gross is not None else None,'double_cost_return_pct':(gross-2*cost)*100 if gross is not None else None,'instrument_type':'UNDERLYING','fill_model':'DAILY PRICE PROXY — NOT VERIFIED FILL'})
    return ledger

def stats(rows,key='net_return_pct'):
    ordered=sorted(rows,key=lambda r:(r['exit_date'],r['symbol']))
    values=[r[key] for r in ordered]
    equity=peak=100.0
    worst=0.0
    for v in values:
        # Illustrative serial closed-trade index; concurrent trades are NOT a portfolio.
        equity*=1+v/100
        peak=max(peak,equity)
        worst=max(worst,(peak-equity)/peak*100)
    return {'count':len(values),'expectancy_pct':sum(values)/len(values) if values else None,'win_rate_pct':100*sum(v>0 for v in values)/len(values) if values else None,'closed_trade_index_drawdown_pct':worst if values else None}

def report(cfg,ledger,manifest):
    windows=[]
    for i,(start,end) in enumerate(cfg['windows']):
        rows=[r for r in ledger if r['window']==i+1]
        trades=[r for r in rows if r['decision']=='ACCEPTED']
        resolved=[r for r in rows if r['decision']!='CENSORED']
        metrics=stats(trades)
        symbols=Counter(r['symbol'] for r in trades)
        regimes=Counter(r['regime'] for r in trades)
        share=max(symbols.values())/len(trades) if trades else None
        leave_symbol={s:stats([r for r in trades if r['symbol']!=s])['expectancy_pct'] for s in symbols}
        leave_regime={g:stats([r for r in trades if r['regime']!=g])['expectancy_pct'] for g in regimes}
        checks={
          'positive_expectancy':metrics['expectancy_pct'] is not None and metrics['expectancy_pct']>0,
          'minimum_trade_count':len(trades)>=cfg['minimum_trades_per_window'],
          'closed_trade_drawdown_proxy':metrics['closed_trade_index_drawdown_pct'] is not None and metrics['closed_trade_index_drawdown_pct']<=cfg['maximum_closed_trade_drawdown_pct'],
          'symbol_diversity':len(symbols)>=cfg['minimum_symbols_per_window'] and share<=cfg['maximum_symbol_share'],
          'regime_diversity':len(regimes)>=cfg['minimum_regimes_per_window'],
          'positive_without_each_symbol':bool(leave_symbol) and all(v is not None and v>0 for v in leave_symbol.values()),
          'positive_without_each_regime':bool(leave_regime) and all(v is not None and v>0 for v in leave_regime.values()),
          'positive_double_cost':bool(trades) and stats(trades,'double_cost_return_pct')['expectancy_pct']>0
        }
        windows.append({'window':i+1,'start':start,'end_exclusive':end,'observations':len(rows),'rejected':sum(r['decision']=='REJECTED' for r in rows),'censored':len(rows)-len(resolved),'metrics':metrics,'double_cost':stats(trades,'double_cost_return_pct'),'all_resolved_observations_control':stats(resolved),'by_symbol':{s:stats([r for r in trades if r['symbol']==s]) for s in symbols},'by_regime':{g:stats([r for r in trades if r['regime']==g]) for g in regimes},'leave_one_symbol_out':leave_symbol,'leave_one_regime_out':leave_regime,'diagnostic_checks':checks,'options_oos_pass':False})
    return {'version':cfg['version'],'generated_at':datetime.now(timezone.utc).isoformat(),'scope':cfg['scope'],'configuration':cfg,'source_manifest':manifest,'observation_count':len(ledger),'resolved_count':sum(r['decision']!='CENSORED' for r in ledger),'accepted_count':sum(r['decision']=='ACCEPTED' for r in ledger),'windows':windows,'phase1_options_status':'NOT PASSED','verified_options_observations':0,'paper_fill_count':0,'shadow_decision_count':0,'execution_enabled':False,'blockers':['Underlying-price pilot only; no historical options contracts or timestamped bid/ask fills.','Costs are assumed allowances, not observed spreads, fees or slippage.','No options repricing/theta evidence. Theta is not to be subtracted again when using actual option price changes.','Current hand-selected instruments; no point-in-time universe or expired/delisted-contract coverage audit.','Retrospective replay; not certified untouched out-of-sample evidence.','Closed-trade drawdown proxy is not marked-to-market portfolio drawdown.','No independently audited source history, immutable storage, or live paper/shadow evidence.'],'ledger':ledger}

def run(root=None):
    root=Path(root) if root else ROOT
    cfg=json.loads((root/'pilot_config.json').read_text())
    ledger=[]
    manifest=[]
    for symbol,provider in cfg['symbols'].items():
        path=root/'pilot_raw'/(symbol+('.csv' if provider=='Massive' else '.json'))
        bars=load_bars(path)
        if not bars or bars[0]['date']<cfg['start'] or bars[-1]['date']>cfg['end']:raise ValueError('Date coverage mismatch')
        manifest.append({'symbol':symbol,'provider':provider,'file':path.name,'sha256':digest(path),'bars':len(bars),'first_date':bars[0]['date'],'last_date':bars[-1]['date'],'retrieved_on':datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat(),'adjusted':False if provider=='Massive' else None})
        ledger.extend(replay(symbol,provider,bars,cfg))
    result=report(cfg,ledger,manifest)
    result['config_sha256']=digest(root/'pilot_config.json')
    result['runner_sha256']=digest(Path(__file__))
    (root/'pilot_report.json').write_text(json.dumps(result,indent=2,allow_nan=False))
    with (root/'pilot_ledger.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(ledger[0]));writer.writeheader();writer.writerows(ledger)
    print(json.dumps({k:result[k] for k in ('observation_count','resolved_count','accepted_count','phase1_options_status')}))
    for w in result['windows']:print(w['window'],w['metrics'],w['diagnostic_checks'])
    return result

if __name__=='__main__':run()
