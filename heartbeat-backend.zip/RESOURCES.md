# Resources v1 — October 28, 2026

Replaces Website Studio navigation and retires its API routes. Existing stored Studio records are not deleted; the archived module is not loaded by the server.

Public directory: 50 states and their capitals, selectable raised/perspective SVG map with a brain navigator, flat-map alternative, keyboard navigation, state/capital search, and mobile-responsive cards. Healthcare, mental health and wellness (including men and women), financial help and loans, government programs. No sign-in or payment gate. No application or personal health/income data collection.

State health and social-service links were extracted from these official directories on October 28, 2026:
- https://www.usa.gov/state-health
- https://www.usa.gov/state-social-services
- https://www.usa.gov/state-governments

National sources: HRSA Find a Health Center, SAMHSA FindTreatment.gov, NIMH, USAGov, SBA, Federal Student Aid. Links are starting points; each local provider, appointment, eligibility rule and funding availability must be confirmed with the administering organization. Capital names are search instructions, not fabricated local listings or automatically filtered search results. Not a live eligibility database. No continuous link monitoring. Review links at least every 60 days and regenerate the embedded directory when changing resources-directory.json.

Geography: generalized 2017 Census boundaries via https://github.com/topojson/us-atlas (ISC license). Alaska and Hawaii are insets. Capital points use approximate city centers, projected with d3.geoAlbersUsa, scale 1300, translate [487.5,305]. The brain and animated connection represent navigation, not live analysis. Washington DC and territories are outside this initial 50-state scope.

Deployment: rename this archive heartbeat-backend.zip, upload to the repository root replacing the existing archive, and use the existing Render deployment flow. No new credentials, services or environment variables required. Open /#resources after deployment. Trading, Guardian, feed and entry-lab strategy source files are unchanged from the previous release.

## Wellbeing collection v2
Warm cream/sage presentation, original AI-generated editorial triptych bundled locally, free session-only daily planner with download/clear, focus timer using wall-clock elapsed time with pause/reset, and a filterable marketplace preview. No plan storage, payment processing, affiliate tracking, health analytics, or seller fees connected. Existing free agency links stay available.

Book recommendations link to verified author/publisher pages: Atomic Habits (James Clear) and The Psychology of Money (Morgan Housel). The display does not reproduce book covers, claim seller affiliation, quote prices, or promise recovery/financial outcomes. SMART Recovery toolbox and NIAAA navigator links were verified October 28, 2026.

Commercial next step: owner applies for a Bookshop.org affiliate account and provides approved product/storefront links; add a clear commission disclosure next to those links when activated. Official signup: https://bookshop.org/affiliates/profile/introduction . This is referral revenue, not an extra charge added to another seller's checkout. Direct resale needs a separate supply/fulfillment arrangement, pricing, checkout, tax handling, shipping and return policies. No sales account was created during this build.
