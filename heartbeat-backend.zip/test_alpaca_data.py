import json
import unittest
from unittest.mock import patch
import urllib.error
import alpaca_data as a
import server

FIX={'snapshots':{'SPY260925C00600000':{'latestQuote':{'t':'2026-09-24T14:00:00Z','bp':1,'ap':1.1,'bs':2,'as':3}}},'next_page_token':'next'}
NOW=a.datetime(2026,9,24,14,0,tzinfo=a.timezone.utc).timestamp() 
class AlpacaTests(unittest.TestCase):
    def test_sample_is_not_full_coverage_or_execution(self):
        r=a.summarize(FIX,NOW+5)
        self.assertEqual(r['valid_recent_quote_count'],0)
        self.assertTrue(r['quotes'][0]['recent_indicative_observation'])
        self.assertFalse(r['usable_for_execution_model'])
        self.assertTrue(r['pagination_remaining']);self.assertFalse(r['execution_enabled'])
        self.assertEqual(r['readiness_credit'],0)
    def test_stale_future_and_crossed_quotes_rejected(self):
        for now in (NOW-1,NOW+31):self.assertEqual(a.summarize(FIX,now)['valid_recent_quote_count'],0)
        d=json.loads(json.dumps(FIX));d['snapshots'][next(iter(d['snapshots']))]['latestQuote']['bp']=2
        self.assertEqual(a.summarize(d,NOW)['valid_recent_quote_count'],0)
    def test_status_ages_quotes_without_mutating_snapshot(self):
        c=a.Collector('test-key','test-secret',lambda *args:None)
        c.items={'SPY':{**a.summarize(FIX,NOW),'received_at':NOW,'state':'OPRA_SAMPLE_RECEIVED'}}
        with patch.object(a.time,'time',return_value=NOW+200):r=c.status()
        self.assertEqual(r['symbols']['SPY']['state'],'COLLECTOR_STALE')
        self.assertEqual(r['symbols']['SPY']['valid_recent_quote_count'],0)
        self.assertEqual(c.items['SPY']['quotes'][0]['quote_age_seconds'],0)
        self.assertNotIn('test-secret',json.dumps(r))
    def test_failure_does_not_reuse_previous_quotes(self):
        c=a.Collector('test-key','test-secret',lambda *args:None)
        with patch.object(a,'fetch',return_value=FIX):c.cycle('SPY')
        with patch.object(a,'fetch',side_effect=a.DataError('OPRA_ACCESS_DENIED')):c.cycle('SPY')
        r=c.status()['symbols']['SPY'];self.assertEqual(r['quotes'],[]);self.assertEqual(r['error'],'OPRA_ACCESS_DENIED')
    def test_no_redirect_or_arbitrary_symbol(self):
        with self.assertRaises(a.DataError):a.NoRedirect().redirect_request(None,None,None,None,None,None)
        with self.assertRaises(a.DataError):a.fetch('test-key','test-secret','../account')
    def test_private_endpoint_and_no_orders(self):
        def call(path,auth='',method='GET'):
            codes=[]
            body=b''.join(server.application({'PATH_INFO':path,'REQUEST_METHOD':method,'HTTP_AUTHORIZATION':auth},lambda code,headers:codes.append(code)))
            return codes[0],body
        with patch.object(server,'ensure_started',lambda:None),patch.object(server,'TOKEN','x'*32):
            self.assertEqual(call('/api/data/alpaca')[0],'401 Unauthorized')
            self.assertEqual(call('/api/data/alpaca','Bearer '+'x'*32)[0],'200 OK')
            self.assertEqual(call('/api/data/alpaca','Bearer '+'x'*32,'POST')[0],'405 Method Not Allowed')
            self.assertEqual(call('/v2/orders','Bearer '+'x'*32,'POST')[0],'405 Method Not Allowed')
    def test_free_feed_is_explicit(self):
        with patch.object(a,'request_data',return_value=FIX) as req:
            a.fetch('key','secret','SPY')
            self.assertEqual(req.call_args.args[3]['feed'],'indicative')
        c=a.Collector('key','secret',lambda *args:None)
        self.assertEqual(c.status()['mode'],'FREE_RESEARCH')
    def test_historical_probe_does_not_claim_quotes(self):
        with patch.object(a,'request_data',side_effect=[{'bars':{'SPY250620C00600000':[{'t':'2025-06-02T14:00:00Z'}]},'next_page_token':'more'},a.DataError('ACCESS_DENIED')]) as req:
            r=a.history_probe('key','secret')
        self.assertEqual(req.call_count,2)
        self.assertEqual(r['results']['bars']['state'],'SAMPLE_RECEIVED')
        self.assertTrue(r['results']['bars']['pagination_remaining'])
        self.assertEqual(r['results']['trades']['error'],'ACCESS_DENIED')
        self.assertEqual(r['readiness_credit'],0)
        self.assertTrue(r['historical_bid_ask'].startswith('NOT_TESTED'))
    def test_empty_history_is_not_access_denied(self):
        with patch.object(a,'request_data',side_effect=[{'bars':{}},{'trades':{}}]):
            r=a.history_probe('key','secret')
        self.assertEqual(r['results']['bars']['state'],'EMPTY_SAMPLE')
        self.assertEqual(r['results']['trades']['state'],'EMPTY_SAMPLE')
if __name__=='__main__':unittest.main()
