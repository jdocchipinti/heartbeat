"""Guardian: deterministic oversight, not a profit predictor or OS sandbox."""
import math
from datetime import datetime
from types import MappingProxyType

POLICY=MappingProxyType({'version':'HB-GUARDIAN-001','mode':'paper_only','budget':50,'position_cap':5,'daily_loss_limit':5,'max_entries_per_day':1,'max_positions':1,'symbols':('BTC/USD','ETH/USD'),'order_type':'limit','time_in_force':'ioc','fee_allowance':0.005,'quote_max_age':15,'max_spread':0.005})
ROLES=('tokyo','palermo','denver','stockholm','professor')
class GuardianBlocked(Exception):pass

def finite(v):
    if isinstance(v,bool):raise GuardianBlocked('INVALID_NUMBER')
    try:n=float(v)
    except (TypeError,ValueError):raise GuardianBlocked('INVALID_NUMBER') from None
    if not math.isfinite(n):raise GuardianBlocked('INVALID_NUMBER')
    return n

def order_shape(order):
    fields={'symbol','qty','side','type','time_in_force','limit_price','client_order_id'}
    if set(order)!=fields:raise GuardianBlocked('ORDER_FIELDS_BLOCKED')
    if order['symbol'] not in POLICY['symbols'] or order['side'] not in ('buy','sell') or order['type']!='limit' or order['time_in_force']!='ioc' or not order['client_order_id'].startswith('hbcp1-'):raise GuardianBlocked('ORDER_SCOPE_BLOCKED')
    qty,price=finite(order['qty']),finite(order['limit_price'])
    if qty<=0 or price<=0:raise GuardianBlocked('INVALID_ORDER_SIZE')
    if order['side']=='buy' and qty*price*1.005>5+1e-8:raise GuardianBlocked('POSITION_CAP_EXCEEDED')

def review(findings,quotes,histories,now):
    symbols={}
    for symbol in POLICY['symbols']:
        f=findings.get(symbol,{})
        checks={r:{'state':'MISSING','detail':'No current assessment.'} for r in ROLES}
        q=quotes.get(symbol)
        if q:
            # Verify declared scope and consistency; shared input is one source, not five confirmations.
            values={
                'tokyo':f.get('tokyo')=='Quote-price activity only; no volume/flow inference',
                'palermo':f.get('palermo') in ('BREAKOUT','NO_TRIGGER'),
                'denver':f.get('denver')=='Experimental rule; events not screened; no proven edge',
                'stockholm':isinstance(f.get('stockholm'),dict) and f['stockholm'].get('spread_fraction')==q['spread_fraction'] and f['stockholm'].get('displayed_bid_size')==q['bid_size'] and f['stockholm'].get('displayed_ask_size')==q['ask_size'],
                'professor':f.get('professor')=='Paper experiment only; hard limits govern orders'}
            for role,ok in values.items():checks[role]={'state':'CHECKED' if ok else 'BLOCKED','detail':'Scope and current output checked.' if ok else 'Missing or inconsistent assessment.'}
        symbols[symbol]={'agents':checks,'complete':all(x['state']=='CHECKED' for x in checks.values()),'entry_trigger':f.get('palermo')=='BREAKOUT','observations':len(histories.get(symbol,[]))}
    return {'version':POLICY['version'],'checked_at':now,'symbols':symbols,'policy':dict(POLICY),'scope':'Checks structured outputs and enforces paper-order rules. Not an ethical certification, independent predictive model, or operating-system sandbox.','source_count':1,'profitability':'UNPROVEN'}

def authorize(order,state,q,now,day,oversight,history,loss):
    order_shape(order)
    qty,price=finite(order['qty']),finite(order['limit_price'])
    if state.get('pending'):raise GuardianBlocked('PENDING_ORDER_EXISTS')
    try:
        timestamp=datetime.fromisoformat(q['t'].replace('Z','+00:00'))
        if timestamp.tzinfo is None:raise ValueError()
        age=now-timestamp.timestamp()
    except (KeyError,ValueError,TypeError):raise GuardianBlocked('QUOTE_INVALID') from None
    bid,ask=finite(q['bid']),finite(q['ask'])
    if not 0<=age<=15 or not 0<bid<=ask:raise GuardianBlocked('QUOTE_STALE_OR_INVALID')
    if order['side']=='sell':
        pos=state.get('position')
        if not pos or pos['symbol']!=order['symbol'] or qty>finite(pos['qty'])+1e-10:raise GuardianBlocked('SELL_EXCEEDS_OWNED_POSITION')
        if qty>finite(q['bid_size']):raise GuardianBlocked('DISPLAYED_SIZE_INSUFFICIENT')
        # Pause and missing peer analysis must not block a valid risk-reducing exit.
        return {'decision':'ALLOW_PAPER_EXIT','reason':'Only the recorded position can be reduced.'}
    if state.get('paused') or state.get('position'):raise GuardianBlocked('ENTRY_PAUSED_OR_POSITION_OPEN')
    if finite(loss)>=5:raise GuardianBlocked('DAILY_LOSS_LIMIT')
    if state['entries'].get(day,0)>=1:raise GuardianBlocked('DAILY_ENTRY_LIMIT')
    if qty*price*1.005>finite(state['cash'])+1e-8:raise GuardianBlocked('EXPERIMENT_CASH_EXCEEDED')
    if (ask-bid)/((ask+bid)/2)>.005 or qty>finite(q['ask_size']):raise GuardianBlocked('LIQUIDITY_FAILED')
    if not oversight or not 0<=now-oversight['checked_at']<=15 or not oversight['symbols'].get(order['symbol'],{}).get('complete'):raise GuardianBlocked('AGENT_REVIEW_INCOMPLETE')
    if not oversight['symbols'][order['symbol']].get('entry_trigger'):raise GuardianBlocked('PALERMO_NOT_CONFIRMED')
    rows=history[-21:]
    if len(rows)!=21 or any(not 40<=rows[i]['at']-rows[i-1]['at']<=90 for i in range(1,21)) or not 0<=now-rows[-1]['at']<=15:raise GuardianBlocked('WARMUP_OR_CHRONOLOGY_FAILED')
    values=[finite(r['mid']) for r in rows]
    if not(values[-1]>max(values[:-1]) and sum(values[-5:])/5>sum(values[-20:])/20):raise GuardianBlocked('STRATEGY_CONDITIONS_NOT_MET')
    return {'decision':'ALLOW_PAPER_ENTRY','reason':'Current assessments and frozen order limits passed. Profit is not assured.'}
