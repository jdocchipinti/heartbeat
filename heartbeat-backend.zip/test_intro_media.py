import unittest
from unittest.mock import patch
import server
class IntroMediaTests(unittest.TestCase):
 def call(self,path,method='GET',range_value=''):
  capture={}
  def start(status,headers):capture.update(status=status,headers=dict(headers))
  with patch.object(server,'ensure_started'):
   body=b''.join(server.application({'PATH_INFO':path,'REQUEST_METHOD':method,'HTTP_RANGE':range_value},start))
  return capture,body
 def test_video_range_and_head(self):
  c,b=self.call('/assets/umbrella-intro.mp4',range_value='bytes=0-31');self.assertEqual(c['status'],'206 Partial Content');self.assertEqual(len(b),32);self.assertIn(b'ftyp',b);self.assertEqual(c['headers']['Content-Type'],'video/mp4')
  c,b=self.call('/assets/umbrella-intro.mp4','HEAD');self.assertEqual(b,b'');self.assertGreater(int(c['headers']['Content-Length']),100)
 def test_invalid_and_suffix(self):
  c,b=self.call('/assets/umbrella-intro.mp4',range_value='bytes=999999999-');self.assertEqual(c['status'],'416 Range Not Satisfiable')
  c,b=self.call('/assets/umbrella-intro.mp4',range_value='bytes=-16');self.assertEqual(len(b),16)
 def test_poster(self):
  c,b=self.call('/assets/umbrella-hero.jpg');self.assertEqual(c['headers']['Content-Type'],'image/jpeg');self.assertTrue(b.startswith(b'\xff\xd8'))
if __name__=='__main__':unittest.main()
