"""Private, human-reviewed outreach. No autonomous sending or prospect scraping."""
import hashlib,html,json,os,re,secrets,smtplib,sqlite3,ssl,time
from email.message import EmailMessage
from email.utils import formatdate,make_msgid
from urllib.parse import urlparse
BASE='https://umbrella-heartbeat-api.onrender.com'
class OutreachError(Exception):pass

def email(value):
    v=str(value).strip().lower()
    if len(v)>254 or not re.fullmatch(r"[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}",v):raise OutreachError('VALID_BUSINESS_EMAIL_REQUIRED')
    return v

def clean(value,maximum):
    if not isinstance(value,str) or not value.strip() or len(value)>maximum or any(ord(c)<32 for c in value):raise OutreachError('INVALID_FIELD')
    return value.strip()

def settings():
    return {k:os.getenv('HB_OUTREACH_'+k,'').strip() for k in ('ENABLED','SMTP_HOST','SMTP_PORT','SMTP_USER','SMTP_PASSWORD','FROM','POSTAL_ADDRESS','SENDER_CONFIRMED')}

def deliver(config,to,subject,body):
    message=EmailMessage();message['From']=config['FROM'];message['To']=to;message['Reply-To']=config['FROM'];message['Subject']=subject;message['Date']=formatdate(localtime=False);message['Message-ID']=make_msgid();message.set_content(body)
    port=int(config['SMTP_PORT']);context=ssl.create_default_context()
    if port==465:client=smtplib.SMTP_SSL(config['SMTP_HOST'],port,timeout=15,context=context)
    else:
        client=smtplib.SMTP(config['SMTP_HOST'],port,timeout=15)
        try:client.ehlo();client.starttls(context=context);client.ehlo()
        except Exception:client.close();raise
    try:
        client.login(config['SMTP_USER'],config['SMTP_PASSWORD'])
        refused=client.send_message(message)
        if refused:raise OutreachError('RECIPIENT_REFUSED')
        return message['Message-ID']
    finally:client.close()

class Workspace:
    def __init__(self,path,transport=deliver,require_mount=True):self.path=path;self.transport=transport;self.require_mount=require_mount
    def db(self):
        if self.require_mount and (not os.path.ismount('/var/data') or not os.path.realpath(self.path).startswith('/var/data/')):raise OutreachError('PERSISTENT_DISK_REQUIRED')
        db=sqlite3.connect(self.path,timeout=5);db.row_factory=sqlite3.Row
        db.execute('CREATE TABLE IF NOT EXISTS co_drafts(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,company TEXT,source TEXT,fact TEXT,subject TEXT,body TEXT,token TEXT,state TEXT,created REAL,attempt_at REAL,receipt TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS co_suppressed(email TEXT PRIMARY KEY,at REAL,reason TEXT)')
        return db
    def config(self):
        c=settings();missing=[]
        for k in ('SMTP_HOST','SMTP_USER','SMTP_PASSWORD','POSTAL_ADDRESS'):
            if not c[k]:missing.append(k)
        try:email(c['FROM'])
        except OutreachError:missing.append('FROM')
        if c['SMTP_PORT'] not in ('465','587'):missing.append('SMTP_PORT_465_OR_587')
        if c['ENABLED']!='true':missing.append('ENABLED')
        if c['SENDER_CONFIRMED']!='true':missing.append('SENDER_CONFIRMED')
        return c,missing
    def render(self,row,c):
        body=row['body']+'\n\nJohn Occhipinti\nClarity- Life Stages | The Umbrella Institute\n'+(c['POSTAL_ADDRESS'] or '[Business postal address required before sending]')+'\n\nBusiness introduction / promotional email.\nTo stop further outreach, unsubscribe: '+BASE+'/outreach/unsubscribe?t='+row['token']+'\nYou may also reply asking us to stop.'
        sha=hashlib.sha256(json.dumps([row['email'],row['subject'],body,c['FROM']],ensure_ascii=False).encode()).hexdigest()
        return {k:row[k] for k in ('id','email','company','source','fact','subject','state','created','attempt_at','receipt')}|{'body':body,'draft_body':row['body'],'review_hash':sha}
    def status(self):
        c,missing=self.config()
        with self.db() as db:
            rows=db.execute('SELECT * FROM co_drafts ORDER BY created DESC LIMIT 100').fetchall();suppressed=db.execute('SELECT email,at,reason FROM co_suppressed ORDER BY at DESC LIMIT 100').fetchall()
        return {'sending_ready':not missing,'missing':missing,'sender':c['FROM'],'drafts':[self.render(r,c) for r in rows],'suppressed':[dict(r) for r in suppressed],'daily_limit':5,'mode':'Human review required. Structured templates, not an autonomous language model.','note':'SMTP acceptance is not delivery. Replies and bounces must be monitored in your sending mailbox.'}
    def create(self,data):
        if data.get('verified_source') is not True:raise OutreachError('VERIFY_BUSINESS_CONTACT_AND_SOURCE')
        recipient=email(data.get('email',''));company=clean(data.get('company'),120);fact=clean(data.get('fact'),500);source=clean(data.get('source'),1000)
        u=urlparse(source)
        if u.scheme not in ('http','https') or not u.hostname or u.username or u.password:raise OutreachError('PUBLIC_SOURCE_URL_REQUIRED')
        subject='A planning-resource conversation with '+company
        body='Hello '+company+' team,\n\n'+fact+'\n\nI’m John, building Clarity- Life Stages under The Umbrella Institute. It is an educational planning preview that helps people organize questions about trusts, wills, care preferences and their next life stage. It does not prepare legal documents or provide legal advice.\n\nI’m looking for feedback from businesses that support people through these conversations. Would a brief product-feedback conversation be useful to your team? There is no obligation to participate.\n\nYou can explore the preview here: '+BASE+'/#clarity'
        if data.get('campaign')=='website':
            subject=clean(data.get('subject'),180)
            body=data.get('body')
            if not isinstance(body,str) or not 20<=len(body)<=8000 or '\x00' in body:raise OutreachError('INVALID_BODY')
        rowid=secrets.token_hex(12)
        with self.db() as db:
            if db.execute('SELECT 1 FROM co_suppressed WHERE email=?',(recipient,)).fetchone():raise OutreachError('DO_NOT_CONTACT')
            try:db.execute('INSERT INTO co_drafts VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(rowid,recipient,company,source,fact,subject,body,secrets.token_hex(32),'DRAFT',time.time(),None,None))
            except sqlite3.IntegrityError:raise OutreachError('CONTACT_ALREADY_IN_QUEUE') from None
        return self.status()
    def edit(self,data):
        subject=clean(data.get('subject'),180);body=data.get('body')
        if not isinstance(body,str) or not 20<=len(body)<=8000 or '\x00' in body:raise OutreachError('INVALID_BODY')
        with self.db() as db:
            cursor=db.execute("UPDATE co_drafts SET subject=?,body=? WHERE id=? AND state='DRAFT'",(subject,body,data.get('id')))
            if cursor.rowcount!=1:raise OutreachError('DRAFT_NOT_EDITABLE')
        return self.status()
    def suppress(self,address,reason='MANUAL_OPT_OUT'):
        address=email(address)
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO co_suppressed VALUES(?,?,?)',(address,time.time(),reason));db.execute("UPDATE co_drafts SET state='SUPPRESSED' WHERE email=? AND state='DRAFT'",(address,))
    def unsubscribe(self,token,commit=False):
        if not isinstance(token,str) or not re.fullmatch('[a-f0-9]{64}',token):raise OutreachError('INVALID_LINK')
        with self.db() as db:row=db.execute('SELECT email FROM co_drafts WHERE token=?',(token,)).fetchone()
        if not row:raise OutreachError('INVALID_LINK')
        if commit:self.suppress(row['email'],'UNSUBSCRIBE_LINK')
        title='You have been unsubscribed.' if commit else 'Stop Clarity outreach'
        action='' if commit else '<form method="post"><button type="submit">Unsubscribe from all Clarity outreach</button></form>'
        return ('<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Clarity outreach</title><body style="font:18px system-ui;max-width:620px;margin:60px auto;padding:24px"><h1>'+title+'</h1>'+action+'<p>Clarity- Life Stages · The Umbrella Institute</p></body></html>').encode()
    def send(self,data):
        if data.get('approved') is not True:raise OutreachError('INDIVIDUAL_APPROVAL_REQUIRED')
        c,missing=self.config()
        if missing:raise OutreachError('SENDER_SETUP_INCOMPLETE')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT * FROM co_drafts WHERE id=?',(data.get('id'),)).fetchone()
            if not row or row['state']!='DRAFT':raise OutreachError('ALREADY_ATTEMPTED_OR_NOT_DRAFT')
            if db.execute('SELECT 1 FROM co_suppressed WHERE email=?',(row['email'],)).fetchone():raise OutreachError('DO_NOT_CONTACT')
            preview=self.render(row,c)
            if not secrets.compare_digest(str(data.get('review_hash','')),preview['review_hash']):raise OutreachError('DRAFT_CHANGED_REVIEW_AGAIN')
            if db.execute('SELECT count(*) FROM co_drafts WHERE attempt_at>?',(time.time()-86400,)).fetchone()[0]>=5:raise OutreachError('DAILY_LIMIT_REACHED')
            db.execute("UPDATE co_drafts SET state='SENDING',attempt_at=? WHERE id=?",(time.time(),row['id']))
        # Intent committed before network call; crashes/uncertainty never trigger automatic resend.
        try:receipt=self.transport(c,row['email'],row['subject'],preview['body']);state='SMTP_ACCEPTED'
        except Exception:receipt=None;state='UNKNOWN_CHECK_MAILBOX'
        with self.db() as db:db.execute('UPDATE co_drafts SET state=?,receipt=? WHERE id=?',(state,receipt,row['id']))
        return self.status()
