import copy
import json
import unittest
from pathlib import Path
from datetime import datetime,timezone,timedelta
import historical_pilot as p

class PilotTests(unittest.TestCase):
    def setUp(self):
        self.cfg=json.loads((Path(__file__).parent/'pilot_config.json').read_text())
        start=datetime(2025,3,1,tzinfo=timezone.utc)
        self.bars=[]
        for i in range(150):
            d=start+timedelta(days=i)
            price=100+i/10
            self.bars.append({'date':d.date().isoformat(),'t':int(d.timestamp()*1000),'o':price,'h':price+2,'l':price-2,'c':price+1,'v':1000 if i%10==0 else 100})

    def test_future_prices_cannot_change_earlier_decision(self):
        before=p.replay('TEST','Massive',self.bars,self.cfg)
        changed=copy.deepcopy(self.bars)
        for b in changed[65:]:
            for k in ('o','h','l','c'):b[k]*=3
        after=p.replay('TEST','Massive',changed,self.cfg)
        for a,b in zip(before,after):
            if a['decision_date']<changed[65]['date']:
                for k in ('decision','reason','relative_volume','regime'):self.assertEqual(a[k],b[k])

    def test_entry_lag_costs_and_no_overlap(self):
        rows=p.replay('TEST','Massive',self.bars,self.cfg)
        accepted=[r for r in rows if r['decision']=='ACCEPTED']
        self.assertTrue(accepted)
        previous={}
        for r in accepted:
            self.assertGreater(r['entry_date'],r['decision_date'])
            self.assertAlmostEqual(r['gross_return_pct']-r['net_return_pct'],.1)
            self.assertAlmostEqual(r['net_return_pct']-r['double_cost_return_pct'],.1)
            self.assertGreater(r['entry_date'],previous.get(r['window'],''))
            previous[r['window']]=r['exit_date']

    def test_censored_outcomes_and_no_false_pass(self):
        rows=p.replay('TEST','Massive',self.bars,self.cfg)
        censored=[r for r in rows if r['decision']=='CENSORED']
        self.assertTrue(censored)
        self.assertTrue(all(r['net_return_pct'] is None for r in censored))
        result=p.report(self.cfg,rows,[])
        self.assertEqual(result['verified_options_observations'],0)
        self.assertFalse(result['execution_enabled'])
        self.assertTrue(all(not w['options_oos_pass'] for w in result['windows']))

    def test_input_duplicates_rejected(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'bad.json'
            path.write_text(json.dumps([[1,100,101,99,100,1],[1,100,101,99,100,1]]))
            with self.assertRaises(ValueError):p.load_bars(path)

if __name__=='__main__':unittest.main()
