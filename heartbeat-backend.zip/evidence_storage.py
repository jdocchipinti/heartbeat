"""Append-only application records; not an independently immutable audit store."""
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from contextlib import contextmanager

class StorageError(Exception):pass

class Connection:
    def __init__(self,raw,postgres):self.raw,self.postgres=raw,postgres
    def execute(self,sql,args=()):
        return self.raw.execute(sql.replace('?', '%s') if self.postgres else sql,args)

@contextmanager
def connect(path,url=''):
    raw=None
    try:
        if url:
            import psycopg
            raw=psycopg.connect(url,connect_timeout=8,options='-c statement_timeout=10000')
        else:
            Path(path).parent.mkdir(parents=True,exist_ok=True)
            raw=sqlite3.connect(path,timeout=10)
            raw.execute('PRAGMA journal_mode=WAL')
        con=Connection(raw,bool(url))
        with raw:
            con.execute('CREATE TABLE IF NOT EXISTS observations (symbol TEXT, bar_time BIGINT, observed_at BIGINT, digest TEXT, payload TEXT, request_id TEXT, PRIMARY KEY(symbol,bar_time,observed_at,digest))')
            con.execute('CREATE TABLE IF NOT EXISTS evidence_artifacts (id TEXT PRIMARY KEY, kind TEXT NOT NULL, created_at BIGINT NOT NULL, digest TEXT NOT NULL, payload TEXT NOT NULL)')
            yield con
    except Exception:
        # Database exceptions can contain passwords/connection strings; never expose them.
        raise StorageError('EVIDENCE_STORAGE_UNAVAILABLE') from None
    finally:
        if raw is not None:raw.close()

def save(path,url,id,kind,payload):
    data=json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False)
    digest=hashlib.sha256(data.encode()).hexdigest()
    with connect(path,url) as con:
        old=con.execute('SELECT digest FROM evidence_artifacts WHERE id=?',(id,)).fetchone()
        if old and old[0]!=digest:raise ValueError('Artifact ID conflict')
        con.execute('INSERT INTO evidence_artifacts VALUES (?,?,?,?,?) ON CONFLICT DO NOTHING',(id,kind,int(time.time()*1000),digest,data))
    return digest

def latest(path,url,kind):
    with connect(path,url) as con:
        row=con.execute('SELECT id,digest,payload FROM evidence_artifacts WHERE kind=? ORDER BY created_at DESC,id DESC LIMIT 1',(kind,)).fetchone()
    if not row:return None
    if hashlib.sha256(row[2].encode()).hexdigest()!=row[1]:raise StorageError('ARTIFACT_INTEGRITY_FAILURE')
    return {'id':row[0],'payload':json.loads(row[2]),'sha256':row[1]}

def verify(path,url,process_id):
    prior=latest(path,url,'storage_probe')
    save(path,url,'storage-'+process_id,'storage_probe',{'process_id':process_id})
    return {'backend':'PostgreSQL' if url else 'SQLite','read_write':'VERIFIED','prior_process_record_read':bool(prior and prior['payload']['process_id']!=process_id),'durability':'Cross-process read observed; hosting retention and backups still require verification.' if prior and prior['payload']['process_id']!=process_id else 'Restart recovery not yet verified.','managed_database_configured':bool(url),'execution_enabled':False}
