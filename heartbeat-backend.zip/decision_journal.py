"""Deterministic observation records. No broker calls or simulated option profits."""
import copy
import hashlib
import json
import threading
from pathlib import Path
import evidence_storage as storage
import agent_review

CONFIG=json.loads(Path(__file__).with_name('decision_experiment.json').read_text())
def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
CONFIG_HASH=digest(CONFIG)
RUNNER_HASH=digest({'journal':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'review':agent_review.SOURCE_HASH})
GUARD=threading.RLock()

def get(path,url,id):
    with storage.connect(path,url) as con:
        row=con.execute('SELECT digest,payload FROM evidence_artifacts WHERE id=?',(id,)).fetchone()
    if row is None:return None
    data=json.loads(row[1])
    if digest(data)!=row[0]:raise storage.StorageError('ARTIFACT_INTEGRITY_FAILURE')
    return data

def recent(path,url,limit=100,pending=False):
    with storage.connect(path,url) as con:
        if pending:
            rows=con.execute("SELECT d.digest,d.payload FROM evidence_artifacts d LEFT JOIN evidence_artifacts o ON o.id=d.id||'-outcome' WHERE d.kind=? AND o.id IS NULL ORDER BY d.created_at DESC,d.id DESC LIMIT ?",('decision',limit)).fetchall()
        else:
            rows=con.execute('SELECT digest,payload FROM evidence_artifacts WHERE kind=? ORDER BY created_at DESC,id DESC LIMIT ?',('decision',limit)).fetchall()
    result=[]
    for sha,payload in rows:
        value=json.loads(payload)
        if digest(value)!=sha:raise storage.StorageError('ARTIFACT_INTEGRITY_FAILURE')
        result.append(value)
    return result

# Each initial specialist sees the same raw snapshot, never another specialist output.
def tokyo(s):
    bars=s['bars'];ratio=None
    if len(bars)>=21:
        baseline=sum(b['v'] for b in bars[-21:-1])/20
        if baseline:ratio=bars[-1]['v']/baseline
    return {'status':'WATCH' if ratio is not None and ratio>=CONFIG['signal']['relative_volume_min'] else 'NO_VOLUME_TRIGGER' if ratio is not None else 'MISSING_BASELINE','relative_volume':ratio,'finding':'Underlying candle activity only; options flow and buyer intent unknown.'}

def palermo(s):
    bars=s['bars'];fast=slow=None
    if len(bars)>=20:
        fast=sum(b['c'] for b in bars[-5:])/5;slow=sum(b['c'] for b in bars[-20:])/20
    return {'status':'STRUCTURE_WATCH' if fast is not None and fast>slow else 'NO_UPWARD_STRUCTURE' if fast is not None else 'MISSING_BASELINE','sma5':fast,'sma20':slow,'entry_conditions':'Volume trigger plus upward structure, then verified option contract, quotes, eligibility and risk checks. No entry price available.'}

def denver(s):
    issues=list(s['issues'])+['Option quotes unavailable','Earnings and macro-event coverage unverified','Options validation incomplete']
    return {'status':'REJECT','issues':issues,'finding':'A price pattern cannot override missing execution and event evidence.'}

def stockholm(s):
    return {'status':'BLOCKED','spread':None,'bid_size':None,'ask_size':None,'modeled_cost':None,'finding':'No verified option bid/ask snapshot. Fill feasibility cannot be established.'}

def professor_initial(s):
    return {'status':'INSUFFICIENT_EVIDENCE','finding':'Initial scope check: underlying candles only; no verified option quote or eligibility evidence. No peer assessments read.'}

def build(s):
    s={k:copy.deepcopy(v) for k,v in s.items() if k!='engines'}
    if s['symbol'] not in CONFIG['universe']:raise ValueError('OUTSIDE_EXPERIMENT_UNIVERSE')
    initial={name:fn(copy.deepcopy(s)) for name,fn in [('tokyo',tokyo),('palermo',palermo),('denver',denver),('stockholm',stockholm),('professor',professor_initial)]}
    discussion=agent_review.run(s,initial)
    watch=initial['tokyo']['status']=='WATCH' and initial['palermo']['status']=='STRUCTURE_WATCH'
    basis={'symbol':s['symbol'],'bars':s['bars'],'issues':s['issues'],'session':s['session'],'config':CONFIG_HASH,'runner':RUNNER_HASH}
    id='HB-D-'+digest(basis)[:24]
    stages=copy.deepcopy(initial)
    stages['professor']={'status':'NO_QUALIFYING_TRADE','summary':('Volume and structure both met the observation rules. ' if watch else 'The underlying observation rules did not both trigger. ')+'Denver rejects missing options/event evidence; Stockholm cannot verify a fill. Keep this observation; do not place an order.','uncertainty':'No options-price outcome or validated predictive probability is available.'}
    return {'id':id,'experiment_version':CONFIG['version'],'config_sha256':CONFIG_HASH,'runner_sha256':RUNNER_HASH,'input_sha256':digest(s),'symbol':s['symbol'],'evaluated_at':s['server_time'],'source':s['source'],'collected_at':s['collected_at'],'last_bar_at':s['bars'][-1]['t'] if s['bars'] else None,'snapshot':copy.deepcopy(s),'collaboration':discussion,'initial_assessments':initial,'review':stages,'initial_sha256':digest(initial),'decision':'NO_QUALIFYING_TRADE','underlying_watch':watch,'what_changed':initial['tokyo'],'why_it_matters':initial['palermo'],'what_disagrees':initial['denver']['issues'],'invalidation':'Cancel the watch if fast SMA falls to/below slow SMA, the activity trigger disappears, data is stale, or any hard gate fails. Stops do not guarantee a maximum loss.','could_fill':False,'fill_status':'NOT_ASSESSABLE','outcome_status':'PENDING_UNDERLYING_OBSERVATION_ONLY','execution_enabled':False,'readiness_credit':0}

def capture(path,url,s):
    record=build(s)
    with GUARD:
        old=get(path,url,record['id'])
        if old:return old
        storage.save(path,url,'experiment-'+CONFIG_HASH+'-'+RUNNER_HASH,'experiment',{'config':CONFIG,'config_sha256':CONFIG_HASH,'runner_sha256':RUNNER_HASH,'runner_source':Path(__file__).read_text(),'review_source':Path(agent_review.__file__).read_text()})
        storage.save(path,url,record['id'],'decision',record)
    return record

def follow(path,url,s):
    # Append outcomes separately; never recompute or overwrite the original decision.
    for r in recent(path,url,500,pending=True):
        if r['symbol']!=s['symbol'] or r['config_sha256']!=CONFIG_HASH:continue
        oid=r['id']+'-outcome'
        original=r['snapshot']['bars']
        if not original:continue
        target=((r['evaluated_at']+59999)//60000)*60000+CONFIG['outcome']['minutes_after_decision']*60000
        if s['server_time']<target:continue
        bar=next((b for b in s['bars'] if b['t']+60000==target),None)
        if bar is None:continue
        result={'decision_id':r['id'],'scope':'Underlying counterfactual; not option P&L or a trade result','target_bar_close_at':target,'observed_at':s['server_time'],'source':s['source'],'original_close':original[-1]['c'],'later_bar':bar,'underlying_change_pct':(bar['c']/original[-1]['c']-1)*100,'option_pnl':None,'fill':None,'benchmark_return':None,'readiness_credit':0}
        storage.save(path,url,oid,'decision_outcome',result)

def listing(path,url):
    records=recent(path,url)
    outcomes={}
    if records:
        ids=[r['id']+'-outcome' for r in records]
        with storage.connect(path,url) as con:
            rows=con.execute('SELECT id,digest,payload FROM evidence_artifacts WHERE id IN ('+','.join('?' for _ in ids)+')',tuple(ids)).fetchall()
        for id,sha,payload in rows:
            value=json.loads(payload)
            if digest(value)!=sha:raise storage.StorageError('ARTIFACT_INTEGRITY_FAILURE')
            outcomes[id]=value
    return {'experiment':CONFIG,'config_sha256':CONFIG_HASH,'runner_sha256':RUNNER_HASH,'limit':100,'retention_note':'Latest 100 shown; older records remain in configured storage. Export includes these 100, not the entire database.','storage':'PostgreSQL configured; recovery unverified' if url else 'SQLite; restart durability unverified','records':[{'record':r,'outcome':outcomes.get(r['id']+'-outcome')} for r in records],'execution_enabled':False,'readiness_credit':0}
