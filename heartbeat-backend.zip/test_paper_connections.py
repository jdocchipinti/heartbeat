import unittest,json
from types import SimpleNamespace
from unittest.mock import patch
import paper_connections as p

class ConnectionChecks(unittest.TestCase):
    def worker(self):return SimpleNamespace(key='private-fixture-key',secret='private-fixture-secret',path='/var/data/paper.db',enabled=True)
    def states(self,r):return {c['name']:c['state'] for c in r['checks']}
    def test_no_configuration_is_not_ready(self):
        w=self.worker();w.key='';w.enabled=False
        with patch.object(p.os.path,'ismount',return_value=False):r=p.check(w,{},1000)
        self.assertEqual(self.states(r)['Paper credentials'],'BLOCKED');self.assertEqual(self.states(r)['Worker enabled'],'BLOCKED');self.assertEqual(self.states(r)['Persistent disk'],'BLOCKED');self.assertEqual(self.states(r)['Broker / Guardian cycle'],'UNVERIFIED')
    def test_configured_is_not_authenticated(self):
        with patch.object(p.os.path,'ismount',return_value=True):r=p.check(self.worker(),{'worker_started':True,'last_tick':1000,'error':'AUTH_REJECTED'},1000)
        self.assertEqual(self.states(r)['Paper credentials'],'CONFIGURED');self.assertEqual(self.states(r)['Worker health'],'BLOCKED');self.assertEqual(self.states(r)['Broker / Guardian cycle'],'UNVERIFIED');self.assertNotIn('private-fixture',json.dumps(r))
    def test_recent_cycle_and_quote_age_are_separate(self):
        report={'worker_started':True,'last_tick':1000,'guardian':{'checked_at':1000},'latest':{'quotes':{'BTC/USD':{'t':'1970-01-01T00:16:40+00:00'}}},'state':{}}
        r=p.check(self.worker(),report,1005);self.assertEqual(self.states(r)['BTC/USD quote'],'RECENT');self.assertEqual(self.states(r)['Broker / Guardian cycle'],'VERIFIED');self.assertEqual(self.states(r)['Paper entry state'],'WAITING');self.assertFalse(r['forced_trade'])
        r=p.check(self.worker(),report,1020);self.assertEqual(self.states(r)['BTC/USD quote'],'WAITING');self.assertEqual(self.states(r)['Worker health'],'READY')
    def test_expired_report_and_pause(self):
        r=p.check(self.worker(),{'worker_started':True,'last_tick':700,'guardian':{'checked_at':700},'state':{'paused':True}},1000)
        self.assertEqual(self.states(r)['Broker / Guardian cycle'],'UNVERIFIED');self.assertEqual(self.states(r)['Paper entry state'],'PAUSED')
