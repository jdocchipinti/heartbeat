import copy
import json
import tempfile
import unittest
from unittest.mock import patch
import decision_journal as j
import evidence_storage as storage
import server

NOW=1800000000000

def observation():
    bars=[{'t':NOW-(21-i)*60000,'o':100+i,'h':102+i,'l':99+i,'c':101+i,'v':10 if i<20 else 30,'vw':100+i} for i in range(21)]
    return {'symbol':'SPY','server_time':NOW,'source':'test fixture, not market evidence','collected_at':NOW,'session':'open','issues':[],'bars':bars,'engines':{'tokyo':{'status':'FABRICATED_PEER_OPINION'}}}

class DecisionTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.path=self.tmp.name+'/journal.db'
    def tearDown(self):self.tmp.cleanup()
    def test_independent_initials_and_hard_block(self):
        s=observation();record=j.build(s)
        self.assertTrue(record['underlying_watch']);self.assertFalse(record['could_fill'])
        self.assertEqual(record['decision'],'NO_QUALIFYING_TRADE');self.assertEqual(record['readiness_credit'],0)
        self.assertNotIn('engines',record['snapshot'])
        s['engines']={'tokyo':{'status':'OTHER'}}
        self.assertEqual(j.build(s)['initial_assessments'],record['initial_assessments'])
        record['review']['tokyo']['status']='MUTATED'
        self.assertEqual(record['initial_assessments']['tokyo']['status'],'WATCH')
    def test_repeat_read_does_not_rewrite_decision_time(self):
        s=observation();first=j.capture(self.path,'',s);s['server_time']+=1000;s['collected_at']+=1000
        second=j.capture(self.path,'',s)
        self.assertEqual(first,second);self.assertEqual(len(j.recent(self.path,'')),1)
    def test_future_outcome_is_separate_and_not_profit(self):
        s=observation();r=j.capture(self.path,'',s)
        future=copy.deepcopy(s);future['server_time']=NOW+300000
        future['bars'].append({'t':NOW+240000,'o':120,'h':130,'l':119,'c':125,'v':20,'vw':123})
        j.follow(self.path,'',future)
        self.assertEqual(j.get(self.path,'',r['id']),r)
        o=j.get(self.path,'',r['id']+'-outcome');self.assertIsNone(o['option_pnl']);self.assertIsNone(o['fill']);self.assertEqual(o['readiness_credit'],0)
        future['bars'][-1]['c']=124;j.follow(self.path,'',future)
        self.assertEqual(j.get(self.path,'',r['id']+'-outcome'),o)
    def test_missing_target_never_substituted(self):
        s=observation();r=j.capture(self.path,'',s);s['server_time']+=600000;j.follow(self.path,'',s)
        self.assertIsNone(j.get(self.path,'',r['id']+'-outcome'))
    def test_source_revision_keeps_both_decisions(self):
        s=observation();a=j.capture(self.path,'',s);s['bars'][-1]['v']=1;b=j.capture(self.path,'',s)
        self.assertNotEqual(a['id'],b['id']);self.assertEqual(len(j.listing(self.path,'')['records']),2)
    def test_corruption_is_rejected(self):
        r=j.capture(self.path,'',observation())
        with storage.connect(self.path) as c:c.execute('UPDATE evidence_artifacts SET payload=? WHERE id=?',('{}',r['id']))
        with self.assertRaises(storage.StorageError):j.listing(self.path,'')
    def test_authenticated_read_only_endpoint(self):
        def call(auth='',method='GET'):
            result=[]
            body=b''.join(server.application({'PATH_INFO':'/api/decisions','REQUEST_METHOD':method,'HTTP_AUTHORIZATION':auth},lambda code,headers:result.append(code)))
            return result[0],json.loads(body)
        with patch.object(server,'DB',self.path),patch.object(server,'DATABASE_URL',''),patch.object(server,'TOKEN','x'*32),patch.object(server,'ensure_started',lambda:None):
            self.assertEqual(call()[0],'401 Unauthorized')
            self.assertEqual(call('Bearer '+'x'*32)[0],'200 OK')
            self.assertEqual(call('Bearer '+'x'*32,'POST')[0],'405 Method Not Allowed')

if __name__=='__main__':unittest.main()
