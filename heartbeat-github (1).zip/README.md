# Heartbeat — The Umbrella Institute

This repository contains the current browser-based research dashboard.

## Upload to GitHub

1. Extract heartbeat-github.zip on your computer.
2. Create a private GitHub repository named heartbeat.
3. Upload index.html and this README.md into the repository root (not the ZIP itself).
4. Commit the files and share the repository URL with your assistant.
5. Authorize Render to read this specific private repository when prompted.

## Render static-site settings

- Workspace: The Umbrella Institute (confirmed)
- Service type: Static Site
- Build command: `echo "Static dashboard; no build required"`
- Publish directory: `.`
- No environment variables or secrets are needed for the static dashboard.

Render's static URL is public even if this source repository is private. Do not add account information or API keys to these files. Static hosting uses the workspace's bandwidth/build allowances; this package creates no resources or billing commitments.

## Current capabilities and limits

- Five deterministic browser-based crypto spot research modules, peer messages, and 3D orbit.
- Public Binance spot quotes/candles when the browser can reach the feed.
- A 3D regional media view with dated snapshot evidence and external sources.
- TradingView US chart embedding, with delayed-data labels. Its rendering has not been browser-verified; the ChatGPT HTML preview showed a blank chart.
- No authenticated US market-data backend, continuously running collector, persistent paper ledger, options validation, or brokerage execution.
- The widget's candles are not accessible to the research modules. Hosting alone does not change this.
- Existing local logic tests passed; these are not evidence of investment returns.

## Next backend milestone

Verify market-data entitlements, then build authenticated server-side ingestion, timestamp/latency checks, durable records, and chart/engine data delivery. Review hosting costs before creating paid services. Keep brokerage execution disabled.
